import { VStack } from '@chakra-ui/react';
import './App.css';
import Connect from './components/Connect';
import Contract1 from './components/Contract';
import Disconnect from './components/Disconnect';
import WalletDetail from './components/WalletDetails';
import Contract from './components/contract';
import { useUser } from './context/UserContext';

function App() {
  const {user} = useUser()

  return (
    <VStack justifyContent="center" alignItems="center" minH="100vh">
      {
        !user ? (
        <Connect /> ) : (
          <>
            <WalletDetail />
            <Contract />
            <Contract1 />
            <Disconnect />
          </>
        )
      }
    </VStack>
  );
}

export default App;
