import { Button, Divider, Flex, Text } from "@chakra-ui/react";
import { ethers } from "ethers";
import { useState } from "react";
import Web3 from "web3";
import { bytecode, contractABI } from "../ABI_file";
import { useUser } from "../context/UserContext";
import { magic } from "../utils/magic";

const Contract1 = () => {
    const {user} = useUser();
    // const {web3} = useWeb3();
    const web3 = new Web3(magic.rpcProvider);
    const [contractAddress, setContractAddress] = useState('')
    // const provider = new ethers.providers.Web3Provider(magic.rpcProvider);
    // let signer = provider.getSigner(user)

    const handleDeploy = async() => {
        const contract = new ethers.ContractFactory(contractABI,bytecode)
        const receipt = await contract.deploy();
        console.log(receipt)
    }

    return(
        <Flex direction={"column"}>
            <Divider my={2} />
            <Text fontFamily="heading" fontWeight={"bold"} fontSize={22} align={"center"}>Sign Transaction</Text>
            <Divider my={2} />
            <Button onClick={handleDeploy}>Deploy</Button>
            <Divider my={2} />
        </Flex>
    )
}

export default Contract1;