import { Button, Divider, Flex, Text } from "@chakra-ui/react";
import { useState } from "react";
import { contractABI } from "../ABI_file";
import { useUser } from "../context/UserContext";
import { useWeb3 } from "../context/Web3context";

const Contract = () => {
    const {user} = useUser();
    const {web3} = useWeb3();
    // const web3 = new Web3(magic.rpcProvider);
    const [contractAddress, setContractAddress] = useState('')

    const handleDeploy = async() => {
        // const cont = new ethers.Contract("0x2cEc1183F4E1bc0A1e78E76aBC00C80448e1B586",contractABI)
        // console.log(cont)
        // await cont.mint(user,user)
        const contract = new web3.eth.Contract(contractABI,"0x2cEc1183F4E1bc0A1e78E76aBC00C80448e1B586")
        console.log("contract: ",contract)
        contract.methods.name().call()
                // .send({from: user})
                .on('transactionHash', (hash: string) => {
                    console.log('Transaction hash:', hash);
                })
                .then((receipt:any)=>{
                    console.log("receipt: ",receipt)
                })
                .catch((error:any)=>{
                    console.log(error)
                })
    }

    return(
        <Flex direction={"column"}>
            <Divider my={2} />
            <Text fontFamily="heading" fontWeight={"bold"} fontSize={22} align={"center"}>Sign Transaction</Text>
            <Divider my={2} />
            <Button onClick={handleDeploy}>Deploy</Button>
            <Divider my={2} />
        </Flex>
    )
}

export default Contract;