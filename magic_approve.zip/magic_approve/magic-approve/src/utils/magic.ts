import { Magic } from 'magic-sdk';
import Web3 from 'web3';

export const magic = new Magic("pk_live_6B5FCCFF6378BBC6",{
    network: 'goerli'
})

export const getProvider = () => {
    return (magic.wallet as any).getProvider();
}

export const getWeb3 = async() => {
    const provider = await getProvider();
    return new Web3(provider)
}