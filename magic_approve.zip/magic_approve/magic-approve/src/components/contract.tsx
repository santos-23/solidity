import { Button, Divider, Flex, Text } from "@chakra-ui/react";
import { useState } from "react";
import { contractABI } from "../ABI_file";
import { useUser } from "../context/UserContext";
import { useWeb3 } from "../context/Web3context";

const Contract = () => {
    const {user} = useUser();
    const {web3} = useWeb3();
    // const web3 = new Web3(magic.rpcProvider);
    const [contractAddress, setContractAddress] = useState('')

    const handleDeploy = async() => {
        console.log(user)
        const contract = new web3.eth.Contract(contractABI,"0xE5f2A565Ee0Aa9836B4c80a07C8b32aAd7978e22")
        contract.methods.name().call()
        console.log(contract)
    }

    return(
        <Flex direction={"column"}>
            <Divider my={2} />
            <Text fontFamily="heading" fontWeight={"bold"} fontSize={22} align={"center"}>Sign Transaction</Text>
            <Divider my={2} />
            <Button onClick={handleDeploy}>Deploy</Button>
            <Divider my={2} />
        </Flex>
    )
}

export default Contract;