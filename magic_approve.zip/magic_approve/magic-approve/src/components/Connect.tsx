import { Button } from "@chakra-ui/react";
import { useUser } from "../context/UserContext";
import { useWeb3 } from "../context/Web3context";
import { getWeb3, magic } from "../utils/magic";

const Connect = () => {
    const {setUser} = useUser();
    const {setWeb3} = useWeb3();

    const handleConnect = async() => {
        try {
            const accounts = await magic.wallet.connectWithUI();
            console.log(accounts[0])
            localStorage.setItem('user', accounts[0]);
            const web3 = await getWeb3();
            setWeb3(web3);
            setUser(accounts[0]);
        } catch (error) {
            console.log(error)
        }
    }
    
    return(
        <Button onClick={handleConnect}>Connect</Button>
    )
}

export default Connect;