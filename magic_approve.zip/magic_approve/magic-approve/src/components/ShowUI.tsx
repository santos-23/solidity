import { Button } from "@chakra-ui/react";
import { magic } from "../utils/magic";

const ShowUIButton = () => {
    const handleShowUI = async () => {
        try {
            await magic?.wallet.showUI()
        } catch (error) {
            console.error("handleShowUI:", error)
        }
    }

    return <Button onClick={handleShowUI}>Show UI</Button>
}

export default ShowUIButton;