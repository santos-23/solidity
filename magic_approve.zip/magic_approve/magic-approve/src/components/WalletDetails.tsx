import { Divider, Flex, Text } from "@chakra-ui/react";
import { useEffect, useState } from "react";
import { useUser } from "../context/UserContext";
import { useWeb3 } from "../context/Web3context";
import Disconnect from "./Disconnect";
import ShowUIButton from "./ShowUI";

const WalletDetail = () => {
    const { web3 } = useWeb3()
    const { user } = useUser()

    const [balance,setBalance] = useState("...")

    useEffect(()=>{
        const getBalance = async() => {
            if(!user || !web3) return
            try {
                const balance = await web3?.eth.getBalance(user)
                setBalance(web3?.utils.fromWei(balance,"ether").substring(0,7))
            } catch (error) {
                console.error("WalletDetail error: ",error)
            }
        }
        getBalance();
    },[user])

    return(
        <Flex direction="column">
            <Divider my={2} />
            <Text fontFamily="heading" fontWeight={"bold"} fontSize={22} align={"center"}>WALLET</Text>
            <Divider my={2} />
            <Text fontWeight="bold">Address</Text>
            <Text fontFamily="monospace" my={2}>
                {user}
            </Text>
            <Divider my={2} />
            <Text fontWeight="bold">Balance</Text>
            <Text fontFamily="monospace">{balance} ETH</Text>
            <Divider my={2} />
            <ShowUIButton />
            <Divider my={2} />
            <Disconnect />
        </Flex>
    )
}

export default WalletDetail;