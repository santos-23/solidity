import { Button, Flex } from "@chakra-ui/react";
import { useUser } from "../context/UserContext";
import { magic } from "../utils/magic";

const Disconnect = () => {
    const {user} = useUser();

    const handleDisconnect = async() => {
        try {
            await magic.user.logout();
        } catch (error) {
            console.log("Handle Disconnect Errors: ", error)
        }
    }

    return(
        <Flex direction={"column"}>
            <Button onClick={handleDisconnect}>Disconnect</Button>
        </Flex>
    )
}

export default Disconnect;