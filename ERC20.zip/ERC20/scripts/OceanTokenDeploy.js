const { ethers } = require("hardhat");

async function main(){
    const OceanToken = await ethers.getContractFactory("OceanToken");
    const oceanToken = await OceanToken.deploy(100000000,50);

    // await oceanToken.deployed();

    console.log("deployed on: ",oceanToken.target);
}

main()
.then(()=>process.exit(0))
.catch((error)=>{
    console.error(error);
    process.exit(1)
})