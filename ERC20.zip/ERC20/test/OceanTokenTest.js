const { expect } = require("chai");
const { ethers } = require("hardhat");


describe("Ocean Token",function(){
    let oceanToken,OceanToken;
    let owner,addr1,addr2;
    let tokenCap = 100000000;
    let tokenBlockReward = 50;

    beforeEach(async function(){
        OceanToken = await ethers.getContractFactory("OceanToken");
        [owner,addr1,addr2] = await ethers.getSigners();
        oceanToken = await OceanToken.deploy(tokenCap,tokenBlockReward);
    })

    describe("deployments: ",function(){
        it("should set the right owner",async function(){
            expect(await oceanToken.owner()).to.equal(owner.address);
        });
        it("should assign the total supply of tokens to the owner",async function(){
            const ownerBalance = await oceanToken.balanceOf(owner.address);
            console.log(ownerBalance);
            expect(await oceanToken.totalSupply()).to.equal(ownerBalance);
        });
        it("should set max capped supply to the argument provided during the deployment",async function(){
            const cap = await oceanToken.cap();
            console.log(cap);
            expect(Number(ethers.formatEther(cap))).to.equal(tokenCap);
        })
        it("should set the block reward to the argument provided during the deployment",async function(){
            const blockReward = await oceanToken.blockReward();
            console.log(blockReward);
            expect(Number(ethers.formatEther(blockReward))).to.equal(tokenBlockReward);
        })
    })
    describe("Transactions: ",function(){
        it("should transfer token between accounts",async function(){
            await oceanToken.transfer(addr1.address,50);
            const addr1Balance = await oceanToken.balanceOf(addr1.address);
            console.log(addr1Balance);
            expect(addr1Balance).to.equal(50);

            await oceanToken.connect(addr1).transfer(addr2.address,30);
            const addr2Balance = await oceanToken.balanceOf(addr2.address);
            console.log(addr1Balance);
            expect(addr2Balance).to.equal(30);
        })
        it("should fail if sender doesn't have tokens to send",async function(){
            const initialOwnerBalance = await oceanToken.balanceOf(owner.address);
            await expect(oceanToken.connect(addr1).transfer(owner.address,1))
                .to.be.revertedWith("ERC20: transfer amount exceeds balance")

            expect(await oceanToken.balanceOf(owner.address)).to.equal(initialOwnerBalance);
        });
        it("should update balace after transactions",async function(){
            const initialOwnerBalance = await oceanToken.balanceOf(owner.address);
            console.log(initialOwnerBalance);
            await oceanToken.transfer(addr1.address,100);
            await oceanToken.transfer(addr2.address,50);

            const currentOwnerBalance = await oceanToken.balanceOf(owner.address);
            console.log(currentOwnerBalance);

            const addr1Balance = await oceanToken.balanceOf(addr1.address);
            console.log(addr1Balance);
            expect(addr1Balance).to.equal(100);

            const addr2Balance = await oceanToken.balanceOf(addr2.address);
            console.log(addr2Balance);
            expect(addr2Balance).to.equal(50);
        })
    })
})