const magic = require("magic-sdk");

const customNodeOptions = {
    rpcUrl : "https://rpc-mumbai.maticvigil.com",
    chainId : "80001"
}