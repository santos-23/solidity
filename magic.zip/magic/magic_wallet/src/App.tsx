import { VStack } from '@chakra-ui/react';
import './App.css';
import ConnectButton from './components/ConnectButton';
import DisconnectButton from './components/DisconnectButton';
import SendTransaction from './components/SendTransaction';
import SignMessage from './components/SignMessage';
import WalletDetail from './components/WalletDetail';
import { useUser } from './context/UserContext';

function App() {
  const {user} = useUser()
  return (
    <VStack justifyContent="center" alignItems="center" minH="100vh">
      {!user ? (
        <ConnectButton />
      ) : (
        <>
          <WalletDetail />
          <SendTransaction />
          <SignMessage />
          <DisconnectButton />
          
        </>
      )}
    </VStack>
  );
}

export default App;
