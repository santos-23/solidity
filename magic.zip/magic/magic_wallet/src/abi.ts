export const nftAbi: any = [
  {
    inputs: [],
    stateMutability: 'nonpayable',
    type: 'constructor',
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'address',
        name: 'owner',
        type: 'address',
      },
      {
        indexed: true,
        internalType: 'address',
        name: 'approved',
        type: 'address',
      },
      {
        indexed: true,
        internalType: 'uint256',
        name: 'tokenId',
        type: 'uint256',
      },
    ],
    name: 'Approval',
    type: 'event',
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'address',
        name: 'owner',
        type: 'address',
      },
      {
        indexed: true,
        internalType: 'address',
        name: 'operator',
        type: 'address',
      },
      {
        indexed: false,
        internalType: 'bool',
        name: 'approved',
        type: 'bool',
      },
    ],
    name: 'ApprovalForAll',
    type: 'event',
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'address',
        name: 'from',
        type: 'address',
      },
      {
        indexed: true,
        internalType: 'address',
        name: 'to',
        type: 'address',
      },
      {
        indexed: true,
        internalType: 'uint256',
        name: 'tokenId',
        type: 'uint256',
      },
    ],
    name: 'Transfer',
    type: 'event',
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: 'to',
        type: 'address',
      },
      {
        internalType: 'uint256',
        name: 'tokenId',
        type: 'uint256',
      },
    ],
    name: 'approve',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: 'owner',
        type: 'address',
      },
    ],
    name: 'balanceOf',
    outputs: [
      {
        internalType: 'uint256',
        name: '',
        type: 'uint256',
      },
    ],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'uint256',
        name: 'tokenId',
        type: 'uint256',
      },
    ],
    name: 'getApproved',
    outputs: [
      {
        internalType: 'address',
        name: '',
        type: 'address',
      },
    ],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: '_owner',
        type: 'address',
      },
    ],
    name: 'getNftsByAddress',
    outputs: [
      {
        internalType: 'uint256[]',
        name: '',
        type: 'uint256[]',
      },
    ],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: 'owner',
        type: 'address',
      },
      {
        internalType: 'address',
        name: 'operator',
        type: 'address',
      },
    ],
    name: 'isApprovedForAll',
    outputs: [
      {
        internalType: 'bool',
        name: '',
        type: 'bool',
      },
    ],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'string',
        name: 'uri',
        type: 'string',
      },
    ],
    name: 'mint',
    outputs: [
      {
        internalType: 'uint256',
        name: '',
        type: 'uint256',
      },
    ],
    stateMutability: 'nonpayable',
    type: 'function',
  },
  {
    inputs: [],
    name: 'name',
    outputs: [
      {
        internalType: 'string',
        name: '',
        type: 'string',
      },
    ],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'uint256',
        name: 'tokenId',
        type: 'uint256',
      },
    ],
    name: 'ownerOf',
    outputs: [
      {
        internalType: 'address',
        name: '',
        type: 'address',
      },
    ],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: 'from',
        type: 'address',
      },
      {
        internalType: 'address',
        name: 'to',
        type: 'address',
      },
      {
        internalType: 'uint256',
        name: 'tokenId',
        type: 'uint256',
      },
    ],
    name: 'safeTransferFrom',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: 'from',
        type: 'address',
      },
      {
        internalType: 'address',
        name: 'to',
        type: 'address',
      },
      {
        internalType: 'uint256',
        name: 'tokenId',
        type: 'uint256',
      },
      {
        internalType: 'bytes',
        name: 'data',
        type: 'bytes',
      },
    ],
    name: 'safeTransferFrom',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: 'operator',
        type: 'address',
      },
      {
        internalType: 'bool',
        name: 'approved',
        type: 'bool',
      },
    ],
    name: 'setApprovalForAll',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'bytes4',
        name: 'interfaceId',
        type: 'bytes4',
      },
    ],
    name: 'supportsInterface',
    outputs: [
      {
        internalType: 'bool',
        name: '',
        type: 'bool',
      },
    ],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [],
    name: 'symbol',
    outputs: [
      {
        internalType: 'string',
        name: '',
        type: 'string',
      },
    ],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'uint256',
        name: 'index',
        type: 'uint256',
      },
    ],
    name: 'tokenByIndex',
    outputs: [
      {
        internalType: 'uint256',
        name: '',
        type: 'uint256',
      },
    ],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: 'owner',
        type: 'address',
      },
      {
        internalType: 'uint256',
        name: 'index',
        type: 'uint256',
      },
    ],
    name: 'tokenOfOwnerByIndex',
    outputs: [
      {
        internalType: 'uint256',
        name: '',
        type: 'uint256',
      },
    ],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'uint256',
        name: 'tokenId',
        type: 'uint256',
      },
    ],
    name: 'tokenURI',
    outputs: [
      {
        internalType: 'string',
        name: '',
        type: 'string',
      },
    ],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [],
    name: 'totalSupply',
    outputs: [
      {
        internalType: 'uint256',
        name: '',
        type: 'uint256',
      },
    ],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'address',
        name: 'from',
        type: 'address',
      },
      {
        internalType: 'address',
        name: 'to',
        type: 'address',
      },
      {
        internalType: 'uint256',
        name: 'tokenId',
        type: 'uint256',
      },
    ],
    name: 'transferFrom',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function',
  },
];

export const ERC20ABI = [
        {
        "inputs": [],
        "stateMutability": "nonpayable",
        "type": "constructor"
        },
        {
        "anonymous": false,
        "inputs": [
            {
            "indexed": true,
            "internalType": "address",
            "name": "owner",
            "type": "address"
            },
            {
            "indexed": true,
            "internalType": "address",
            "name": "spender",
            "type": "address"
            },
            {
            "indexed": false,
            "internalType": "uint256",
            "name": "value",
            "type": "uint256"
            }
        ],
        "name": "Approval",
        "type": "event"
        },
        {
        "anonymous": false,
        "inputs": [
            {
            "indexed": true,
            "internalType": "address",
            "name": "from",
            "type": "address"
            },
            {
            "indexed": true,
            "internalType": "address",
            "name": "to",
            "type": "address"
            },
            {
            "indexed": false,
            "internalType": "uint256",
            "name": "value",
            "type": "uint256"
            }
        ],
        "name": "Transfer",
        "type": "event"
        },
        {
        "inputs": [
            {
            "internalType": "address",
            "name": "owner",
            "type": "address"
            },
            {
            "internalType": "address",
            "name": "spender",
            "type": "address"
            }
        ],
        "name": "allowance",
        "outputs": [
            {
            "internalType": "uint256",
            "name": "",
            "type": "uint256"
            }
        ],
        "stateMutability": "view",
        "type": "function"
        },
        {
        "inputs": [
            {
            "internalType": "address",
            "name": "spender",
            "type": "address"
            },
            {
            "internalType": "uint256",
            "name": "amount",
            "type": "uint256"
            }
        ],
        "name": "approve",
        "outputs": [
            {
            "internalType": "bool",
            "name": "",
            "type": "bool"
            }
        ],
        "stateMutability": "nonpayable",
        "type": "function"
        },
        {
        "inputs": [
            {
            "internalType": "address",
            "name": "account",
            "type": "address"
            }
        ],
        "name": "balanceOf",
        "outputs": [
            {
            "internalType": "uint256",
            "name": "",
            "type": "uint256"
            }
        ],
        "stateMutability": "view",
        "type": "function"
        },
        {
        "inputs": [],
        "name": "decimals",
        "outputs": [
            {
            "internalType": "uint8",
            "name": "",
            "type": "uint8"
            }
        ],
        "stateMutability": "view",
        "type": "function"
        },
        {
        "inputs": [
            {
            "internalType": "address",
            "name": "spender",
            "type": "address"
            },
            {
            "internalType": "uint256",
            "name": "subtractedValue",
            "type": "uint256"
            }
        ],
        "name": "decreaseAllowance",
        "outputs": [
            {
            "internalType": "bool",
            "name": "",
            "type": "bool"
            }
        ],
        "stateMutability": "nonpayable",
        "type": "function"
        },
        {
        "inputs": [
            {
            "internalType": "address",
            "name": "spender",
            "type": "address"
            },
            {
            "internalType": "uint256",
            "name": "addedValue",
            "type": "uint256"
            }
        ],
        "name": "increaseAllowance",
        "outputs": [
            {
            "internalType": "bool",
            "name": "",
            "type": "bool"
            }
        ],
        "stateMutability": "nonpayable",
        "type": "function"
        },
        {
        "inputs": [
            {
            "internalType": "uint256",
            "name": "tokenAmount",
            "type": "uint256"
            }
        ],
        "name": "mint",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
        },
        {
        "inputs": [],
        "name": "name",
        "outputs": [
            {
            "internalType": "string",
            "name": "",
            "type": "string"
            }
        ],
        "stateMutability": "view",
        "type": "function"
        },
        {
        "inputs": [],
        "name": "symbol",
        "outputs": [
            {
            "internalType": "string",
            "name": "",
            "type": "string"
            }
        ],
        "stateMutability": "view",
        "type": "function"
        },
        {
        "inputs": [],
        "name": "totalSupply",
        "outputs": [
            {
            "internalType": "uint256",
            "name": "",
            "type": "uint256"
            }
        ],
        "stateMutability": "view",
        "type": "function"
        },
        {
        "inputs": [
            {
            "internalType": "address",
            "name": "to",
            "type": "address"
            },
            {
            "internalType": "uint256",
            "name": "amount",
            "type": "uint256"
            }
        ],
        "name": "transfer",
        "outputs": [
            {
            "internalType": "bool",
            "name": "",
            "type": "bool"
            }
        ],
        "stateMutability": "nonpayable",
        "type": "function"
        },
        {
        "inputs": [
            {
            "internalType": "address",
            "name": "from",
            "type": "address"
            },
            {
            "internalType": "address",
            "name": "to",
            "type": "address"
            },
            {
            "internalType": "uint256",
            "name": "amount",
            "type": "uint256"
            }
        ],
        "name": "transferFrom",
        "outputs": [
            {
            "internalType": "bool",
            "name": "",
            "type": "bool"
            }
        ],
        "stateMutability": "nonpayable",
        "type": "function"
        }
    ]

export const ERC721ABI = [
  {
    "inputs": [],
    "stateMutability": "nonpayable",
    "type": "constructor"
  },
  {
    "anonymous": false,
    "inputs": [
      {
        "indexed": true,
        "internalType": "address",
        "name": "owner",
        "type": "address"
      },
      {
        "indexed": true,
        "internalType": "address",
        "name": "approved",
        "type": "address"
      },
      {
        "indexed": true,
        "internalType": "uint256",
        "name": "tokenId",
        "type": "uint256"
      }
    ],
    "name": "Approval",
    "type": "event"
  },
  {
    "anonymous": false,
    "inputs": [
      {
        "indexed": true,
        "internalType": "address",
        "name": "owner",
        "type": "address"
      },
      {
        "indexed": true,
        "internalType": "address",
        "name": "operator",
        "type": "address"
      },
      {
        "indexed": false,
        "internalType": "bool",
        "name": "approved",
        "type": "bool"
      }
    ],
    "name": "ApprovalForAll",
    "type": "event"
  },
  {
    "anonymous": false,
    "inputs": [
      {
        "indexed": false,
        "internalType": "uint256",
        "name": "_fromTokenId",
        "type": "uint256"
      },
      {
        "indexed": false,
        "internalType": "uint256",
        "name": "_toTokenId",
        "type": "uint256"
      }
    ],
    "name": "BatchMetadataUpdate",
    "type": "event"
  },
  {
    "anonymous": false,
    "inputs": [
      {
        "indexed": false,
        "internalType": "uint256",
        "name": "_tokenId",
        "type": "uint256"
      }
    ],
    "name": "MetadataUpdate",
    "type": "event"
  },
  {
    "anonymous": false,
    "inputs": [
      {
        "indexed": true,
        "internalType": "address",
        "name": "from",
        "type": "address"
      },
      {
        "indexed": true,
        "internalType": "address",
        "name": "to",
        "type": "address"
      },
      {
        "indexed": true,
        "internalType": "uint256",
        "name": "tokenId",
        "type": "uint256"
      }
    ],
    "name": "Transfer",
    "type": "event"
  },
  {
    "inputs": [
      {
        "internalType": "address",
        "name": "to",
        "type": "address"
      },
      {
        "internalType": "uint256",
        "name": "tokenId",
        "type": "uint256"
      }
    ],
    "name": "TransferNFT",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [
      {
        "internalType": "address",
        "name": "to",
        "type": "address"
      },
      {
        "internalType": "uint256",
        "name": "tokenId",
        "type": "uint256"
      }
    ],
    "name": "approve",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [
      {
        "internalType": "address",
        "name": "owner",
        "type": "address"
      }
    ],
    "name": "balanceOf",
    "outputs": [
      {
        "internalType": "uint256",
        "name": "",
        "type": "uint256"
      }
    ],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [
      {
        "internalType": "uint256",
        "name": "tokenId",
        "type": "uint256"
      }
    ],
    "name": "getApproved",
    "outputs": [
      {
        "internalType": "address",
        "name": "",
        "type": "address"
      }
    ],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [
      {
        "internalType": "address",
        "name": "owner",
        "type": "address"
      },
      {
        "internalType": "address",
        "name": "operator",
        "type": "address"
      }
    ],
    "name": "isApprovedForAll",
    "outputs": [
      {
        "internalType": "bool",
        "name": "",
        "type": "bool"
      }
    ],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "mint",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "name",
    "outputs": [
      {
        "internalType": "string",
        "name": "",
        "type": "string"
      }
    ],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [
      {
        "internalType": "uint256",
        "name": "tokenId",
        "type": "uint256"
      }
    ],
    "name": "ownerOf",
    "outputs": [
      {
        "internalType": "address",
        "name": "",
        "type": "address"
      }
    ],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [
      {
        "internalType": "address",
        "name": "from",
        "type": "address"
      },
      {
        "internalType": "address",
        "name": "to",
        "type": "address"
      },
      {
        "internalType": "uint256",
        "name": "tokenId",
        "type": "uint256"
      }
    ],
    "name": "safeTransferFrom",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [
      {
        "internalType": "address",
        "name": "from",
        "type": "address"
      },
      {
        "internalType": "address",
        "name": "to",
        "type": "address"
      },
      {
        "internalType": "uint256",
        "name": "tokenId",
        "type": "uint256"
      },
      {
        "internalType": "bytes",
        "name": "data",
        "type": "bytes"
      }
    ],
    "name": "safeTransferFrom",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [
      {
        "internalType": "address",
        "name": "operator",
        "type": "address"
      },
      {
        "internalType": "bool",
        "name": "approved",
        "type": "bool"
      }
    ],
    "name": "setApprovalForAll",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [
      {
        "internalType": "bytes4",
        "name": "interfaceId",
        "type": "bytes4"
      }
    ],
    "name": "supportsInterface",
    "outputs": [
      {
        "internalType": "bool",
        "name": "",
        "type": "bool"
      }
    ],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "symbol",
    "outputs": [
      {
        "internalType": "string",
        "name": "",
        "type": "string"
      }
    ],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [
      {
        "internalType": "uint256",
        "name": "tokenId",
        "type": "uint256"
      }
    ],
    "name": "tokenURI",
    "outputs": [
      {
        "internalType": "string",
        "name": "",
        "type": "string"
      }
    ],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [
      {
        "internalType": "address",
        "name": "from",
        "type": "address"
      },
      {
        "internalType": "address",
        "name": "to",
        "type": "address"
      },
      {
        "internalType": "uint256",
        "name": "tokenId",
        "type": "uint256"
      }
    ],
    "name": "transferFrom",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  }
]

export const demoABI = [
  {
    "inputs": [],
    "stateMutability": "nonpayable",
    "type": "constructor"
  },
  {
    "anonymous": false,
    "inputs": [
      {
        "indexed": true,
        "internalType": "address",
        "name": "owner",
        "type": "address"
      },
      {
        "indexed": true,
        "internalType": "address",
        "name": "approved",
        "type": "address"
      },
      {
        "indexed": true,
        "internalType": "uint256",
        "name": "tokenId",
        "type": "uint256"
      }
    ],
    "name": "Approval",
    "type": "event"
  },
  {
    "anonymous": false,
    "inputs": [
      {
        "indexed": true,
        "internalType": "address",
        "name": "owner",
        "type": "address"
      },
      {
        "indexed": true,
        "internalType": "address",
        "name": "operator",
        "type": "address"
      },
      {
        "indexed": false,
        "internalType": "bool",
        "name": "approved",
        "type": "bool"
      }
    ],
    "name": "ApprovalForAll",
    "type": "event"
  },
  {
    "anonymous": false,
    "inputs": [
      {
        "indexed": true,
        "internalType": "address",
        "name": "from",
        "type": "address"
      },
      {
        "indexed": true,
        "internalType": "address",
        "name": "to",
        "type": "address"
      },
      {
        "indexed": true,
        "internalType": "uint256",
        "name": "tokenId",
        "type": "uint256"
      }
    ],
    "name": "Transfer",
    "type": "event"
  },
  {
    "inputs": [
      {
        "internalType": "address",
        "name": "to",
        "type": "address"
      },
      {
        "internalType": "uint256",
        "name": "tokenId",
        "type": "uint256"
      }
    ],
    "name": "approve",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [
      {
        "internalType": "address",
        "name": "owner",
        "type": "address"
      }
    ],
    "name": "balanceOf",
    "outputs": [
      {
        "internalType": "uint256",
        "name": "",
        "type": "uint256"
      }
    ],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "collect",
    "outputs": [],
    "stateMutability": "payable",
    "type": "function"
  },
  {
    "inputs": [
      {
        "internalType": "uint256",
        "name": "tokenId",
        "type": "uint256"
      }
    ],
    "name": "getApproved",
    "outputs": [
      {
        "internalType": "address",
        "name": "",
        "type": "address"
      }
    ],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [
      {
        "internalType": "address",
        "name": "owner",
        "type": "address"
      },
      {
        "internalType": "address",
        "name": "operator",
        "type": "address"
      }
    ],
    "name": "isApprovedForAll",
    "outputs": [
      {
        "internalType": "bool",
        "name": "",
        "type": "bool"
      }
    ],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [
      {
        "internalType": "address",
        "name": "to",
        "type": "address"
      }
    ],
    "name": "mint",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "name",
    "outputs": [
      {
        "internalType": "string",
        "name": "",
        "type": "string"
      }
    ],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [
      {
        "internalType": "uint256",
        "name": "tokenId",
        "type": "uint256"
      }
    ],
    "name": "ownerOf",
    "outputs": [
      {
        "internalType": "address",
        "name": "",
        "type": "address"
      }
    ],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [
      {
        "internalType": "address",
        "name": "from",
        "type": "address"
      },
      {
        "internalType": "address",
        "name": "to",
        "type": "address"
      },
      {
        "internalType": "uint256",
        "name": "tokenId",
        "type": "uint256"
      }
    ],
    "name": "safeTransferFrom",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [
      {
        "internalType": "address",
        "name": "from",
        "type": "address"
      },
      {
        "internalType": "address",
        "name": "to",
        "type": "address"
      },
      {
        "internalType": "uint256",
        "name": "tokenId",
        "type": "uint256"
      },
      {
        "internalType": "bytes",
        "name": "data",
        "type": "bytes"
      }
    ],
    "name": "safeTransferFrom",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [
      {
        "internalType": "address",
        "name": "operator",
        "type": "address"
      },
      {
        "internalType": "bool",
        "name": "approved",
        "type": "bool"
      }
    ],
    "name": "setApprovalForAll",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [
      {
        "internalType": "bytes4",
        "name": "interfaceId",
        "type": "bytes4"
      }
    ],
    "name": "supportsInterface",
    "outputs": [
      {
        "internalType": "bool",
        "name": "",
        "type": "bool"
      }
    ],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "symbol",
    "outputs": [
      {
        "internalType": "string",
        "name": "",
        "type": "string"
      }
    ],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [
      {
        "internalType": "uint256",
        "name": "tokenId",
        "type": "uint256"
      }
    ],
    "name": "tokenURI",
    "outputs": [
      {
        "internalType": "string",
        "name": "",
        "type": "string"
      }
    ],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [
      {
        "internalType": "address",
        "name": "to",
        "type": "address"
      }
    ],
    "name": "transFer",
    "outputs": [],
    "stateMutability": "payable",
    "type": "function"
  },
  {
    "inputs": [
      {
        "internalType": "address",
        "name": "from",
        "type": "address"
      },
      {
        "internalType": "address",
        "name": "to",
        "type": "address"
      },
      {
        "internalType": "uint256",
        "name": "tokenId",
        "type": "uint256"
      }
    ],
    "name": "transferFrom",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  }
]

export const ERC115ABI = [
  {
    "inputs": [],
    "stateMutability": "nonpayable",
    "type": "constructor"
  },
  {
    "anonymous": false,
    "inputs": [
      {
        "indexed": true,
        "internalType": "address",
        "name": "account",
        "type": "address"
      },
      {
        "indexed": true,
        "internalType": "address",
        "name": "operator",
        "type": "address"
      },
      {
        "indexed": false,
        "internalType": "bool",
        "name": "approved",
        "type": "bool"
      }
    ],
    "name": "ApprovalForAll",
    "type": "event"
  },
  {
    "anonymous": false,
    "inputs": [
      {
        "indexed": true,
        "internalType": "address",
        "name": "operator",
        "type": "address"
      },
      {
        "indexed": true,
        "internalType": "address",
        "name": "from",
        "type": "address"
      },
      {
        "indexed": true,
        "internalType": "address",
        "name": "to",
        "type": "address"
      },
      {
        "indexed": false,
        "internalType": "uint256[]",
        "name": "ids",
        "type": "uint256[]"
      },
      {
        "indexed": false,
        "internalType": "uint256[]",
        "name": "values",
        "type": "uint256[]"
      }
    ],
    "name": "TransferBatch",
    "type": "event"
  },
  {
    "anonymous": false,
    "inputs": [
      {
        "indexed": true,
        "internalType": "address",
        "name": "operator",
        "type": "address"
      },
      {
        "indexed": true,
        "internalType": "address",
        "name": "from",
        "type": "address"
      },
      {
        "indexed": true,
        "internalType": "address",
        "name": "to",
        "type": "address"
      },
      {
        "indexed": false,
        "internalType": "uint256",
        "name": "id",
        "type": "uint256"
      },
      {
        "indexed": false,
        "internalType": "uint256",
        "name": "value",
        "type": "uint256"
      }
    ],
    "name": "TransferSingle",
    "type": "event"
  },
  {
    "anonymous": false,
    "inputs": [
      {
        "indexed": false,
        "internalType": "string",
        "name": "value",
        "type": "string"
      },
      {
        "indexed": true,
        "internalType": "uint256",
        "name": "id",
        "type": "uint256"
      }
    ],
    "name": "URI",
    "type": "event"
  },
  {
    "inputs": [
      {
        "internalType": "address",
        "name": "account",
        "type": "address"
      },
      {
        "internalType": "uint256",
        "name": "id",
        "type": "uint256"
      }
    ],
    "name": "balanceOf",
    "outputs": [
      {
        "internalType": "uint256",
        "name": "",
        "type": "uint256"
      }
    ],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [
      {
        "internalType": "address[]",
        "name": "accounts",
        "type": "address[]"
      },
      {
        "internalType": "uint256[]",
        "name": "ids",
        "type": "uint256[]"
      }
    ],
    "name": "balanceOfBatch",
    "outputs": [
      {
        "internalType": "uint256[]",
        "name": "",
        "type": "uint256[]"
      }
    ],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [
      {
        "internalType": "address",
        "name": "account",
        "type": "address"
      },
      {
        "internalType": "address",
        "name": "operator",
        "type": "address"
      }
    ],
    "name": "isApprovedForAll",
    "outputs": [
      {
        "internalType": "bool",
        "name": "",
        "type": "bool"
      }
    ],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [
      {
        "internalType": "uint256",
        "name": "amount",
        "type": "uint256"
      }
    ],
    "name": "mintCard",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "name",
    "outputs": [
      {
        "internalType": "string",
        "name": "",
        "type": "string"
      }
    ],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [
      {
        "internalType": "address",
        "name": "from",
        "type": "address"
      },
      {
        "internalType": "address",
        "name": "to",
        "type": "address"
      },
      {
        "internalType": "uint256[]",
        "name": "ids",
        "type": "uint256[]"
      },
      {
        "internalType": "uint256[]",
        "name": "amounts",
        "type": "uint256[]"
      },
      {
        "internalType": "bytes",
        "name": "data",
        "type": "bytes"
      }
    ],
    "name": "safeBatchTransferFrom",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [
      {
        "internalType": "address",
        "name": "from",
        "type": "address"
      },
      {
        "internalType": "address",
        "name": "to",
        "type": "address"
      },
      {
        "internalType": "uint256",
        "name": "id",
        "type": "uint256"
      },
      {
        "internalType": "uint256",
        "name": "amount",
        "type": "uint256"
      },
      {
        "internalType": "bytes",
        "name": "data",
        "type": "bytes"
      }
    ],
    "name": "safeTransferFrom",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [
      {
        "internalType": "address",
        "name": "operator",
        "type": "address"
      },
      {
        "internalType": "bool",
        "name": "approved",
        "type": "bool"
      }
    ],
    "name": "setApprovalForAll",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [
      {
        "internalType": "bytes4",
        "name": "interfaceId",
        "type": "bytes4"
      }
    ],
    "name": "supportsInterface",
    "outputs": [
      {
        "internalType": "bool",
        "name": "",
        "type": "bool"
      }
    ],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "symbol",
    "outputs": [
      {
        "internalType": "string",
        "name": "",
        "type": "string"
      }
    ],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [
      {
        "internalType": "uint256",
        "name": "_tokenid",
        "type": "uint256"
      }
    ],
    "name": "uri",
    "outputs": [
      {
        "internalType": "string",
        "name": "",
        "type": "string"
      }
    ],
    "stateMutability": "pure",
    "type": "function"
  }
]

export const demoByteCode = "0x608060405260006006553480156200001657600080fd5b506040518060400160405280600c81526020017f43727970746f546f6b656e7300000000000000000000000000000000000000008152506040518060400160405280600381526020017f4352540000000000000000000000000000000000000000000000000000000000815250816000908162000094919062000329565b508060019081620000a6919062000329565b50505062000410565b600081519050919050565b7f4e487b7100000000000000000000000000000000000000000000000000000000600052604160045260246000fd5b7f4e487b7100000000000000000000000000000000000000000000000000000000600052602260045260246000fd5b600060028204905060018216806200013157607f821691505b602082108103620001475762000146620000e9565b5b50919050565b60008190508160005260206000209050919050565b60006020601f8301049050919050565b600082821b905092915050565b600060088302620001b17fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff8262000172565b620001bd868362000172565b95508019841693508086168417925050509392505050565b6000819050919050565b6000819050919050565b60006200020a62000204620001fe84620001d5565b620001df565b620001d5565b9050919050565b6000819050919050565b6200022683620001e9565b6200023e620002358262000211565b8484546200017f565b825550505050565b600090565b6200025562000246565b620002628184846200021b565b505050565b5b818110156200028a576200027e6000826200024b565b60018101905062000268565b5050565b601f821115620002d957620002a3816200014d565b620002ae8462000162565b81016020851015620002be578190505b620002d6620002cd8562000162565b83018262000267565b50505b505050565b600082821c905092915050565b6000620002fe60001984600802620002de565b1980831691505092915050565b6000620003198383620002eb565b9150826002028217905092915050565b6200033482620000af565b67ffffffffffffffff81111562000350576200034f620000ba565b5b6200035c825462000118565b620003698282856200028e565b600060209050601f831160018114620003a157600084156200038c578287015190505b6200039885826200030b565b86555062000408565b601f198416620003b1866200014d565b60005b82811015620003db57848901518255600182019150602085019450602081019050620003b4565b86831015620003fb5784890151620003f7601f891682620002eb565b8355505b6001600288020188555050505b505050505050565b61266880620004206000396000f3fe6080604052600436106100f35760003560e01c80636a6278421161008a578063b88d4fde11610059578063b88d4fde1461032b578063c87b56dd14610354578063e522538114610391578063e985e9c51461039b576100f3565b80636a6278421461027157806370a082311461029a57806395d89b41146102d7578063a22cb46514610302576100f3565b806323b872dd116100c657806323b872dd146101c657806342842e0e146101ef57806343161344146102185780636352211e14610234576100f3565b806301ffc9a7146100f857806306fdde0314610135578063081812fc14610160578063095ea7b31461019d575b600080fd5b34801561010457600080fd5b5061011f600480360381019061011a91906118ed565b6103d8565b60405161012c9190611935565b60405180910390f35b34801561014157600080fd5b5061014a6104ba565b60405161015791906119e0565b60405180910390f35b34801561016c57600080fd5b5061018760048036038101906101829190611a38565b61054c565b6040516101949190611aa6565b60405180910390f35b3480156101a957600080fd5b506101c460048036038101906101bf9190611aed565b610592565b005b3480156101d257600080fd5b506101ed60048036038101906101e89190611b2d565b6106a9565b005b3480156101fb57600080fd5b5061021660048036038101906102119190611b2d565b610709565b005b610232600480360381019061022d9190611b80565b610729565b005b34801561024057600080fd5b5061025b60048036038101906102569190611a38565b610779565b6040516102689190611aa6565b60405180910390f35b34801561027d57600080fd5b5061029860048036038101906102939190611b80565b6107ff565b005b3480156102a657600080fd5b506102c160048036038101906102bc9190611b80565b610826565b6040516102ce9190611bbc565b60405180910390f35b3480156102e357600080fd5b506102ec6108dd565b6040516102f991906119e0565b60405180910390f35b34801561030e57600080fd5b5061032960048036038101906103249190611c03565b61096f565b005b34801561033757600080fd5b50610352600480360381019061034d9190611d78565b610985565b005b34801561036057600080fd5b5061037b60048036038101906103769190611a38565b6109e7565b60405161038891906119e0565b60405180910390f35b610399610a4f565b005b3480156103a757600080fd5b506103c260048036038101906103bd9190611dfb565b610a98565b6040516103cf9190611935565b60405180910390f35b60007f80ac58cd000000000000000000000000000000000000000000000000000000007bffffffffffffffffffffffffffffffffffffffffffffffffffffffff1916827bffffffffffffffffffffffffffffffffffffffffffffffffffffffff191614806104a357507f5b5e139f000000000000000000000000000000000000000000000000000000007bffffffffffffffffffffffffffffffffffffffffffffffffffffffff1916827bffffffffffffffffffffffffffffffffffffffffffffffffffffffff1916145b806104b357506104b282610b2c565b5b9050919050565b6060600080546104c990611e6a565b80601f01602080910402602001604051908101604052809291908181526020018280546104f590611e6a565b80156105425780601f1061051757610100808354040283529160200191610542565b820191906000526020600020905b81548152906001019060200180831161052557829003601f168201915b5050505050905090565b600061055782610b96565b6004600083815260200190815260200160002060009054906101000a900473ffffffffffffffffffffffffffffffffffffffff169050919050565b600061059d82610779565b90508073ffffffffffffffffffffffffffffffffffffffff168373ffffffffffffffffffffffffffffffffffffffff160361060d576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040161060490611f0d565b60405180910390fd5b8073ffffffffffffffffffffffffffffffffffffffff1661062c610be1565b73ffffffffffffffffffffffffffffffffffffffff16148061065b575061065a81610655610be1565b610a98565b5b61069a576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040161069190611f9f565b60405180910390fd5b6106a48383610be9565b505050565b6106ba6106b4610be1565b82610ca2565b6106f9576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004016106f090612031565b60405180910390fd5b610704838383610d37565b505050565b61072483838360405180602001604052806000815250610985565b505050565b60003490508173ffffffffffffffffffffffffffffffffffffffff166108fc829081150290604051600060405180830381858888f19350505050158015610774573d6000803e3d6000fd5b505050565b60008061078583611030565b9050600073ffffffffffffffffffffffffffffffffffffffff168173ffffffffffffffffffffffffffffffffffffffff16036107f6576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004016107ed9061209d565b60405180910390fd5b80915050919050565b60066000815480929190610812906120ec565b91905055506108238160065461106d565b50565b60008073ffffffffffffffffffffffffffffffffffffffff168273ffffffffffffffffffffffffffffffffffffffff1603610896576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040161088d906121a6565b60405180910390fd5b600360008373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff168152602001908152602001600020549050919050565b6060600180546108ec90611e6a565b80601f016020809104026020016040519081016040528092919081815260200182805461091890611e6a565b80156109655780601f1061093a57610100808354040283529160200191610965565b820191906000526020600020905b81548152906001019060200180831161094857829003601f168201915b5050505050905090565b61098161097a610be1565b838361128a565b5050565b610996610990610be1565b83610ca2565b6109d5576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004016109cc90612031565b60405180910390fd5b6109e1848484846113f6565b50505050565b60606109f282610b96565b60006109fc611452565b90506000815111610a1c5760405180602001604052806000815250610a47565b80610a2684611469565b604051602001610a37929190612202565b6040516020818303038152906040525b915050919050565b3373ffffffffffffffffffffffffffffffffffffffff166108fc479081150290604051600060405180830381858888f19350505050158015610a95573d6000803e3d6000fd5b50565b6000600560008473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200190815260200160002060008373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200190815260200160002060009054906101000a900460ff16905092915050565b60007f01ffc9a7000000000000000000000000000000000000000000000000000000007bffffffffffffffffffffffffffffffffffffffffffffffffffffffff1916827bffffffffffffffffffffffffffffffffffffffffffffffffffffffff1916149050919050565b610b9f81611537565b610bde576040517f08c379a0000000000000000000000000000000000000000000000000000000008152600401610bd59061209d565b60405180910390fd5b50565b600033905090565b816004600083815260200190815260200160002060006101000a81548173ffffffffffffffffffffffffffffffffffffffff021916908373ffffffffffffffffffffffffffffffffffffffff160217905550808273ffffffffffffffffffffffffffffffffffffffff16610c5c83610779565b73ffffffffffffffffffffffffffffffffffffffff167f8c5be1e5ebec7d5bd14f71427d1e84f3dd0314c0f7b2291e5b200ac8c7c3b92560405160405180910390a45050565b600080610cae83610779565b90508073ffffffffffffffffffffffffffffffffffffffff168473ffffffffffffffffffffffffffffffffffffffff161480610cf05750610cef8185610a98565b5b80610d2e57508373ffffffffffffffffffffffffffffffffffffffff16610d168461054c565b73ffffffffffffffffffffffffffffffffffffffff16145b91505092915050565b8273ffffffffffffffffffffffffffffffffffffffff16610d5782610779565b73ffffffffffffffffffffffffffffffffffffffff1614610dad576040517f08c379a0000000000000000000000000000000000000000000000000000000008152600401610da490612298565b60405180910390fd5b600073ffffffffffffffffffffffffffffffffffffffff168273ffffffffffffffffffffffffffffffffffffffff1603610e1c576040517f08c379a0000000000000000000000000000000000000000000000000000000008152600401610e139061232a565b60405180910390fd5b610e298383836001611578565b8273ffffffffffffffffffffffffffffffffffffffff16610e4982610779565b73ffffffffffffffffffffffffffffffffffffffff1614610e9f576040517f08c379a0000000000000000000000000000000000000000000000000000000008152600401610e9690612298565b60405180910390fd5b6004600082815260200190815260200160002060006101000a81549073ffffffffffffffffffffffffffffffffffffffff02191690556001600360008573ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff168152602001908152602001600020600082825403925050819055506001600360008473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200190815260200160002060008282540192505081905550816002600083815260200190815260200160002060006101000a81548173ffffffffffffffffffffffffffffffffffffffff021916908373ffffffffffffffffffffffffffffffffffffffff160217905550808273ffffffffffffffffffffffffffffffffffffffff168473ffffffffffffffffffffffffffffffffffffffff167fddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef60405160405180910390a461102b838383600161157e565b505050565b60006002600083815260200190815260200160002060009054906101000a900473ffffffffffffffffffffffffffffffffffffffff169050919050565b600073ffffffffffffffffffffffffffffffffffffffff168273ffffffffffffffffffffffffffffffffffffffff16036110dc576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004016110d390612396565b60405180910390fd5b6110e581611537565b15611125576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040161111c90612402565b60405180910390fd5b611133600083836001611578565b61113c81611537565b1561117c576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040161117390612402565b60405180910390fd5b6001600360008473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200190815260200160002060008282540192505081905550816002600083815260200190815260200160002060006101000a81548173ffffffffffffffffffffffffffffffffffffffff021916908373ffffffffffffffffffffffffffffffffffffffff160217905550808273ffffffffffffffffffffffffffffffffffffffff16600073ffffffffffffffffffffffffffffffffffffffff167fddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef60405160405180910390a461128660008383600161157e565b5050565b8173ffffffffffffffffffffffffffffffffffffffff168373ffffffffffffffffffffffffffffffffffffffff16036112f8576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004016112ef9061246e565b60405180910390fd5b80600560008573ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200190815260200160002060008473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200190815260200160002060006101000a81548160ff0219169083151502179055508173ffffffffffffffffffffffffffffffffffffffff168373ffffffffffffffffffffffffffffffffffffffff167f17307eab39ab6107e8899845ad3d59bd9653f200f220920489ca2b5937696c31836040516113e99190611935565b60405180910390a3505050565b611401848484610d37565b61140d84848484611584565b61144c576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040161144390612500565b60405180910390fd5b50505050565b606060405180602001604052806000815250905090565b6060600060016114788461170b565b01905060008167ffffffffffffffff81111561149757611496611c4d565b5b6040519080825280601f01601f1916602001820160405280156114c95781602001600182028036833780820191505090505b509050600082602001820190505b60011561152c578080600190039150507f3031323334353637383961626364656600000000000000000000000000000000600a86061a8153600a85816115205761151f612520565b5b049450600085036114d7575b819350505050919050565b60008073ffffffffffffffffffffffffffffffffffffffff1661155983611030565b73ffffffffffffffffffffffffffffffffffffffff1614159050919050565b50505050565b50505050565b60006115a58473ffffffffffffffffffffffffffffffffffffffff1661185e565b156116fe578373ffffffffffffffffffffffffffffffffffffffff1663150b7a026115ce610be1565b8786866040518563ffffffff1660e01b81526004016115f094939291906125a4565b6020604051808303816000875af192505050801561162c57506040513d601f19601f820116820180604052508101906116299190612605565b60015b6116ae573d806000811461165c576040519150601f19603f3d011682016040523d82523d6000602084013e611661565b606091505b5060008151036116a6576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040161169d90612500565b60405180910390fd5b805181602001fd5b63150b7a0260e01b7bffffffffffffffffffffffffffffffffffffffffffffffffffffffff1916817bffffffffffffffffffffffffffffffffffffffffffffffffffffffff191614915050611703565b600190505b949350505050565b600080600090507a184f03e93ff9f4daa797ed6e38ed64bf6a1f0100000000000000008310611769577a184f03e93ff9f4daa797ed6e38ed64bf6a1f010000000000000000838161175f5761175e612520565b5b0492506040810190505b6d04ee2d6d415b85acef810000000083106117a6576d04ee2d6d415b85acef8100000000838161179c5761179b612520565b5b0492506020810190505b662386f26fc1000083106117d557662386f26fc1000083816117cb576117ca612520565b5b0492506010810190505b6305f5e10083106117fe576305f5e10083816117f4576117f3612520565b5b0492506008810190505b612710831061182357612710838161181957611818612520565b5b0492506004810190505b60648310611846576064838161183c5761183b612520565b5b0492506002810190505b600a8310611855576001810190505b80915050919050565b6000808273ffffffffffffffffffffffffffffffffffffffff163b119050919050565b6000604051905090565b600080fd5b600080fd5b60007fffffffff0000000000000000000000000000000000000000000000000000000082169050919050565b6118ca81611895565b81146118d557600080fd5b50565b6000813590506118e7816118c1565b92915050565b6000602082840312156119035761190261188b565b5b6000611911848285016118d8565b91505092915050565b60008115159050919050565b61192f8161191a565b82525050565b600060208201905061194a6000830184611926565b92915050565b600081519050919050565b600082825260208201905092915050565b60005b8381101561198a57808201518184015260208101905061196f565b60008484015250505050565b6000601f19601f8301169050919050565b60006119b282611950565b6119bc818561195b565b93506119cc81856020860161196c565b6119d581611996565b840191505092915050565b600060208201905081810360008301526119fa81846119a7565b905092915050565b6000819050919050565b611a1581611a02565b8114611a2057600080fd5b50565b600081359050611a3281611a0c565b92915050565b600060208284031215611a4e57611a4d61188b565b5b6000611a5c84828501611a23565b91505092915050565b600073ffffffffffffffffffffffffffffffffffffffff82169050919050565b6000611a9082611a65565b9050919050565b611aa081611a85565b82525050565b6000602082019050611abb6000830184611a97565b92915050565b611aca81611a85565b8114611ad557600080fd5b50565b600081359050611ae781611ac1565b92915050565b60008060408385031215611b0457611b0361188b565b5b6000611b1285828601611ad8565b9250506020611b2385828601611a23565b9150509250929050565b600080600060608486031215611b4657611b4561188b565b5b6000611b5486828701611ad8565b9350506020611b6586828701611ad8565b9250506040611b7686828701611a23565b9150509250925092565b600060208284031215611b9657611b9561188b565b5b6000611ba484828501611ad8565b91505092915050565b611bb681611a02565b82525050565b6000602082019050611bd16000830184611bad565b92915050565b611be08161191a565b8114611beb57600080fd5b50565b600081359050611bfd81611bd7565b92915050565b60008060408385031215611c1a57611c1961188b565b5b6000611c2885828601611ad8565b9250506020611c3985828601611bee565b9150509250929050565b600080fd5b600080fd5b7f4e487b7100000000000000000000000000000000000000000000000000000000600052604160045260246000fd5b611c8582611996565b810181811067ffffffffffffffff82111715611ca457611ca3611c4d565b5b80604052505050565b6000611cb7611881565b9050611cc38282611c7c565b919050565b600067ffffffffffffffff821115611ce357611ce2611c4d565b5b611cec82611996565b9050602081019050919050565b82818337600083830152505050565b6000611d1b611d1684611cc8565b611cad565b905082815260208101848484011115611d3757611d36611c48565b5b611d42848285611cf9565b509392505050565b600082601f830112611d5f57611d5e611c43565b5b8135611d6f848260208601611d08565b91505092915050565b60008060008060808587031215611d9257611d9161188b565b5b6000611da087828801611ad8565b9450506020611db187828801611ad8565b9350506040611dc287828801611a23565b925050606085013567ffffffffffffffff811115611de357611de2611890565b5b611def87828801611d4a565b91505092959194509250565b60008060408385031215611e1257611e1161188b565b5b6000611e2085828601611ad8565b9250506020611e3185828601611ad8565b9150509250929050565b7f4e487b7100000000000000000000000000000000000000000000000000000000600052602260045260246000fd5b60006002820490506001821680611e8257607f821691505b602082108103611e9557611e94611e3b565b5b50919050565b7f4552433732313a20617070726f76616c20746f2063757272656e74206f776e6560008201527f7200000000000000000000000000000000000000000000000000000000000000602082015250565b6000611ef760218361195b565b9150611f0282611e9b565b604082019050919050565b60006020820190508181036000830152611f2681611eea565b9050919050565b7f4552433732313a20617070726f76652063616c6c6572206973206e6f7420746f60008201527f6b656e206f776e6572206f7220617070726f76656420666f7220616c6c000000602082015250565b6000611f89603d8361195b565b9150611f9482611f2d565b604082019050919050565b60006020820190508181036000830152611fb881611f7c565b9050919050565b7f4552433732313a2063616c6c6572206973206e6f7420746f6b656e206f776e6560008201527f72206f7220617070726f76656400000000000000000000000000000000000000602082015250565b600061201b602d8361195b565b915061202682611fbf565b604082019050919050565b6000602082019050818103600083015261204a8161200e565b9050919050565b7f4552433732313a20696e76616c696420746f6b656e2049440000000000000000600082015250565b600061208760188361195b565b915061209282612051565b602082019050919050565b600060208201905081810360008301526120b68161207a565b9050919050565b7f4e487b7100000000000000000000000000000000000000000000000000000000600052601160045260246000fd5b60006120f782611a02565b91507fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff8203612129576121286120bd565b5b600182019050919050565b7f4552433732313a2061646472657373207a65726f206973206e6f74206120766160008201527f6c6964206f776e65720000000000000000000000000000000000000000000000602082015250565b600061219060298361195b565b915061219b82612134565b604082019050919050565b600060208201905081810360008301526121bf81612183565b9050919050565b600081905092915050565b60006121dc82611950565b6121e681856121c6565b93506121f681856020860161196c565b80840191505092915050565b600061220e82856121d1565b915061221a82846121d1565b91508190509392505050565b7f4552433732313a207472616e736665722066726f6d20696e636f72726563742060008201527f6f776e6572000000000000000000000000000000000000000000000000000000602082015250565b600061228260258361195b565b915061228d82612226565b604082019050919050565b600060208201905081810360008301526122b181612275565b9050919050565b7f4552433732313a207472616e7366657220746f20746865207a65726f2061646460008201527f7265737300000000000000000000000000000000000000000000000000000000602082015250565b600061231460248361195b565b915061231f826122b8565b604082019050919050565b6000602082019050818103600083015261234381612307565b9050919050565b7f4552433732313a206d696e7420746f20746865207a65726f2061646472657373600082015250565b600061238060208361195b565b915061238b8261234a565b602082019050919050565b600060208201905081810360008301526123af81612373565b9050919050565b7f4552433732313a20746f6b656e20616c7265616479206d696e74656400000000600082015250565b60006123ec601c8361195b565b91506123f7826123b6565b602082019050919050565b6000602082019050818103600083015261241b816123df565b9050919050565b7f4552433732313a20617070726f766520746f2063616c6c657200000000000000600082015250565b600061245860198361195b565b915061246382612422565b602082019050919050565b600060208201905081810360008301526124878161244b565b9050919050565b7f4552433732313a207472616e7366657220746f206e6f6e20455243373231526560008201527f63656976657220696d706c656d656e7465720000000000000000000000000000602082015250565b60006124ea60328361195b565b91506124f58261248e565b604082019050919050565b60006020820190508181036000830152612519816124dd565b9050919050565b7f4e487b7100000000000000000000000000000000000000000000000000000000600052601260045260246000fd5b600081519050919050565b600082825260208201905092915050565b60006125768261254f565b612580818561255a565b935061259081856020860161196c565b61259981611996565b840191505092915050565b60006080820190506125b96000830187611a97565b6125c66020830186611a97565b6125d36040830185611bad565b81810360608301526125e5818461256b565b905095945050505050565b6000815190506125ff816118c1565b92915050565b60006020828403121561261b5761261a61188b565b5b6000612629848285016125f0565b9150509291505056fea26469706673582212204fc028927bd2c4140e01510de91a39f08ae2aeec730221f36b8bc4d1e0b345a964736f6c63430008130033"

export const bytecode721 = "0x608060405260006007553480156200001657600080fd5b506040518060400160405280600881526020017f4d616769634e46540000000000000000000000000000000000000000000000008152506040518060400160405280600381526020017f4d4e460000000000000000000000000000000000000000000000000000000000815250816000908162000094919062000329565b508060019081620000a6919062000329565b50505062000410565b600081519050919050565b7f4e487b7100000000000000000000000000000000000000000000000000000000600052604160045260246000fd5b7f4e487b7100000000000000000000000000000000000000000000000000000000600052602260045260246000fd5b600060028204905060018216806200013157607f821691505b602082108103620001475762000146620000e9565b5b50919050565b60008190508160005260206000209050919050565b60006020601f8301049050919050565b600082821b905092915050565b600060088302620001b17fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff8262000172565b620001bd868362000172565b95508019841693508086168417925050509392505050565b6000819050919050565b6000819050919050565b60006200020a62000204620001fe84620001d5565b620001df565b620001d5565b9050919050565b6000819050919050565b6200022683620001e9565b6200023e620002358262000211565b8484546200017f565b825550505050565b600090565b6200025562000246565b620002628184846200021b565b505050565b5b818110156200028a576200027e6000826200024b565b60018101905062000268565b5050565b601f821115620002d957620002a3816200014d565b620002ae8462000162565b81016020851015620002be578190505b620002d6620002cd8562000162565b83018262000267565b50505b505050565b600082821c905092915050565b6000620002fe60001984600802620002de565b1980831691505092915050565b6000620003198383620002eb565b9150826002028217905092915050565b6200033482620000af565b67ffffffffffffffff81111562000350576200034f620000ba565b5b6200035c825462000118565b620003698282856200028e565b600060209050601f831160018114620003a157600084156200038c578287015190505b6200039885826200030b565b86555062000408565b601f198416620003b1866200014d565b60005b82811015620003db57848901518255600182019150602085019450602081019050620003b4565b86831015620003fb5784890151620003f7601f891682620002eb565b8355505b6001600288020188555050505b505050505050565b612ad580620004206000396000f3fe608060405234801561001057600080fd5b50600436106100f55760003560e01c80636352211e11610097578063b88d4fde11610066578063b88d4fde14610270578063c87b56dd1461028c578063e1f3ef1f146102bc578063e985e9c5146102d8576100f5565b80636352211e146101d657806370a082311461020657806395d89b4114610236578063a22cb46514610254576100f5565b8063095ea7b3116100d3578063095ea7b3146101785780631249c58b1461019457806323b872dd1461019e57806342842e0e146101ba576100f5565b806301ffc9a7146100fa57806306fdde031461012a578063081812fc14610148575b600080fd5b610114600480360381019061010f9190611a07565b610308565b6040516101219190611a4f565b60405180910390f35b61013261031a565b60405161013f9190611afa565b60405180910390f35b610162600480360381019061015d9190611b52565b6103ac565b60405161016f9190611bc0565b60405180910390f35b610192600480360381019061018d9190611c07565b6103f2565b005b61019c610509565b005b6101b860048036038101906101b39190611c47565b610557565b005b6101d460048036038101906101cf9190611c47565b6105b7565b005b6101f060048036038101906101eb9190611b52565b6105d7565b6040516101fd9190611bc0565b60405180910390f35b610220600480360381019061021b9190611c9a565b61065d565b60405161022d9190611cd6565b60405180910390f35b61023e610714565b60405161024b9190611afa565b60405180910390f35b61026e60048036038101906102699190611d1d565b6107a6565b005b61028a60048036038101906102859190611e92565b6107bc565b005b6102a660048036038101906102a19190611b52565b61081e565b6040516102b39190611afa565b60405180910390f35b6102d660048036038101906102d19190611c07565b610830565b005b6102f260048036038101906102ed9190611f15565b61083f565b6040516102ff9190611a4f565b60405180910390f35b6000610313826108d3565b9050919050565b60606000805461032990611f84565b80601f016020809104026020016040519081016040528092919081815260200182805461035590611f84565b80156103a25780601f10610377576101008083540402835291602001916103a2565b820191906000526020600020905b81548152906001019060200180831161038557829003601f168201915b5050505050905090565b60006103b782610934565b6004600083815260200190815260200160002060009054906101000a900473ffffffffffffffffffffffffffffffffffffffff169050919050565b60006103fd826105d7565b90508073ffffffffffffffffffffffffffffffffffffffff168373ffffffffffffffffffffffffffffffffffffffff160361046d576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040161046490612027565b60405180910390fd5b8073ffffffffffffffffffffffffffffffffffffffff1661048c61097f565b73ffffffffffffffffffffffffffffffffffffffff1614806104bb57506104ba816104b561097f565b61083f565b5b6104fa576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004016104f1906120b9565b60405180910390fd5b6105048383610987565b505050565b6007600081548092919061051c90612108565b9190505550600060075490506105323382610a40565b61055481604051806080016040528060438152602001612a5d60439139610c5d565b50565b61056861056261097f565b82610d01565b6105a7576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040161059e906121c2565b60405180910390fd5b6105b2838383610d96565b505050565b6105d2838383604051806020016040528060008152506107bc565b505050565b6000806105e38361108f565b9050600073ffffffffffffffffffffffffffffffffffffffff168173ffffffffffffffffffffffffffffffffffffffff1603610654576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040161064b9061222e565b60405180910390fd5b80915050919050565b60008073ffffffffffffffffffffffffffffffffffffffff168273ffffffffffffffffffffffffffffffffffffffff16036106cd576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004016106c4906122c0565b60405180910390fd5b600360008373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff168152602001908152602001600020549050919050565b60606001805461072390611f84565b80601f016020809104026020016040519081016040528092919081815260200182805461074f90611f84565b801561079c5780601f106107715761010080835404028352916020019161079c565b820191906000526020600020905b81548152906001019060200180831161077f57829003601f168201915b5050505050905090565b6107b86107b161097f565b83836110cc565b5050565b6107cd6107c761097f565b83610d01565b61080c576040517f08c379a0000000000000000000000000000000000000000000000000000000008152600401610803906121c2565b60405180910390fd5b61081884848484611238565b50505050565b606061082982611294565b9050919050565b61083b3383836105b7565b5050565b6000600560008473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200190815260200160002060008373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200190815260200160002060009054906101000a900460ff16905092915050565b6000634906490660e01b7bffffffffffffffffffffffffffffffffffffffffffffffffffffffff1916827bffffffffffffffffffffffffffffffffffffffffffffffffffffffff1916148061092d575061092c826113a6565b5b9050919050565b61093d81611488565b61097c576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004016109739061222e565b60405180910390fd5b50565b600033905090565b816004600083815260200190815260200160002060006101000a81548173ffffffffffffffffffffffffffffffffffffffff021916908373ffffffffffffffffffffffffffffffffffffffff160217905550808273ffffffffffffffffffffffffffffffffffffffff166109fa836105d7565b73ffffffffffffffffffffffffffffffffffffffff167f8c5be1e5ebec7d5bd14f71427d1e84f3dd0314c0f7b2291e5b200ac8c7c3b92560405160405180910390a45050565b600073ffffffffffffffffffffffffffffffffffffffff168273ffffffffffffffffffffffffffffffffffffffff1603610aaf576040517f08c379a0000000000000000000000000000000000000000000000000000000008152600401610aa69061232c565b60405180910390fd5b610ab881611488565b15610af8576040517f08c379a0000000000000000000000000000000000000000000000000000000008152600401610aef90612398565b60405180910390fd5b610b066000838360016114c9565b610b0f81611488565b15610b4f576040517f08c379a0000000000000000000000000000000000000000000000000000000008152600401610b4690612398565b60405180910390fd5b6001600360008473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200190815260200160002060008282540192505081905550816002600083815260200190815260200160002060006101000a81548173ffffffffffffffffffffffffffffffffffffffff021916908373ffffffffffffffffffffffffffffffffffffffff160217905550808273ffffffffffffffffffffffffffffffffffffffff16600073ffffffffffffffffffffffffffffffffffffffff167fddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef60405160405180910390a4610c596000838360016114db565b5050565b610c6682611488565b610ca5576040517f08c379a0000000000000000000000000000000000000000000000000000000008152600401610c9c9061242a565b60405180910390fd5b80600660008481526020019081526020016000209081610cc591906125f6565b507ff8e1a15aba9398e019f0b49df1a4fde98ee17ae345cb5f6b5e2c27f5033e8ce782604051610cf59190611cd6565b60405180910390a15050565b600080610d0d836105d7565b90508073ffffffffffffffffffffffffffffffffffffffff168473ffffffffffffffffffffffffffffffffffffffff161480610d4f5750610d4e818561083f565b5b80610d8d57508373ffffffffffffffffffffffffffffffffffffffff16610d75846103ac565b73ffffffffffffffffffffffffffffffffffffffff16145b91505092915050565b8273ffffffffffffffffffffffffffffffffffffffff16610db6826105d7565b73ffffffffffffffffffffffffffffffffffffffff1614610e0c576040517f08c379a0000000000000000000000000000000000000000000000000000000008152600401610e039061273a565b60405180910390fd5b600073ffffffffffffffffffffffffffffffffffffffff168273ffffffffffffffffffffffffffffffffffffffff1603610e7b576040517f08c379a0000000000000000000000000000000000000000000000000000000008152600401610e72906127cc565b60405180910390fd5b610e8883838360016114c9565b8273ffffffffffffffffffffffffffffffffffffffff16610ea8826105d7565b73ffffffffffffffffffffffffffffffffffffffff1614610efe576040517f08c379a0000000000000000000000000000000000000000000000000000000008152600401610ef59061273a565b60405180910390fd5b6004600082815260200190815260200160002060006101000a81549073ffffffffffffffffffffffffffffffffffffffff02191690556001600360008573ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff168152602001908152602001600020600082825403925050819055506001600360008473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200190815260200160002060008282540192505081905550816002600083815260200190815260200160002060006101000a81548173ffffffffffffffffffffffffffffffffffffffff021916908373ffffffffffffffffffffffffffffffffffffffff160217905550808273ffffffffffffffffffffffffffffffffffffffff168473ffffffffffffffffffffffffffffffffffffffff167fddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef60405160405180910390a461108a83838360016114db565b505050565b60006002600083815260200190815260200160002060009054906101000a900473ffffffffffffffffffffffffffffffffffffffff169050919050565b8173ffffffffffffffffffffffffffffffffffffffff168373ffffffffffffffffffffffffffffffffffffffff160361113a576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040161113190612838565b60405180910390fd5b80600560008573ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200190815260200160002060008473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200190815260200160002060006101000a81548160ff0219169083151502179055508173ffffffffffffffffffffffffffffffffffffffff168373ffffffffffffffffffffffffffffffffffffffff167f17307eab39ab6107e8899845ad3d59bd9653f200f220920489ca2b5937696c318360405161122b9190611a4f565b60405180910390a3505050565b611243848484610d96565b61124f848484846114e1565b61128e576040517f08c379a0000000000000000000000000000000000000000000000000000000008152600401611285906128ca565b60405180910390fd5b50505050565b606061129f82610934565b60006006600084815260200190815260200160002080546112bf90611f84565b80601f01602080910402602001604051908101604052809291908181526020018280546112eb90611f84565b80156113385780601f1061130d57610100808354040283529160200191611338565b820191906000526020600020905b81548152906001019060200180831161131b57829003601f168201915b505050505090506000611349611668565b9050600081510361135e5781925050506113a1565b60008251111561139357808260405160200161137b929190612926565b604051602081830303815290604052925050506113a1565b61139c8461167f565b925050505b919050565b60007f80ac58cd000000000000000000000000000000000000000000000000000000007bffffffffffffffffffffffffffffffffffffffffffffffffffffffff1916827bffffffffffffffffffffffffffffffffffffffffffffffffffffffff1916148061147157507f5b5e139f000000000000000000000000000000000000000000000000000000007bffffffffffffffffffffffffffffffffffffffffffffffffffffffff1916827bffffffffffffffffffffffffffffffffffffffffffffffffffffffff1916145b806114815750611480826116e7565b5b9050919050565b60008073ffffffffffffffffffffffffffffffffffffffff166114aa8361108f565b73ffffffffffffffffffffffffffffffffffffffff1614159050919050565b6114d584848484611751565b50505050565b50505050565b60006115028473ffffffffffffffffffffffffffffffffffffffff16611757565b1561165b578373ffffffffffffffffffffffffffffffffffffffff1663150b7a0261152b61097f565b8786866040518563ffffffff1660e01b815260040161154d949392919061299f565b6020604051808303816000875af192505050801561158957506040513d601f19601f820116820180604052508101906115869190612a00565b60015b61160b573d80600081146115b9576040519150601f19603f3d011682016040523d82523d6000602084013e6115be565b606091505b506000815103611603576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004016115fa906128ca565b60405180910390fd5b805181602001fd5b63150b7a0260e01b7bffffffffffffffffffffffffffffffffffffffffffffffffffffffff1916817bffffffffffffffffffffffffffffffffffffffffffffffffffffffff191614915050611660565b600190505b949350505050565b606060405180602001604052806000815250905090565b606061168a82610934565b6000611694611668565b905060008151116116b457604051806020016040528060008152506116df565b806116be8461177a565b6040516020016116cf929190612926565b6040516020818303038152906040525b915050919050565b60007f01ffc9a7000000000000000000000000000000000000000000000000000000007bffffffffffffffffffffffffffffffffffffffffffffffffffffffff1916827bffffffffffffffffffffffffffffffffffffffffffffffffffffffff1916149050919050565b50505050565b6000808273ffffffffffffffffffffffffffffffffffffffff163b119050919050565b60606000600161178984611848565b01905060008167ffffffffffffffff8111156117a8576117a7611d67565b5b6040519080825280601f01601f1916602001820160405280156117da5781602001600182028036833780820191505090505b509050600082602001820190505b60011561183d578080600190039150507f3031323334353637383961626364656600000000000000000000000000000000600a86061a8153600a858161183157611830612a2d565b5b049450600085036117e8575b819350505050919050565b600080600090507a184f03e93ff9f4daa797ed6e38ed64bf6a1f01000000000000000083106118a6577a184f03e93ff9f4daa797ed6e38ed64bf6a1f010000000000000000838161189c5761189b612a2d565b5b0492506040810190505b6d04ee2d6d415b85acef810000000083106118e3576d04ee2d6d415b85acef810000000083816118d9576118d8612a2d565b5b0492506020810190505b662386f26fc10000831061191257662386f26fc10000838161190857611907612a2d565b5b0492506010810190505b6305f5e100831061193b576305f5e100838161193157611930612a2d565b5b0492506008810190505b612710831061196057612710838161195657611955612a2d565b5b0492506004810190505b60648310611983576064838161197957611978612a2d565b5b0492506002810190505b600a8310611992576001810190505b80915050919050565b6000604051905090565b600080fd5b600080fd5b60007fffffffff0000000000000000000000000000000000000000000000000000000082169050919050565b6119e4816119af565b81146119ef57600080fd5b50565b600081359050611a01816119db565b92915050565b600060208284031215611a1d57611a1c6119a5565b5b6000611a2b848285016119f2565b91505092915050565b60008115159050919050565b611a4981611a34565b82525050565b6000602082019050611a646000830184611a40565b92915050565b600081519050919050565b600082825260208201905092915050565b60005b83811015611aa4578082015181840152602081019050611a89565b60008484015250505050565b6000601f19601f8301169050919050565b6000611acc82611a6a565b611ad68185611a75565b9350611ae6818560208601611a86565b611aef81611ab0565b840191505092915050565b60006020820190508181036000830152611b148184611ac1565b905092915050565b6000819050919050565b611b2f81611b1c565b8114611b3a57600080fd5b50565b600081359050611b4c81611b26565b92915050565b600060208284031215611b6857611b676119a5565b5b6000611b7684828501611b3d565b91505092915050565b600073ffffffffffffffffffffffffffffffffffffffff82169050919050565b6000611baa82611b7f565b9050919050565b611bba81611b9f565b82525050565b6000602082019050611bd56000830184611bb1565b92915050565b611be481611b9f565b8114611bef57600080fd5b50565b600081359050611c0181611bdb565b92915050565b60008060408385031215611c1e57611c1d6119a5565b5b6000611c2c85828601611bf2565b9250506020611c3d85828601611b3d565b9150509250929050565b600080600060608486031215611c6057611c5f6119a5565b5b6000611c6e86828701611bf2565b9350506020611c7f86828701611bf2565b9250506040611c9086828701611b3d565b9150509250925092565b600060208284031215611cb057611caf6119a5565b5b6000611cbe84828501611bf2565b91505092915050565b611cd081611b1c565b82525050565b6000602082019050611ceb6000830184611cc7565b92915050565b611cfa81611a34565b8114611d0557600080fd5b50565b600081359050611d1781611cf1565b92915050565b60008060408385031215611d3457611d336119a5565b5b6000611d4285828601611bf2565b9250506020611d5385828601611d08565b9150509250929050565b600080fd5b600080fd5b7f4e487b7100000000000000000000000000000000000000000000000000000000600052604160045260246000fd5b611d9f82611ab0565b810181811067ffffffffffffffff82111715611dbe57611dbd611d67565b5b80604052505050565b6000611dd161199b565b9050611ddd8282611d96565b919050565b600067ffffffffffffffff821115611dfd57611dfc611d67565b5b611e0682611ab0565b9050602081019050919050565b82818337600083830152505050565b6000611e35611e3084611de2565b611dc7565b905082815260208101848484011115611e5157611e50611d62565b5b611e5c848285611e13565b509392505050565b600082601f830112611e7957611e78611d5d565b5b8135611e89848260208601611e22565b91505092915050565b60008060008060808587031215611eac57611eab6119a5565b5b6000611eba87828801611bf2565b9450506020611ecb87828801611bf2565b9350506040611edc87828801611b3d565b925050606085013567ffffffffffffffff811115611efd57611efc6119aa565b5b611f0987828801611e64565b91505092959194509250565b60008060408385031215611f2c57611f2b6119a5565b5b6000611f3a85828601611bf2565b9250506020611f4b85828601611bf2565b9150509250929050565b7f4e487b7100000000000000000000000000000000000000000000000000000000600052602260045260246000fd5b60006002820490506001821680611f9c57607f821691505b602082108103611faf57611fae611f55565b5b50919050565b7f4552433732313a20617070726f76616c20746f2063757272656e74206f776e6560008201527f7200000000000000000000000000000000000000000000000000000000000000602082015250565b6000612011602183611a75565b915061201c82611fb5565b604082019050919050565b6000602082019050818103600083015261204081612004565b9050919050565b7f4552433732313a20617070726f76652063616c6c6572206973206e6f7420746f60008201527f6b656e206f776e6572206f7220617070726f76656420666f7220616c6c000000602082015250565b60006120a3603d83611a75565b91506120ae82612047565b604082019050919050565b600060208201905081810360008301526120d281612096565b9050919050565b7f4e487b7100000000000000000000000000000000000000000000000000000000600052601160045260246000fd5b600061211382611b1c565b91507fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff8203612145576121446120d9565b5b600182019050919050565b7f4552433732313a2063616c6c6572206973206e6f7420746f6b656e206f776e6560008201527f72206f7220617070726f76656400000000000000000000000000000000000000602082015250565b60006121ac602d83611a75565b91506121b782612150565b604082019050919050565b600060208201905081810360008301526121db8161219f565b9050919050565b7f4552433732313a20696e76616c696420746f6b656e2049440000000000000000600082015250565b6000612218601883611a75565b9150612223826121e2565b602082019050919050565b600060208201905081810360008301526122478161220b565b9050919050565b7f4552433732313a2061646472657373207a65726f206973206e6f74206120766160008201527f6c6964206f776e65720000000000000000000000000000000000000000000000602082015250565b60006122aa602983611a75565b91506122b58261224e565b604082019050919050565b600060208201905081810360008301526122d98161229d565b9050919050565b7f4552433732313a206d696e7420746f20746865207a65726f2061646472657373600082015250565b6000612316602083611a75565b9150612321826122e0565b602082019050919050565b6000602082019050818103600083015261234581612309565b9050919050565b7f4552433732313a20746f6b656e20616c7265616479206d696e74656400000000600082015250565b6000612382601c83611a75565b915061238d8261234c565b602082019050919050565b600060208201905081810360008301526123b181612375565b9050919050565b7f45524337323155524953746f726167653a2055524920736574206f66206e6f6e60008201527f6578697374656e7420746f6b656e000000000000000000000000000000000000602082015250565b6000612414602e83611a75565b915061241f826123b8565b604082019050919050565b6000602082019050818103600083015261244381612407565b9050919050565b60008190508160005260206000209050919050565b60006020601f8301049050919050565b600082821b905092915050565b6000600883026124ac7fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff8261246f565b6124b6868361246f565b95508019841693508086168417925050509392505050565b6000819050919050565b60006124f36124ee6124e984611b1c565b6124ce565b611b1c565b9050919050565b6000819050919050565b61250d836124d8565b612521612519826124fa565b84845461247c565b825550505050565b600090565b612536612529565b612541818484612504565b505050565b5b818110156125655761255a60008261252e565b600181019050612547565b5050565b601f8211156125aa5761257b8161244a565b6125848461245f565b81016020851015612593578190505b6125a761259f8561245f565b830182612546565b50505b505050565b600082821c905092915050565b60006125cd600019846008026125af565b1980831691505092915050565b60006125e683836125bc565b9150826002028217905092915050565b6125ff82611a6a565b67ffffffffffffffff81111561261857612617611d67565b5b6126228254611f84565b61262d828285612569565b600060209050601f831160018114612660576000841561264e578287015190505b61265885826125da565b8655506126c0565b601f19841661266e8661244a565b60005b8281101561269657848901518255600182019150602085019450602081019050612671565b868310156126b357848901516126af601f8916826125bc565b8355505b6001600288020188555050505b505050505050565b7f4552433732313a207472616e736665722066726f6d20696e636f72726563742060008201527f6f776e6572000000000000000000000000000000000000000000000000000000602082015250565b6000612724602583611a75565b915061272f826126c8565b604082019050919050565b6000602082019050818103600083015261275381612717565b9050919050565b7f4552433732313a207472616e7366657220746f20746865207a65726f2061646460008201527f7265737300000000000000000000000000000000000000000000000000000000602082015250565b60006127b6602483611a75565b91506127c18261275a565b604082019050919050565b600060208201905081810360008301526127e5816127a9565b9050919050565b7f4552433732313a20617070726f766520746f2063616c6c657200000000000000600082015250565b6000612822601983611a75565b915061282d826127ec565b602082019050919050565b6000602082019050818103600083015261285181612815565b9050919050565b7f4552433732313a207472616e7366657220746f206e6f6e20455243373231526560008201527f63656976657220696d706c656d656e7465720000000000000000000000000000602082015250565b60006128b4603283611a75565b91506128bf82612858565b604082019050919050565b600060208201905081810360008301526128e3816128a7565b9050919050565b600081905092915050565b600061290082611a6a565b61290a81856128ea565b935061291a818560208601611a86565b80840191505092915050565b600061293282856128f5565b915061293e82846128f5565b91508190509392505050565b600081519050919050565b600082825260208201905092915050565b60006129718261294a565b61297b8185612955565b935061298b818560208601611a86565b61299481611ab0565b840191505092915050565b60006080820190506129b46000830187611bb1565b6129c16020830186611bb1565b6129ce6040830185611cc7565b81810360608301526129e08184612966565b905095945050505050565b6000815190506129fa816119db565b92915050565b600060208284031215612a1657612a156119a5565b5b6000612a24848285016129eb565b91505092915050565b7f4e487b7100000000000000000000000000000000000000000000000000000000600052601260045260246000fdfe68747470733a2f2f697066732e696f2f697066732f516d5a5359656a7067484c64616f3164413865766a66637a4d4b6d5a544543316b4244664243456b354c34705278a2646970667358221220656734ba552a4dbbe52320b104d290624bdd1ec1afbfb4fc7ab57319dddc4ed964736f6c63430008130033"

export const byteCode1155 = "0x60806040526040518060400160405280600881526020017f436172746f6f6e73000000000000000000000000000000000000000000000000815250600390816200004a91906200035c565b506040518060400160405280600381526020017f43544e0000000000000000000000000000000000000000000000000000000000815250600490816200009191906200035c565b506000600555348015620000a457600080fd5b5060405180602001604052806000815250620000c681620000cd60201b60201c565b5062000443565b8060029081620000de91906200035c565b5050565b600081519050919050565b7f4e487b7100000000000000000000000000000000000000000000000000000000600052604160045260246000fd5b7f4e487b7100000000000000000000000000000000000000000000000000000000600052602260045260246000fd5b600060028204905060018216806200016457607f821691505b6020821081036200017a57620001796200011c565b5b50919050565b60008190508160005260206000209050919050565b60006020601f8301049050919050565b600082821b905092915050565b600060088302620001e47fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff82620001a5565b620001f08683620001a5565b95508019841693508086168417925050509392505050565b6000819050919050565b6000819050919050565b60006200023d62000237620002318462000208565b62000212565b62000208565b9050919050565b6000819050919050565b62000259836200021c565b62000271620002688262000244565b848454620001b2565b825550505050565b600090565b6200028862000279565b620002958184846200024e565b505050565b5b81811015620002bd57620002b16000826200027e565b6001810190506200029b565b5050565b601f8211156200030c57620002d68162000180565b620002e18462000195565b81016020851015620002f1578190505b62000309620003008562000195565b8301826200029a565b50505b505050565b600082821c905092915050565b6000620003316000198460080262000311565b1980831691505092915050565b60006200034c83836200031e565b9150826002028217905092915050565b6200036782620000e2565b67ffffffffffffffff811115620003835762000382620000ed565b5b6200038f82546200014b565b6200039c828285620002c1565b600060209050601f831160018114620003d45760008415620003bf578287015190505b620003cb85826200033e565b8655506200043b565b601f198416620003e48662000180565b60005b828110156200040e57848901518255600182019150602085019450602081019050620003e7565b868310156200042e57848901516200042a601f8916826200031e565b8355505b6001600288020188555050505b505050505050565b612f3b80620004536000396000f3fe608060405234801561001057600080fd5b50600436106100a85760003560e01c80634e1273f4116100715780634e1273f41461017757806360b47a50146101a757806395d89b41146101c3578063a22cb465146101e1578063e985e9c5146101fd578063f242432a1461022d576100a8565b8062fdd58e146100ad57806301ffc9a7146100dd57806306fdde031461010d5780630e89341c1461012b5780632eb2c2d61461015b575b600080fd5b6100c760048036038101906100c29190611925565b610249565b6040516100d49190611974565b60405180910390f35b6100f760048036038101906100f291906119e7565b610311565b6040516101049190611a2f565b60405180910390f35b6101156103f3565b6040516101229190611ada565b60405180910390f35b61014560048036038101906101409190611afc565b610481565b6040516101529190611ada565b60405180910390f35b61017560048036038101906101709190611d26565b6104b2565b005b610191600480360381019061018c9190611eb8565b610553565b60405161019e9190611fee565b60405180910390f35b6101c160048036038101906101bc9190611afc565b61066c565b005b6101cb6106cb565b6040516101d89190611ada565b60405180910390f35b6101fb60048036038101906101f6919061203c565b610759565b005b6102176004803603810190610212919061207c565b61076f565b6040516102249190611a2f565b60405180910390f35b610247600480360381019061024291906120bc565b610803565b005b60008073ffffffffffffffffffffffffffffffffffffffff168373ffffffffffffffffffffffffffffffffffffffff16036102b9576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004016102b0906121c5565b60405180910390fd5b60008083815260200190815260200160002060008473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200190815260200160002054905092915050565b60007fd9b67a26000000000000000000000000000000000000000000000000000000007bffffffffffffffffffffffffffffffffffffffffffffffffffffffff1916827bffffffffffffffffffffffffffffffffffffffffffffffffffffffff191614806103dc57507f0e89341c000000000000000000000000000000000000000000000000000000007bffffffffffffffffffffffffffffffffffffffffffffffffffffffff1916827bffffffffffffffffffffffffffffffffffffffffffffffffffffffff1916145b806103ec57506103eb826108a4565b5b9050919050565b6003805461040090612214565b80601f016020809104026020016040519081016040528092919081815260200182805461042c90612214565b80156104795780601f1061044e57610100808354040283529160200191610479565b820191906000526020600020905b81548152906001019060200180831161045c57829003601f168201915b505050505081565b606061048c8261090e565b60405160200161049c9190612365565b6040516020818303038152906040529050919050565b6104ba6109dc565b73ffffffffffffffffffffffffffffffffffffffff168573ffffffffffffffffffffffffffffffffffffffff16148061050057506104ff856104fa6109dc565b61076f565b5b61053f576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040161053690612404565b60405180910390fd5b61054c85858585856109e4565b5050505050565b60608151835114610599576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040161059090612496565b60405180910390fd5b6000835167ffffffffffffffff8111156105b6576105b5611b2e565b5b6040519080825280602002602001820160405280156105e45781602001602082028036833780820191505090505b50905060005b845181101561066157610631858281518110610609576106086124b6565b5b6020026020010151858381518110610624576106236124b6565b5b6020026020010151610249565b828281518110610644576106436124b6565b5b6020026020010181815250508061065a90612514565b90506105ea565b508091505092915050565b6005600081548092919061067f90612514565b9190505550600060055490506106a633828460405180602001604052806000815250610d05565b6106c7604051806080016040528060438152602001612ec360439139610eb5565b5050565b600480546106d890612214565b80601f016020809104026020016040519081016040528092919081815260200182805461070490612214565b80156107515780601f1061072657610100808354040283529160200191610751565b820191906000526020600020905b81548152906001019060200180831161073457829003601f168201915b505050505081565b61076b6107646109dc565b8383610ec8565b5050565b6000600160008473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200190815260200160002060008373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200190815260200160002060009054906101000a900460ff16905092915050565b61080b6109dc565b73ffffffffffffffffffffffffffffffffffffffff168573ffffffffffffffffffffffffffffffffffffffff16148061085157506108508561084b6109dc565b61076f565b5b610890576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040161088790612404565b60405180910390fd5b61089d8585858585611034565b5050505050565b60007f01ffc9a7000000000000000000000000000000000000000000000000000000007bffffffffffffffffffffffffffffffffffffffffffffffffffffffff1916827bffffffffffffffffffffffffffffffffffffffffffffffffffffffff1916149050919050565b60606000600161091d846112cf565b01905060008167ffffffffffffffff81111561093c5761093b611b2e565b5b6040519080825280601f01601f19166020018201604052801561096e5781602001600182028036833780820191505090505b509050600082602001820190505b6001156109d1578080600190039150507f3031323334353637383961626364656600000000000000000000000000000000600a86061a8153600a85816109c5576109c461255c565b5b0494506000850361097c575b819350505050919050565b600033905090565b8151835114610a28576040517f08c379a0000000000000000000000000000000000000000000000000000000008152600401610a1f906125fd565b60405180910390fd5b600073ffffffffffffffffffffffffffffffffffffffff168473ffffffffffffffffffffffffffffffffffffffff1603610a97576040517f08c379a0000000000000000000000000000000000000000000000000000000008152600401610a8e9061268f565b60405180910390fd5b6000610aa16109dc565b9050610ab1818787878787611422565b60005b8451811015610c62576000858281518110610ad257610ad16124b6565b5b602002602001015190506000858381518110610af157610af06124b6565b5b60200260200101519050600080600084815260200190815260200160002060008b73ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200190815260200160002054905081811015610b92576040517f08c379a0000000000000000000000000000000000000000000000000000000008152600401610b8990612721565b60405180910390fd5b81810360008085815260200190815260200160002060008c73ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff168152602001908152602001600020819055508160008085815260200190815260200160002060008b73ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1681526020019081526020016000206000828254610c479190612741565b9250508190555050505080610c5b90612514565b9050610ab4565b508473ffffffffffffffffffffffffffffffffffffffff168673ffffffffffffffffffffffffffffffffffffffff168273ffffffffffffffffffffffffffffffffffffffff167f4a39dc06d4c0dbc64b70af90fd698a233a518aa5d07e595d983b8c0526c8f7fb8787604051610cd9929190612775565b60405180910390a4610cef81878787878761142a565b610cfd818787878787611432565b505050505050565b600073ffffffffffffffffffffffffffffffffffffffff168473ffffffffffffffffffffffffffffffffffffffff1603610d74576040517f08c379a0000000000000000000000000000000000000000000000000000000008152600401610d6b9061281e565b60405180910390fd5b6000610d7e6109dc565b90506000610d8b85611609565b90506000610d9885611609565b9050610da983600089858589611422565b8460008088815260200190815260200160002060008973ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1681526020019081526020016000206000828254610e089190612741565b925050819055508673ffffffffffffffffffffffffffffffffffffffff16600073ffffffffffffffffffffffffffffffffffffffff168473ffffffffffffffffffffffffffffffffffffffff167fc3d58168c5ae7397731d063d5bbf3d657854427343f4c083240f7aacaa2d0f628989604051610e8692919061283e565b60405180910390a4610e9d8360008985858961142a565b610eac83600089898989611683565b50505050505050565b8060029081610ec49190612a13565b5050565b8173ffffffffffffffffffffffffffffffffffffffff168373ffffffffffffffffffffffffffffffffffffffff1603610f36576040517f08c379a0000000000000000000000000000000000000000000000000000000008152600401610f2d90612b57565b60405180910390fd5b80600160008573ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200190815260200160002060008473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200190815260200160002060006101000a81548160ff0219169083151502179055508173ffffffffffffffffffffffffffffffffffffffff168373ffffffffffffffffffffffffffffffffffffffff167f17307eab39ab6107e8899845ad3d59bd9653f200f220920489ca2b5937696c31836040516110279190611a2f565b60405180910390a3505050565b600073ffffffffffffffffffffffffffffffffffffffff168473ffffffffffffffffffffffffffffffffffffffff16036110a3576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040161109a9061268f565b60405180910390fd5b60006110ad6109dc565b905060006110ba85611609565b905060006110c785611609565b90506110d7838989858589611422565b600080600088815260200190815260200160002060008a73ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1681526020019081526020016000205490508581101561116e576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040161116590612721565b60405180910390fd5b85810360008089815260200190815260200160002060008b73ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff168152602001908152602001600020819055508560008089815260200190815260200160002060008a73ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200190815260200160002060008282546112239190612741565b925050819055508773ffffffffffffffffffffffffffffffffffffffff168973ffffffffffffffffffffffffffffffffffffffff168573ffffffffffffffffffffffffffffffffffffffff167fc3d58168c5ae7397731d063d5bbf3d657854427343f4c083240f7aacaa2d0f628a8a6040516112a092919061283e565b60405180910390a46112b6848a8a86868a61142a565b6112c4848a8a8a8a8a611683565b505050505050505050565b600080600090507a184f03e93ff9f4daa797ed6e38ed64bf6a1f010000000000000000831061132d577a184f03e93ff9f4daa797ed6e38ed64bf6a1f01000000000000000083816113235761132261255c565b5b0492506040810190505b6d04ee2d6d415b85acef8100000000831061136a576d04ee2d6d415b85acef810000000083816113605761135f61255c565b5b0492506020810190505b662386f26fc10000831061139957662386f26fc10000838161138f5761138e61255c565b5b0492506010810190505b6305f5e10083106113c2576305f5e10083816113b8576113b761255c565b5b0492506008810190505b61271083106113e75761271083816113dd576113dc61255c565b5b0492506004810190505b6064831061140a5760648381611400576113ff61255c565b5b0492506002810190505b600a8310611419576001810190505b80915050919050565b505050505050565b505050505050565b6114518473ffffffffffffffffffffffffffffffffffffffff1661185a565b15611601578373ffffffffffffffffffffffffffffffffffffffff1663bc197c8187878686866040518663ffffffff1660e01b8152600401611497959493929190612bdb565b6020604051808303816000875af19250505080156114d357506040513d601f19601f820116820180604052508101906114d09190612c58565b60015b611578576114df612c92565b806308c379a00361153b57506114f3612cb4565b806114fe575061153d565b806040517f08c379a00000000000000000000000000000000000000000000000000000000081526004016115329190611ada565b60405180910390fd5b505b6040517f08c379a000000000000000000000000000000000000000000000000000000000815260040161156f90612db6565b60405180910390fd5b63bc197c8160e01b7bffffffffffffffffffffffffffffffffffffffffffffffffffffffff1916817bffffffffffffffffffffffffffffffffffffffffffffffffffffffff1916146115ff576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004016115f690612e48565b60405180910390fd5b505b505050505050565b60606000600167ffffffffffffffff81111561162857611627611b2e565b5b6040519080825280602002602001820160405280156116565781602001602082028036833780820191505090505b509050828160008151811061166e5761166d6124b6565b5b60200260200101818152505080915050919050565b6116a28473ffffffffffffffffffffffffffffffffffffffff1661185a565b15611852578373ffffffffffffffffffffffffffffffffffffffff1663f23a6e6187878686866040518663ffffffff1660e01b81526004016116e8959493929190612e68565b6020604051808303816000875af192505050801561172457506040513d601f19601f820116820180604052508101906117219190612c58565b60015b6117c957611730612c92565b806308c379a00361178c5750611744612cb4565b8061174f575061178e565b806040517f08c379a00000000000000000000000000000000000000000000000000000000081526004016117839190611ada565b60405180910390fd5b505b6040517f08c379a00000000000000000000000000000000000000000000000000000000081526004016117c090612db6565b60405180910390fd5b63f23a6e6160e01b7bffffffffffffffffffffffffffffffffffffffffffffffffffffffff1916817bffffffffffffffffffffffffffffffffffffffffffffffffffffffff191614611850576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040161184790612e48565b60405180910390fd5b505b505050505050565b6000808273ffffffffffffffffffffffffffffffffffffffff163b119050919050565b6000604051905090565b600080fd5b600080fd5b600073ffffffffffffffffffffffffffffffffffffffff82169050919050565b60006118bc82611891565b9050919050565b6118cc816118b1565b81146118d757600080fd5b50565b6000813590506118e9816118c3565b92915050565b6000819050919050565b611902816118ef565b811461190d57600080fd5b50565b60008135905061191f816118f9565b92915050565b6000806040838503121561193c5761193b611887565b5b600061194a858286016118da565b925050602061195b85828601611910565b9150509250929050565b61196e816118ef565b82525050565b60006020820190506119896000830184611965565b92915050565b60007fffffffff0000000000000000000000000000000000000000000000000000000082169050919050565b6119c48161198f565b81146119cf57600080fd5b50565b6000813590506119e1816119bb565b92915050565b6000602082840312156119fd576119fc611887565b5b6000611a0b848285016119d2565b91505092915050565b60008115159050919050565b611a2981611a14565b82525050565b6000602082019050611a446000830184611a20565b92915050565b600081519050919050565b600082825260208201905092915050565b60005b83811015611a84578082015181840152602081019050611a69565b60008484015250505050565b6000601f19601f8301169050919050565b6000611aac82611a4a565b611ab68185611a55565b9350611ac6818560208601611a66565b611acf81611a90565b840191505092915050565b60006020820190508181036000830152611af48184611aa1565b905092915050565b600060208284031215611b1257611b11611887565b5b6000611b2084828501611910565b91505092915050565b600080fd5b7f4e487b7100000000000000000000000000000000000000000000000000000000600052604160045260246000fd5b611b6682611a90565b810181811067ffffffffffffffff82111715611b8557611b84611b2e565b5b80604052505050565b6000611b9861187d565b9050611ba48282611b5d565b919050565b600067ffffffffffffffff821115611bc457611bc3611b2e565b5b602082029050602081019050919050565b600080fd5b6000611bed611be884611ba9565b611b8e565b90508083825260208201905060208402830185811115611c1057611c0f611bd5565b5b835b81811015611c395780611c258882611910565b845260208401935050602081019050611c12565b5050509392505050565b600082601f830112611c5857611c57611b29565b5b8135611c68848260208601611bda565b91505092915050565b600080fd5b600067ffffffffffffffff821115611c9157611c90611b2e565b5b611c9a82611a90565b9050602081019050919050565b82818337600083830152505050565b6000611cc9611cc484611c76565b611b8e565b905082815260208101848484011115611ce557611ce4611c71565b5b611cf0848285611ca7565b509392505050565b600082601f830112611d0d57611d0c611b29565b5b8135611d1d848260208601611cb6565b91505092915050565b600080600080600060a08688031215611d4257611d41611887565b5b6000611d50888289016118da565b9550506020611d61888289016118da565b945050604086013567ffffffffffffffff811115611d8257611d8161188c565b5b611d8e88828901611c43565b935050606086013567ffffffffffffffff811115611daf57611dae61188c565b5b611dbb88828901611c43565b925050608086013567ffffffffffffffff811115611ddc57611ddb61188c565b5b611de888828901611cf8565b9150509295509295909350565b600067ffffffffffffffff821115611e1057611e0f611b2e565b5b602082029050602081019050919050565b6000611e34611e2f84611df5565b611b8e565b90508083825260208201905060208402830185811115611e5757611e56611bd5565b5b835b81811015611e805780611e6c88826118da565b845260208401935050602081019050611e59565b5050509392505050565b600082601f830112611e9f57611e9e611b29565b5b8135611eaf848260208601611e21565b91505092915050565b60008060408385031215611ecf57611ece611887565b5b600083013567ffffffffffffffff811115611eed57611eec61188c565b5b611ef985828601611e8a565b925050602083013567ffffffffffffffff811115611f1a57611f1961188c565b5b611f2685828601611c43565b9150509250929050565b600081519050919050565b600082825260208201905092915050565b6000819050602082019050919050565b611f65816118ef565b82525050565b6000611f778383611f5c565b60208301905092915050565b6000602082019050919050565b6000611f9b82611f30565b611fa58185611f3b565b9350611fb083611f4c565b8060005b83811015611fe1578151611fc88882611f6b565b9750611fd383611f83565b925050600181019050611fb4565b5085935050505092915050565b600060208201905081810360008301526120088184611f90565b905092915050565b61201981611a14565b811461202457600080fd5b50565b60008135905061203681612010565b92915050565b6000806040838503121561205357612052611887565b5b6000612061858286016118da565b925050602061207285828601612027565b9150509250929050565b6000806040838503121561209357612092611887565b5b60006120a1858286016118da565b92505060206120b2858286016118da565b9150509250929050565b600080600080600060a086880312156120d8576120d7611887565b5b60006120e6888289016118da565b95505060206120f7888289016118da565b945050604061210888828901611910565b935050606061211988828901611910565b925050608086013567ffffffffffffffff81111561213a5761213961188c565b5b61214688828901611cf8565b9150509295509295909350565b7f455243313135353a2061646472657373207a65726f206973206e6f742061207660008201527f616c6964206f776e657200000000000000000000000000000000000000000000602082015250565b60006121af602a83611a55565b91506121ba82612153565b604082019050919050565b600060208201905081810360008301526121de816121a2565b9050919050565b7f4e487b7100000000000000000000000000000000000000000000000000000000600052602260045260246000fd5b6000600282049050600182168061222c57607f821691505b60208210810361223f5761223e6121e5565b5b50919050565b600081905092915050565b7f68747470733a2f2f697066732e696f2f697066732f516d643872515a4132626360008201527f4a725157525961355477587755483435336b32486f72336761564d4e5139764c60208201527f4565712f00000000000000000000000000000000000000000000000000000000604082015250565b60006122d2604483612245565b91506122dd82612250565b604482019050919050565b60006122f382611a4a565b6122fd8185612245565b935061230d818560208601611a66565b80840191505092915050565b7f2e6a736f6e000000000000000000000000000000000000000000000000000000600082015250565b600061234f600583612245565b915061235a82612319565b600582019050919050565b6000612370826122c5565b915061237c82846122e8565b915061238782612342565b915081905092915050565b7f455243313135353a2063616c6c6572206973206e6f7420746f6b656e206f776e60008201527f6572206f7220617070726f766564000000000000000000000000000000000000602082015250565b60006123ee602e83611a55565b91506123f982612392565b604082019050919050565b6000602082019050818103600083015261241d816123e1565b9050919050565b7f455243313135353a206163636f756e747320616e6420696473206c656e67746860008201527f206d69736d617463680000000000000000000000000000000000000000000000602082015250565b6000612480602983611a55565b915061248b82612424565b604082019050919050565b600060208201905081810360008301526124af81612473565b9050919050565b7f4e487b7100000000000000000000000000000000000000000000000000000000600052603260045260246000fd5b7f4e487b7100000000000000000000000000000000000000000000000000000000600052601160045260246000fd5b600061251f826118ef565b91507fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff8203612551576125506124e5565b5b600182019050919050565b7f4e487b7100000000000000000000000000000000000000000000000000000000600052601260045260246000fd5b7f455243313135353a2069647320616e6420616d6f756e7473206c656e6774682060008201527f6d69736d61746368000000000000000000000000000000000000000000000000602082015250565b60006125e7602883611a55565b91506125f28261258b565b604082019050919050565b60006020820190508181036000830152612616816125da565b9050919050565b7f455243313135353a207472616e7366657220746f20746865207a65726f20616460008201527f6472657373000000000000000000000000000000000000000000000000000000602082015250565b6000612679602583611a55565b91506126848261261d565b604082019050919050565b600060208201905081810360008301526126a88161266c565b9050919050565b7f455243313135353a20696e73756666696369656e742062616c616e636520666f60008201527f72207472616e7366657200000000000000000000000000000000000000000000602082015250565b600061270b602a83611a55565b9150612716826126af565b604082019050919050565b6000602082019050818103600083015261273a816126fe565b9050919050565b600061274c826118ef565b9150612757836118ef565b925082820190508082111561276f5761276e6124e5565b5b92915050565b6000604082019050818103600083015261278f8185611f90565b905081810360208301526127a38184611f90565b90509392505050565b7f455243313135353a206d696e7420746f20746865207a65726f2061646472657360008201527f7300000000000000000000000000000000000000000000000000000000000000602082015250565b6000612808602183611a55565b9150612813826127ac565b604082019050919050565b60006020820190508181036000830152612837816127fb565b9050919050565b60006040820190506128536000830185611965565b6128606020830184611965565b9392505050565b60008190508160005260206000209050919050565b60006020601f8301049050919050565b600082821b905092915050565b6000600883026128c97fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff8261288c565b6128d3868361288c565b95508019841693508086168417925050509392505050565b6000819050919050565b600061291061290b612906846118ef565b6128eb565b6118ef565b9050919050565b6000819050919050565b61292a836128f5565b61293e61293682612917565b848454612899565b825550505050565b600090565b612953612946565b61295e818484612921565b505050565b5b818110156129825761297760008261294b565b600181019050612964565b5050565b601f8211156129c75761299881612867565b6129a18461287c565b810160208510156129b0578190505b6129c46129bc8561287c565b830182612963565b50505b505050565b600082821c905092915050565b60006129ea600019846008026129cc565b1980831691505092915050565b6000612a0383836129d9565b9150826002028217905092915050565b612a1c82611a4a565b67ffffffffffffffff811115612a3557612a34611b2e565b5b612a3f8254612214565b612a4a828285612986565b600060209050601f831160018114612a7d5760008415612a6b578287015190505b612a7585826129f7565b865550612add565b601f198416612a8b86612867565b60005b82811015612ab357848901518255600182019150602085019450602081019050612a8e565b86831015612ad05784890151612acc601f8916826129d9565b8355505b6001600288020188555050505b505050505050565b7f455243313135353a2073657474696e6720617070726f76616c2073746174757360008201527f20666f722073656c660000000000000000000000000000000000000000000000602082015250565b6000612b41602983611a55565b9150612b4c82612ae5565b604082019050919050565b60006020820190508181036000830152612b7081612b34565b9050919050565b612b80816118b1565b82525050565b600081519050919050565b600082825260208201905092915050565b6000612bad82612b86565b612bb78185612b91565b9350612bc7818560208601611a66565b612bd081611a90565b840191505092915050565b600060a082019050612bf06000830188612b77565b612bfd6020830187612b77565b8181036040830152612c0f8186611f90565b90508181036060830152612c238185611f90565b90508181036080830152612c378184612ba2565b90509695505050505050565b600081519050612c52816119bb565b92915050565b600060208284031215612c6e57612c6d611887565b5b6000612c7c84828501612c43565b91505092915050565b60008160e01c9050919050565b600060033d1115612cb15760046000803e612cae600051612c85565b90505b90565b600060443d10612d4157612cc661187d565b60043d036004823e80513d602482011167ffffffffffffffff82111715612cee575050612d41565b808201805167ffffffffffffffff811115612d0c5750505050612d41565b80602083010160043d038501811115612d29575050505050612d41565b612d3882602001850186611b5d565b82955050505050505b90565b7f455243313135353a207472616e7366657220746f206e6f6e2d4552433131353560008201527f526563656976657220696d706c656d656e746572000000000000000000000000602082015250565b6000612da0603483611a55565b9150612dab82612d44565b604082019050919050565b60006020820190508181036000830152612dcf81612d93565b9050919050565b7f455243313135353a204552433131353552656365697665722072656a6563746560008201527f6420746f6b656e73000000000000000000000000000000000000000000000000602082015250565b6000612e32602883611a55565b9150612e3d82612dd6565b604082019050919050565b60006020820190508181036000830152612e6181612e25565b9050919050565b600060a082019050612e7d6000830188612b77565b612e8a6020830187612b77565b612e976040830186611965565b612ea46060830185611965565b8181036080830152612eb68184612ba2565b9050969550505050505056fe68747470733a2f2f697066732e696f2f697066732f516d5768775255524c785877564a76706d583834764a684368545464454e3444557552374d346e3259636e6f4833a26469706673582212200f99e8d01bb7e7c717be0976a47958232758d0e2a9e28b22497e0b8d7bb5cc8e64736f6c63430008130033"
