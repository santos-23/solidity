export const contractABI = [
    {
      "inputs": [],
      "stateMutability": "nonpayable",
      "type": "constructor"
    },
    {
      "anonymous": false,
      "inputs": [
        {
          "indexed": true,
          "internalType": "address",
          "name": "owner",
          "type": "address"
        },
        {
          "indexed": true,
          "internalType": "address",
          "name": "approved",
          "type": "address"
        },
        {
          "indexed": true,
          "internalType": "uint256",
          "name": "tokenId",
          "type": "uint256"
        }
      ],
      "name": "Approval",
      "type": "event"
    },
    {
      "anonymous": false,
      "inputs": [
        {
          "indexed": true,
          "internalType": "address",
          "name": "owner",
          "type": "address"
        },
        {
          "indexed": true,
          "internalType": "address",
          "name": "operator",
          "type": "address"
        },
        {
          "indexed": false,
          "internalType": "bool",
          "name": "approved",
          "type": "bool"
        }
      ],
      "name": "ApprovalForAll",
      "type": "event"
    },
    {
      "anonymous": false,
      "inputs": [
        {
          "indexed": false,
          "internalType": "uint256",
          "name": "_fromTokenId",
          "type": "uint256"
        },
        {
          "indexed": false,
          "internalType": "uint256",
          "name": "_toTokenId",
          "type": "uint256"
        }
      ],
      "name": "BatchMetadataUpdate",
      "type": "event"
    },
    {
      "anonymous": false,
      "inputs": [
        {
          "indexed": false,
          "internalType": "uint256",
          "name": "_tokenId",
          "type": "uint256"
        }
      ],
      "name": "MetadataUpdate",
      "type": "event"
    },
    {
      "anonymous": false,
      "inputs": [
        {
          "indexed": true,
          "internalType": "address",
          "name": "from",
          "type": "address"
        },
        {
          "indexed": true,
          "internalType": "address",
          "name": "to",
          "type": "address"
        },
        {
          "indexed": true,
          "internalType": "uint256",
          "name": "tokenId",
          "type": "uint256"
        }
      ],
      "name": "Transfer",
      "type": "event"
    },
    {
      "inputs": [
        {
          "internalType": "address",
          "name": "to",
          "type": "address"
        },
        {
          "internalType": "uint256",
          "name": "tokenId",
          "type": "uint256"
        }
      ],
      "name": "approve",
      "outputs": [],
      "stateMutability": "nonpayable",
      "type": "function"
    },
    {
      "inputs": [
        {
          "internalType": "address",
          "name": "owner",
          "type": "address"
        }
      ],
      "name": "balanceOf",
      "outputs": [
        {
          "internalType": "uint256",
          "name": "",
          "type": "uint256"
        }
      ],
      "stateMutability": "view",
      "type": "function"
    },
    {
      "inputs": [],
      "name": "collect",
      "outputs": [],
      "stateMutability": "payable",
      "type": "function"
    },
    {
      "inputs": [
        {
          "internalType": "uint256",
          "name": "tokenId",
          "type": "uint256"
        }
      ],
      "name": "getApproved",
      "outputs": [
        {
          "internalType": "address",
          "name": "",
          "type": "address"
        }
      ],
      "stateMutability": "view",
      "type": "function"
    },
    {
      "inputs": [
        {
          "internalType": "address",
          "name": "owner",
          "type": "address"
        },
        {
          "internalType": "address",
          "name": "operator",
          "type": "address"
        }
      ],
      "name": "isApprovedForAll",
      "outputs": [
        {
          "internalType": "bool",
          "name": "",
          "type": "bool"
        }
      ],
      "stateMutability": "view",
      "type": "function"
    },
    {
      "inputs": [
        {
          "internalType": "address",
          "name": "from",
          "type": "address"
        },
        {
          "internalType": "address",
          "name": "to",
          "type": "address"
        },
        {
          "internalType": "address",
          "name": "artist",
          "type": "address"
        },
        {
          "internalType": "address",
          "name": "royalityAddress",
          "type": "address"
        },
        {
          "internalType": "uint256",
          "name": "royality",
          "type": "uint256"
        },
        {
          "internalType": "uint256",
          "name": "commission",
          "type": "uint256"
        },
        {
          "internalType": "uint256",
          "name": "amount",
          "type": "uint256"
        },
        {
          "internalType": "uint256",
          "name": "tokenId",
          "type": "uint256"
        }
      ],
      "name": "magicTransfer",
      "outputs": [],
      "stateMutability": "payable",
      "type": "function"
    },
    {
      "inputs": [
        {
          "internalType": "address",
          "name": "to",
          "type": "address"
        },
        {
          "internalType": "string",
          "name": "base_uri",
          "type": "string"
        }
      ],
      "name": "mint",
      "outputs": [],
      "stateMutability": "nonpayable",
      "type": "function"
    },
    {
      "inputs": [],
      "name": "name",
      "outputs": [
        {
          "internalType": "string",
          "name": "",
          "type": "string"
        }
      ],
      "stateMutability": "view",
      "type": "function"
    },
    {
      "inputs": [
        {
          "internalType": "uint256",
          "name": "tokenId",
          "type": "uint256"
        }
      ],
      "name": "ownerOf",
      "outputs": [
        {
          "internalType": "address",
          "name": "",
          "type": "address"
        }
      ],
      "stateMutability": "view",
      "type": "function"
    },
    {
      "inputs": [
        {
          "internalType": "address",
          "name": "from",
          "type": "address"
        },
        {
          "internalType": "address",
          "name": "to",
          "type": "address"
        },
        {
          "internalType": "uint256",
          "name": "tokenId",
          "type": "uint256"
        }
      ],
      "name": "safeTransferFrom",
      "outputs": [],
      "stateMutability": "nonpayable",
      "type": "function"
    },
    {
      "inputs": [
        {
          "internalType": "address",
          "name": "from",
          "type": "address"
        },
        {
          "internalType": "address",
          "name": "to",
          "type": "address"
        },
        {
          "internalType": "uint256",
          "name": "tokenId",
          "type": "uint256"
        },
        {
          "internalType": "bytes",
          "name": "data",
          "type": "bytes"
        }
      ],
      "name": "safeTransferFrom",
      "outputs": [],
      "stateMutability": "nonpayable",
      "type": "function"
    },
    {
      "inputs": [
        {
          "internalType": "address",
          "name": "operator",
          "type": "address"
        },
        {
          "internalType": "bool",
          "name": "approved",
          "type": "bool"
        }
      ],
      "name": "setApprovalForAll",
      "outputs": [],
      "stateMutability": "nonpayable",
      "type": "function"
    },
    {
      "inputs": [
        {
          "internalType": "bytes4",
          "name": "interfaceId",
          "type": "bytes4"
        }
      ],
      "name": "supportsInterface",
      "outputs": [
        {
          "internalType": "bool",
          "name": "",
          "type": "bool"
        }
      ],
      "stateMutability": "view",
      "type": "function"
    },
    {
      "inputs": [],
      "name": "symbol",
      "outputs": [
        {
          "internalType": "string",
          "name": "",
          "type": "string"
        }
      ],
      "stateMutability": "view",
      "type": "function"
    },
    {
      "inputs": [
        {
          "internalType": "uint256",
          "name": "tokenId",
          "type": "uint256"
        }
      ],
      "name": "tokenURI",
      "outputs": [
        {
          "internalType": "string",
          "name": "",
          "type": "string"
        }
      ],
      "stateMutability": "view",
      "type": "function"
    },
    {
      "inputs": [
        {
          "internalType": "address",
          "name": "from",
          "type": "address"
        },
        {
          "internalType": "address",
          "name": "to",
          "type": "address"
        },
        {
          "internalType": "uint256",
          "name": "tokenId",
          "type": "uint256"
        }
      ],
      "name": "transferFrom",
      "outputs": [],
      "stateMutability": "nonpayable",
      "type": "function"
    }
  ]

export const contractAbi = [
  {
    "inputs": [],
    "stateMutability": "nonpayable",
    "type": "constructor"
  },
  {
    "anonymous": false,
    "inputs": [
      {
        "indexed": true,
        "internalType": "address",
        "name": "owner",
        "type": "address"
      },
      {
        "indexed": true,
        "internalType": "address",
        "name": "approved",
        "type": "address"
      },
      {
        "indexed": true,
        "internalType": "uint256",
        "name": "tokenId",
        "type": "uint256"
      }
    ],
    "name": "Approval",
    "type": "event"
  },
  {
    "anonymous": false,
    "inputs": [
      {
        "indexed": true,
        "internalType": "address",
        "name": "owner",
        "type": "address"
      },
      {
        "indexed": true,
        "internalType": "address",
        "name": "operator",
        "type": "address"
      },
      {
        "indexed": false,
        "internalType": "bool",
        "name": "approved",
        "type": "bool"
      }
    ],
    "name": "ApprovalForAll",
    "type": "event"
  },
  {
    "anonymous": false,
    "inputs": [
      {
        "indexed": false,
        "internalType": "uint256",
        "name": "_fromTokenId",
        "type": "uint256"
      },
      {
        "indexed": false,
        "internalType": "uint256",
        "name": "_toTokenId",
        "type": "uint256"
      }
    ],
    "name": "BatchMetadataUpdate",
    "type": "event"
  },
  {
    "anonymous": false,
    "inputs": [
      {
        "indexed": false,
        "internalType": "uint256",
        "name": "_tokenId",
        "type": "uint256"
      }
    ],
    "name": "MetadataUpdate",
    "type": "event"
  },
  {
    "anonymous": false,
    "inputs": [
      {
        "indexed": true,
        "internalType": "address",
        "name": "from",
        "type": "address"
      },
      {
        "indexed": true,
        "internalType": "address",
        "name": "to",
        "type": "address"
      },
      {
        "indexed": true,
        "internalType": "uint256",
        "name": "tokenId",
        "type": "uint256"
      }
    ],
    "name": "Transfer",
    "type": "event"
  },
  {
    "inputs": [
      {
        "internalType": "address",
        "name": "to",
        "type": "address"
      },
      {
        "internalType": "uint256",
        "name": "tokenId",
        "type": "uint256"
      }
    ],
    "name": "approve",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [
      {
        "internalType": "address",
        "name": "owner",
        "type": "address"
      }
    ],
    "name": "balanceOf",
    "outputs": [
      {
        "internalType": "uint256",
        "name": "",
        "type": "uint256"
      }
    ],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "collect",
    "outputs": [],
    "stateMutability": "payable",
    "type": "function"
  },
  {
    "inputs": [
      {
        "internalType": "uint256",
        "name": "tokenId",
        "type": "uint256"
      }
    ],
    "name": "getApproved",
    "outputs": [
      {
        "internalType": "address",
        "name": "",
        "type": "address"
      }
    ],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [
      {
        "internalType": "address",
        "name": "owner",
        "type": "address"
      },
      {
        "internalType": "address",
        "name": "operator",
        "type": "address"
      }
    ],
    "name": "isApprovedForAll",
    "outputs": [
      {
        "internalType": "bool",
        "name": "",
        "type": "bool"
      }
    ],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [
      {
        "internalType": "address",
        "name": "from",
        "type": "address"
      },
      {
        "internalType": "address",
        "name": "to",
        "type": "address"
      },
      {
        "internalType": "address",
        "name": "artist",
        "type": "address"
      },
      {
        "internalType": "address",
        "name": "royalityAddress",
        "type": "address"
      },
      {
        "internalType": "uint256",
        "name": "royality",
        "type": "uint256"
      },
      {
        "internalType": "uint256",
        "name": "commission",
        "type": "uint256"
      },
      {
        "internalType": "uint256",
        "name": "tokenId",
        "type": "uint256"
      }
    ],
    "name": "magicTransfer",
    "outputs": [],
    "stateMutability": "payable",
    "type": "function"
  },
  {
    "inputs": [
      {
        "internalType": "address",
        "name": "to",
        "type": "address"
      },
      {
        "internalType": "string",
        "name": "base_uri",
        "type": "string"
      }
    ],
    "name": "mint",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "name",
    "outputs": [
      {
        "internalType": "string",
        "name": "",
        "type": "string"
      }
    ],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [
      {
        "internalType": "uint256",
        "name": "tokenId",
        "type": "uint256"
      }
    ],
    "name": "ownerOf",
    "outputs": [
      {
        "internalType": "address",
        "name": "",
        "type": "address"
      }
    ],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [
      {
        "internalType": "address",
        "name": "from",
        "type": "address"
      },
      {
        "internalType": "address",
        "name": "to",
        "type": "address"
      },
      {
        "internalType": "uint256",
        "name": "tokenId",
        "type": "uint256"
      }
    ],
    "name": "safeTransferFrom",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [
      {
        "internalType": "address",
        "name": "from",
        "type": "address"
      },
      {
        "internalType": "address",
        "name": "to",
        "type": "address"
      },
      {
        "internalType": "uint256",
        "name": "tokenId",
        "type": "uint256"
      },
      {
        "internalType": "bytes",
        "name": "data",
        "type": "bytes"
      }
    ],
    "name": "safeTransferFrom",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [
      {
        "internalType": "address",
        "name": "operator",
        "type": "address"
      },
      {
        "internalType": "bool",
        "name": "approved",
        "type": "bool"
      }
    ],
    "name": "setApprovalForAll",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [
      {
        "internalType": "bytes4",
        "name": "interfaceId",
        "type": "bytes4"
      }
    ],
    "name": "supportsInterface",
    "outputs": [
      {
        "internalType": "bool",
        "name": "",
        "type": "bool"
      }
    ],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "symbol",
    "outputs": [
      {
        "internalType": "string",
        "name": "",
        "type": "string"
      }
    ],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [
      {
        "internalType": "uint256",
        "name": "tokenId",
        "type": "uint256"
      }
    ],
    "name": "tokenURI",
    "outputs": [
      {
        "internalType": "string",
        "name": "",
        "type": "string"
      }
    ],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [
      {
        "internalType": "address",
        "name": "from",
        "type": "address"
      },
      {
        "internalType": "address",
        "name": "to",
        "type": "address"
      },
      {
        "internalType": "uint256",
        "name": "tokenId",
        "type": "uint256"
      }
    ],
    "name": "transferFrom",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  }
]

export const contractByte = "0x608060405260006007553480156200001657600080fd5b506040518060400160405280600c81526020017f43727970746f546f6b656e7300000000000000000000000000000000000000008152506040518060400160405280600381526020017f4352540000000000000000000000000000000000000000000000000000000000815250816000908162000094919062000329565b508060019081620000a6919062000329565b50505062000410565b600081519050919050565b7f4e487b7100000000000000000000000000000000000000000000000000000000600052604160045260246000fd5b7f4e487b7100000000000000000000000000000000000000000000000000000000600052602260045260246000fd5b600060028204905060018216806200013157607f821691505b602082108103620001475762000146620000e9565b5b50919050565b60008190508160005260206000209050919050565b60006020601f8301049050919050565b600082821b905092915050565b600060088302620001b17fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff8262000172565b620001bd868362000172565b95508019841693508086168417925050509392505050565b6000819050919050565b6000819050919050565b60006200020a62000204620001fe84620001d5565b620001df565b620001d5565b9050919050565b6000819050919050565b6200022683620001e9565b6200023e620002358262000211565b8484546200017f565b825550505050565b600090565b6200025562000246565b620002628184846200021b565b505050565b5b818110156200028a576200027e6000826200024b565b60018101905062000268565b5050565b601f821115620002d957620002a3816200014d565b620002ae8462000162565b81016020851015620002be578190505b620002d6620002cd8562000162565b83018262000267565b50505b505050565b600082821c905092915050565b6000620002fe60001984600802620002de565b1980831691505092915050565b6000620003198383620002eb565b9150826002028217905092915050565b6200033482620000af565b67ffffffffffffffff81111562000350576200034f620000ba565b5b6200035c825462000118565b620003698282856200028e565b600060209050601f831160018114620003a157600084156200038c578287015190505b6200039885826200030b565b86555062000408565b601f198416620003b1866200014d565b60005b82811015620003db57848901518255600182019150602085019450602081019050620003b4565b86831015620003fb5784890151620003f7601f891682620002eb565b8355505b6001600288020188555050505b505050505050565b612fe080620004206000396000f3fe6080604052600436106100f35760003560e01c8063886ec9791161008a578063c87b56dd11610059578063c87b56dd1461032b578063d0def52114610368578063e522538114610391578063e985e9c51461039b576100f3565b8063886ec9791461029257806395d89b41146102ae578063a22cb465146102d9578063b88d4fde14610302576100f3565b806323b872dd116100c657806323b872dd146101c657806342842e0e146101ef5780636352211e1461021857806370a0823114610255576100f3565b806301ffc9a7146100f857806306fdde0314610135578063081812fc14610160578063095ea7b31461019d575b600080fd5b34801561010457600080fd5b5061011f600480360381019061011a9190611d0f565b6103d8565b60405161012c9190611d57565b60405180910390f35b34801561014157600080fd5b5061014a6103ea565b6040516101579190611e02565b60405180910390f35b34801561016c57600080fd5b5061018760048036038101906101829190611e5a565b61047c565b6040516101949190611ec8565b60405180910390f35b3480156101a957600080fd5b506101c460048036038101906101bf9190611f0f565b6104c2565b005b3480156101d257600080fd5b506101ed60048036038101906101e89190611f4f565b6105d9565b005b3480156101fb57600080fd5b5061021660048036038101906102119190611f4f565b610639565b005b34801561022457600080fd5b5061023f600480360381019061023a9190611e5a565b610659565b60405161024c9190611ec8565b60405180910390f35b34801561026157600080fd5b5061027c60048036038101906102779190611fa2565b6106df565b6040516102899190611fde565b60405180910390f35b6102ac60048036038101906102a79190611ff9565b610796565b005b3480156102ba57600080fd5b506102c36109c0565b6040516102d09190611e02565b60405180910390f35b3480156102e557600080fd5b5061030060048036038101906102fb91906120c7565b610a52565b005b34801561030e57600080fd5b506103296004803603810190610324919061223c565b610a68565b005b34801561033757600080fd5b50610352600480360381019061034d9190611e5a565b610aca565b60405161035f9190611e02565b60405180910390f35b34801561037457600080fd5b5061038f600480360381019061038a9190612360565b610adc565b005b610399610b10565b005b3480156103a757600080fd5b506103c260048036038101906103bd91906123bc565b610b59565b6040516103cf9190611d57565b60405180910390f35b60006103e382610bed565b9050919050565b6060600080546103f99061242b565b80601f01602080910402602001604051908101604052809291908181526020018280546104259061242b565b80156104725780601f1061044757610100808354040283529160200191610472565b820191906000526020600020905b81548152906001019060200180831161045557829003601f168201915b5050505050905090565b600061048782610c4e565b6004600083815260200190815260200160002060009054906101000a900473ffffffffffffffffffffffffffffffffffffffff169050919050565b60006104cd82610659565b90508073ffffffffffffffffffffffffffffffffffffffff168373ffffffffffffffffffffffffffffffffffffffff160361053d576040517f08c379a0000000000000000000000000000000000000000000000000000000008152600401610534906124ce565b60405180910390fd5b8073ffffffffffffffffffffffffffffffffffffffff1661055c610c99565b73ffffffffffffffffffffffffffffffffffffffff16148061058b575061058a81610585610c99565b610b59565b5b6105ca576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004016105c190612560565b60405180910390fd5b6105d48383610ca1565b505050565b6105ea6105e4610c99565b82610d5a565b610629576040517f08c379a0000000000000000000000000000000000000000000000000000000008152600401610620906125f2565b60405180910390fd5b610634838383610def565b505050565b61065483838360405180602001604052806000815250610a68565b505050565b600080610665836110e8565b9050600073ffffffffffffffffffffffffffffffffffffffff168173ffffffffffffffffffffffffffffffffffffffff16036106d6576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004016106cd9061265e565b60405180910390fd5b80915050919050565b60008073ffffffffffffffffffffffffffffffffffffffff168273ffffffffffffffffffffffffffffffffffffffff160361074f576040517f08c379a0000000000000000000000000000000000000000000000000000000008152600401610746906126f0565b60405180910390fd5b600360008373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff168152602001908152602001600020549050919050565b8473ffffffffffffffffffffffffffffffffffffffff168773ffffffffffffffffffffffffffffffffffffffff16146107e5576107d38588610b59565b6107e4576107e385886001611125565b5b5b61080085878360405180602001604052806000815250611291565b60003490508573ffffffffffffffffffffffffffffffffffffffff168873ffffffffffffffffffffffffffffffffffffffff1603610884578573ffffffffffffffffffffffffffffffffffffffff166108fc829081150290604051600060405180830381858888f1935050505015801561087e573d6000803e3d6000fd5b506109b6565b600060648483610894919061273f565b61089e91906127b0565b90508873ffffffffffffffffffffffffffffffffffffffff166108fc829081150290604051600060405180830381858888f193505050501580156108e6573d6000803e3d6000fd5b5080826108f391906127e1565b9150600060648684610905919061273f565b61090f91906127b0565b905060008790508073ffffffffffffffffffffffffffffffffffffffff166108fc839081150290604051600060405180830381858888f1935050505015801561095c573d6000803e3d6000fd5b50818461096991906127e1565b93508873ffffffffffffffffffffffffffffffffffffffff166108fc859081150290604051600060405180830381858888f193505050501580156109b1573d6000803e3d6000fd5b505050505b5050505050505050565b6060600180546109cf9061242b565b80601f01602080910402602001604051908101604052809291908181526020018280546109fb9061242b565b8015610a485780601f10610a1d57610100808354040283529160200191610a48565b820191906000526020600020905b815481529060010190602001808311610a2b57829003601f168201915b5050505050905090565b610a64610a5d610c99565b8383611125565b5050565b610a79610a73610c99565b83610d5a565b610ab8576040517f08c379a0000000000000000000000000000000000000000000000000000000008152600401610aaf906125f2565b60405180910390fd5b610ac484848484611291565b50505050565b6060610ad5826112ed565b9050919050565b60076000815480929190610aef90612815565b9190505550610b00826007546113ff565b610b0c6007548261161c565b5050565b3373ffffffffffffffffffffffffffffffffffffffff166108fc479081150290604051600060405180830381858888f19350505050158015610b56573d6000803e3d6000fd5b50565b6000600560008473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200190815260200160002060008373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200190815260200160002060009054906101000a900460ff16905092915050565b6000634906490660e01b7bffffffffffffffffffffffffffffffffffffffffffffffffffffffff1916827bffffffffffffffffffffffffffffffffffffffffffffffffffffffff19161480610c475750610c46826116c0565b5b9050919050565b610c57816117a2565b610c96576040517f08c379a0000000000000000000000000000000000000000000000000000000008152600401610c8d9061265e565b60405180910390fd5b50565b600033905090565b816004600083815260200190815260200160002060006101000a81548173ffffffffffffffffffffffffffffffffffffffff021916908373ffffffffffffffffffffffffffffffffffffffff160217905550808273ffffffffffffffffffffffffffffffffffffffff16610d1483610659565b73ffffffffffffffffffffffffffffffffffffffff167f8c5be1e5ebec7d5bd14f71427d1e84f3dd0314c0f7b2291e5b200ac8c7c3b92560405160405180910390a45050565b600080610d6683610659565b90508073ffffffffffffffffffffffffffffffffffffffff168473ffffffffffffffffffffffffffffffffffffffff161480610da85750610da78185610b59565b5b80610de657508373ffffffffffffffffffffffffffffffffffffffff16610dce8461047c565b73ffffffffffffffffffffffffffffffffffffffff16145b91505092915050565b8273ffffffffffffffffffffffffffffffffffffffff16610e0f82610659565b73ffffffffffffffffffffffffffffffffffffffff1614610e65576040517f08c379a0000000000000000000000000000000000000000000000000000000008152600401610e5c906128cf565b60405180910390fd5b600073ffffffffffffffffffffffffffffffffffffffff168273ffffffffffffffffffffffffffffffffffffffff1603610ed4576040517f08c379a0000000000000000000000000000000000000000000000000000000008152600401610ecb90612961565b60405180910390fd5b610ee183838360016117e3565b8273ffffffffffffffffffffffffffffffffffffffff16610f0182610659565b73ffffffffffffffffffffffffffffffffffffffff1614610f57576040517f08c379a0000000000000000000000000000000000000000000000000000000008152600401610f4e906128cf565b60405180910390fd5b6004600082815260200190815260200160002060006101000a81549073ffffffffffffffffffffffffffffffffffffffff02191690556001600360008573ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff168152602001908152602001600020600082825403925050819055506001600360008473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200190815260200160002060008282540192505081905550816002600083815260200190815260200160002060006101000a81548173ffffffffffffffffffffffffffffffffffffffff021916908373ffffffffffffffffffffffffffffffffffffffff160217905550808273ffffffffffffffffffffffffffffffffffffffff168473ffffffffffffffffffffffffffffffffffffffff167fddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef60405160405180910390a46110e383838360016117e9565b505050565b60006002600083815260200190815260200160002060009054906101000a900473ffffffffffffffffffffffffffffffffffffffff169050919050565b8173ffffffffffffffffffffffffffffffffffffffff168373ffffffffffffffffffffffffffffffffffffffff1603611193576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040161118a906129cd565b60405180910390fd5b80600560008573ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200190815260200160002060008473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200190815260200160002060006101000a81548160ff0219169083151502179055508173ffffffffffffffffffffffffffffffffffffffff168373ffffffffffffffffffffffffffffffffffffffff167f17307eab39ab6107e8899845ad3d59bd9653f200f220920489ca2b5937696c31836040516112849190611d57565b60405180910390a3505050565b61129c848484610def565b6112a8848484846117ef565b6112e7576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004016112de90612a5f565b60405180910390fd5b50505050565b60606112f882610c4e565b60006006600084815260200190815260200160002080546113189061242b565b80601f01602080910402602001604051908101604052809291908181526020018280546113449061242b565b80156113915780601f1061136657610100808354040283529160200191611391565b820191906000526020600020905b81548152906001019060200180831161137457829003601f168201915b5050505050905060006113a2611976565b905060008151036113b75781925050506113fa565b6000825111156113ec5780826040516020016113d4929190612abb565b604051602081830303815290604052925050506113fa565b6113f58461198d565b925050505b919050565b600073ffffffffffffffffffffffffffffffffffffffff168273ffffffffffffffffffffffffffffffffffffffff160361146e576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040161146590612b2b565b60405180910390fd5b611477816117a2565b156114b7576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004016114ae90612b97565b60405180910390fd5b6114c56000838360016117e3565b6114ce816117a2565b1561150e576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040161150590612b97565b60405180910390fd5b6001600360008473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200190815260200160002060008282540192505081905550816002600083815260200190815260200160002060006101000a81548173ffffffffffffffffffffffffffffffffffffffff021916908373ffffffffffffffffffffffffffffffffffffffff160217905550808273ffffffffffffffffffffffffffffffffffffffff16600073ffffffffffffffffffffffffffffffffffffffff167fddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef60405160405180910390a46116186000838360016117e9565b5050565b611625826117a2565b611664576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040161165b90612c29565b60405180910390fd5b806006600084815260200190815260200160002090816116849190612df5565b507ff8e1a15aba9398e019f0b49df1a4fde98ee17ae345cb5f6b5e2c27f5033e8ce7826040516116b49190611fde565b60405180910390a15050565b60007f80ac58cd000000000000000000000000000000000000000000000000000000007bffffffffffffffffffffffffffffffffffffffffffffffffffffffff1916827bffffffffffffffffffffffffffffffffffffffffffffffffffffffff1916148061178b57507f5b5e139f000000000000000000000000000000000000000000000000000000007bffffffffffffffffffffffffffffffffffffffffffffffffffffffff1916827bffffffffffffffffffffffffffffffffffffffffffffffffffffffff1916145b8061179b575061179a826119f5565b5b9050919050565b60008073ffffffffffffffffffffffffffffffffffffffff166117c4836110e8565b73ffffffffffffffffffffffffffffffffffffffff1614159050919050565b50505050565b50505050565b60006118108473ffffffffffffffffffffffffffffffffffffffff16611a5f565b15611969578373ffffffffffffffffffffffffffffffffffffffff1663150b7a02611839610c99565b8786866040518563ffffffff1660e01b815260040161185b9493929190612f1c565b6020604051808303816000875af192505050801561189757506040513d601f19601f820116820180604052508101906118949190612f7d565b60015b611919573d80600081146118c7576040519150601f19603f3d011682016040523d82523d6000602084013e6118cc565b606091505b506000815103611911576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040161190890612a5f565b60405180910390fd5b805181602001fd5b63150b7a0260e01b7bffffffffffffffffffffffffffffffffffffffffffffffffffffffff1916817bffffffffffffffffffffffffffffffffffffffffffffffffffffffff19161491505061196e565b600190505b949350505050565b606060405180602001604052806000815250905090565b606061199882610c4e565b60006119a2611976565b905060008151116119c257604051806020016040528060008152506119ed565b806119cc84611a82565b6040516020016119dd929190612abb565b6040516020818303038152906040525b915050919050565b60007f01ffc9a7000000000000000000000000000000000000000000000000000000007bffffffffffffffffffffffffffffffffffffffffffffffffffffffff1916827bffffffffffffffffffffffffffffffffffffffffffffffffffffffff1916149050919050565b6000808273ffffffffffffffffffffffffffffffffffffffff163b119050919050565b606060006001611a9184611b50565b01905060008167ffffffffffffffff811115611ab057611aaf612111565b5b6040519080825280601f01601f191660200182016040528015611ae25781602001600182028036833780820191505090505b509050600082602001820190505b600115611b45578080600190039150507f3031323334353637383961626364656600000000000000000000000000000000600a86061a8153600a8581611b3957611b38612781565b5b04945060008503611af0575b819350505050919050565b600080600090507a184f03e93ff9f4daa797ed6e38ed64bf6a1f0100000000000000008310611bae577a184f03e93ff9f4daa797ed6e38ed64bf6a1f0100000000000000008381611ba457611ba3612781565b5b0492506040810190505b6d04ee2d6d415b85acef81000000008310611beb576d04ee2d6d415b85acef81000000008381611be157611be0612781565b5b0492506020810190505b662386f26fc100008310611c1a57662386f26fc100008381611c1057611c0f612781565b5b0492506010810190505b6305f5e1008310611c43576305f5e1008381611c3957611c38612781565b5b0492506008810190505b6127108310611c68576127108381611c5e57611c5d612781565b5b0492506004810190505b60648310611c8b5760648381611c8157611c80612781565b5b0492506002810190505b600a8310611c9a576001810190505b80915050919050565b6000604051905090565b600080fd5b600080fd5b60007fffffffff0000000000000000000000000000000000000000000000000000000082169050919050565b611cec81611cb7565b8114611cf757600080fd5b50565b600081359050611d0981611ce3565b92915050565b600060208284031215611d2557611d24611cad565b5b6000611d3384828501611cfa565b91505092915050565b60008115159050919050565b611d5181611d3c565b82525050565b6000602082019050611d6c6000830184611d48565b92915050565b600081519050919050565b600082825260208201905092915050565b60005b83811015611dac578082015181840152602081019050611d91565b60008484015250505050565b6000601f19601f8301169050919050565b6000611dd482611d72565b611dde8185611d7d565b9350611dee818560208601611d8e565b611df781611db8565b840191505092915050565b60006020820190508181036000830152611e1c8184611dc9565b905092915050565b6000819050919050565b611e3781611e24565b8114611e4257600080fd5b50565b600081359050611e5481611e2e565b92915050565b600060208284031215611e7057611e6f611cad565b5b6000611e7e84828501611e45565b91505092915050565b600073ffffffffffffffffffffffffffffffffffffffff82169050919050565b6000611eb282611e87565b9050919050565b611ec281611ea7565b82525050565b6000602082019050611edd6000830184611eb9565b92915050565b611eec81611ea7565b8114611ef757600080fd5b50565b600081359050611f0981611ee3565b92915050565b60008060408385031215611f2657611f25611cad565b5b6000611f3485828601611efa565b9250506020611f4585828601611e45565b9150509250929050565b600080600060608486031215611f6857611f67611cad565b5b6000611f7686828701611efa565b9350506020611f8786828701611efa565b9250506040611f9886828701611e45565b9150509250925092565b600060208284031215611fb857611fb7611cad565b5b6000611fc684828501611efa565b91505092915050565b611fd881611e24565b82525050565b6000602082019050611ff36000830184611fcf565b92915050565b600080600080600080600060e0888a03121561201857612017611cad565b5b60006120268a828b01611efa565b97505060206120378a828b01611efa565b96505060406120488a828b01611efa565b95505060606120598a828b01611efa565b945050608061206a8a828b01611e45565b93505060a061207b8a828b01611e45565b92505060c061208c8a828b01611e45565b91505092959891949750929550565b6120a481611d3c565b81146120af57600080fd5b50565b6000813590506120c18161209b565b92915050565b600080604083850312156120de576120dd611cad565b5b60006120ec85828601611efa565b92505060206120fd858286016120b2565b9150509250929050565b600080fd5b600080fd5b7f4e487b7100000000000000000000000000000000000000000000000000000000600052604160045260246000fd5b61214982611db8565b810181811067ffffffffffffffff8211171561216857612167612111565b5b80604052505050565b600061217b611ca3565b90506121878282612140565b919050565b600067ffffffffffffffff8211156121a7576121a6612111565b5b6121b082611db8565b9050602081019050919050565b82818337600083830152505050565b60006121df6121da8461218c565b612171565b9050828152602081018484840111156121fb576121fa61210c565b5b6122068482856121bd565b509392505050565b600082601f83011261222357612222612107565b5b81356122338482602086016121cc565b91505092915050565b6000806000806080858703121561225657612255611cad565b5b600061226487828801611efa565b945050602061227587828801611efa565b935050604061228687828801611e45565b925050606085013567ffffffffffffffff8111156122a7576122a6611cb2565b5b6122b38782880161220e565b91505092959194509250565b600067ffffffffffffffff8211156122da576122d9612111565b5b6122e382611db8565b9050602081019050919050565b60006123036122fe846122bf565b612171565b90508281526020810184848401111561231f5761231e61210c565b5b61232a8482856121bd565b509392505050565b600082601f83011261234757612346612107565b5b81356123578482602086016122f0565b91505092915050565b6000806040838503121561237757612376611cad565b5b600061238585828601611efa565b925050602083013567ffffffffffffffff8111156123a6576123a5611cb2565b5b6123b285828601612332565b9150509250929050565b600080604083850312156123d3576123d2611cad565b5b60006123e185828601611efa565b92505060206123f285828601611efa565b9150509250929050565b7f4e487b7100000000000000000000000000000000000000000000000000000000600052602260045260246000fd5b6000600282049050600182168061244357607f821691505b602082108103612456576124556123fc565b5b50919050565b7f4552433732313a20617070726f76616c20746f2063757272656e74206f776e6560008201527f7200000000000000000000000000000000000000000000000000000000000000602082015250565b60006124b8602183611d7d565b91506124c38261245c565b604082019050919050565b600060208201905081810360008301526124e7816124ab565b9050919050565b7f4552433732313a20617070726f76652063616c6c6572206973206e6f7420746f60008201527f6b656e206f776e6572206f7220617070726f76656420666f7220616c6c000000602082015250565b600061254a603d83611d7d565b9150612555826124ee565b604082019050919050565b600060208201905081810360008301526125798161253d565b9050919050565b7f4552433732313a2063616c6c6572206973206e6f7420746f6b656e206f776e6560008201527f72206f7220617070726f76656400000000000000000000000000000000000000602082015250565b60006125dc602d83611d7d565b91506125e782612580565b604082019050919050565b6000602082019050818103600083015261260b816125cf565b9050919050565b7f4552433732313a20696e76616c696420746f6b656e2049440000000000000000600082015250565b6000612648601883611d7d565b915061265382612612565b602082019050919050565b600060208201905081810360008301526126778161263b565b9050919050565b7f4552433732313a2061646472657373207a65726f206973206e6f74206120766160008201527f6c6964206f776e65720000000000000000000000000000000000000000000000602082015250565b60006126da602983611d7d565b91506126e58261267e565b604082019050919050565b60006020820190508181036000830152612709816126cd565b9050919050565b7f4e487b7100000000000000000000000000000000000000000000000000000000600052601160045260246000fd5b600061274a82611e24565b915061275583611e24565b925082820261276381611e24565b9150828204841483151761277a57612779612710565b5b5092915050565b7f4e487b7100000000000000000000000000000000000000000000000000000000600052601260045260246000fd5b60006127bb82611e24565b91506127c683611e24565b9250826127d6576127d5612781565b5b828204905092915050565b60006127ec82611e24565b91506127f783611e24565b925082820390508181111561280f5761280e612710565b5b92915050565b600061282082611e24565b91507fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff820361285257612851612710565b5b600182019050919050565b7f4552433732313a207472616e736665722066726f6d20696e636f72726563742060008201527f6f776e6572000000000000000000000000000000000000000000000000000000602082015250565b60006128b9602583611d7d565b91506128c48261285d565b604082019050919050565b600060208201905081810360008301526128e8816128ac565b9050919050565b7f4552433732313a207472616e7366657220746f20746865207a65726f2061646460008201527f7265737300000000000000000000000000000000000000000000000000000000602082015250565b600061294b602483611d7d565b9150612956826128ef565b604082019050919050565b6000602082019050818103600083015261297a8161293e565b9050919050565b7f4552433732313a20617070726f766520746f2063616c6c657200000000000000600082015250565b60006129b7601983611d7d565b91506129c282612981565b602082019050919050565b600060208201905081810360008301526129e6816129aa565b9050919050565b7f4552433732313a207472616e7366657220746f206e6f6e20455243373231526560008201527f63656976657220696d706c656d656e7465720000000000000000000000000000602082015250565b6000612a49603283611d7d565b9150612a54826129ed565b604082019050919050565b60006020820190508181036000830152612a7881612a3c565b9050919050565b600081905092915050565b6000612a9582611d72565b612a9f8185612a7f565b9350612aaf818560208601611d8e565b80840191505092915050565b6000612ac78285612a8a565b9150612ad38284612a8a565b91508190509392505050565b7f4552433732313a206d696e7420746f20746865207a65726f2061646472657373600082015250565b6000612b15602083611d7d565b9150612b2082612adf565b602082019050919050565b60006020820190508181036000830152612b4481612b08565b9050919050565b7f4552433732313a20746f6b656e20616c7265616479206d696e74656400000000600082015250565b6000612b81601c83611d7d565b9150612b8c82612b4b565b602082019050919050565b60006020820190508181036000830152612bb081612b74565b9050919050565b7f45524337323155524953746f726167653a2055524920736574206f66206e6f6e60008201527f6578697374656e7420746f6b656e000000000000000000000000000000000000602082015250565b6000612c13602e83611d7d565b9150612c1e82612bb7565b604082019050919050565b60006020820190508181036000830152612c4281612c06565b9050919050565b60008190508160005260206000209050919050565b60006020601f8301049050919050565b600082821b905092915050565b600060088302612cab7fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff82612c6e565b612cb58683612c6e565b95508019841693508086168417925050509392505050565b6000819050919050565b6000612cf2612ced612ce884611e24565b612ccd565b611e24565b9050919050565b6000819050919050565b612d0c83612cd7565b612d20612d1882612cf9565b848454612c7b565b825550505050565b600090565b612d35612d28565b612d40818484612d03565b505050565b5b81811015612d6457612d59600082612d2d565b600181019050612d46565b5050565b601f821115612da957612d7a81612c49565b612d8384612c5e565b81016020851015612d92578190505b612da6612d9e85612c5e565b830182612d45565b50505b505050565b600082821c905092915050565b6000612dcc60001984600802612dae565b1980831691505092915050565b6000612de58383612dbb565b9150826002028217905092915050565b612dfe82611d72565b67ffffffffffffffff811115612e1757612e16612111565b5b612e21825461242b565b612e2c828285612d68565b600060209050601f831160018114612e5f5760008415612e4d578287015190505b612e578582612dd9565b865550612ebf565b601f198416612e6d86612c49565b60005b82811015612e9557848901518255600182019150602085019450602081019050612e70565b86831015612eb25784890151612eae601f891682612dbb565b8355505b6001600288020188555050505b505050505050565b600081519050919050565b600082825260208201905092915050565b6000612eee82612ec7565b612ef88185612ed2565b9350612f08818560208601611d8e565b612f1181611db8565b840191505092915050565b6000608082019050612f316000830187611eb9565b612f3e6020830186611eb9565b612f4b6040830185611fcf565b8181036060830152612f5d8184612ee3565b905095945050505050565b600081519050612f7781611ce3565b92915050565b600060208284031215612f9357612f92611cad565b5b6000612fa184828501612f68565b9150509291505056fea2646970667358221220d373634d5acdc940360b1f6be320679331de33488980aef038f72f3033aaac8a64736f6c63430008130033"

export const bytecode = "0x608060405260006007553480156200001657600080fd5b506040518060400160405280600c81526020017f43727970746f546f6b656e7300000000000000000000000000000000000000008152506040518060400160405280600381526020017f4352540000000000000000000000000000000000000000000000000000000000815250816000908162000094919062000329565b508060019081620000a6919062000329565b50505062000410565b600081519050919050565b7f4e487b7100000000000000000000000000000000000000000000000000000000600052604160045260246000fd5b7f4e487b7100000000000000000000000000000000000000000000000000000000600052602260045260246000fd5b600060028204905060018216806200013157607f821691505b602082108103620001475762000146620000e9565b5b50919050565b60008190508160005260206000209050919050565b60006020601f8301049050919050565b600082821b905092915050565b600060088302620001b17fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff8262000172565b620001bd868362000172565b95508019841693508086168417925050509392505050565b6000819050919050565b6000819050919050565b60006200020a62000204620001fe84620001d5565b620001df565b620001d5565b9050919050565b6000819050919050565b6200022683620001e9565b6200023e620002358262000211565b8484546200017f565b825550505050565b600090565b6200025562000246565b620002628184846200021b565b505050565b5b818110156200028a576200027e6000826200024b565b60018101905062000268565b5050565b601f821115620002d957620002a3816200014d565b620002ae8462000162565b81016020851015620002be578190505b620002d6620002cd8562000162565b83018262000267565b50505b505050565b600082821c905092915050565b6000620002fe60001984600802620002de565b1980831691505092915050565b6000620003198383620002eb565b9150826002028217905092915050565b6200033482620000af565b67ffffffffffffffff81111562000350576200034f620000ba565b5b6200035c825462000118565b620003698282856200028e565b600060209050601f831160018114620003a157600084156200038c578287015190505b6200039885826200030b565b86555062000408565b601f198416620003b1866200014d565b60005b82811015620003db57848901518255600182019150602085019450602081019050620003b4565b86831015620003fb5784890151620003f7601f891682620002eb565b8355505b6001600288020188555050505b505050505050565b61301480620004206000396000f3fe6080604052600436106100f35760003560e01c806370a082311161008a578063c87b56dd11610059578063c87b56dd1461032b578063d0def52114610368578063e522538114610391578063e985e9c51461039b576100f3565b806370a082311461027157806395d89b41146102ae578063a22cb465146102d9578063b88d4fde14610302576100f3565b806323b872dd116100c657806323b872dd146101c6578063342a978b146101ef57806342842e0e1461020b5780636352211e14610234576100f3565b806301ffc9a7146100f857806306fdde0314610135578063081812fc14610160578063095ea7b31461019d575b600080fd5b34801561010457600080fd5b5061011f600480360381019061011a9190611d2f565b6103d8565b60405161012c9190611d77565b60405180910390f35b34801561014157600080fd5b5061014a6103ea565b6040516101579190611e22565b60405180910390f35b34801561016c57600080fd5b5061018760048036038101906101829190611e7a565b61047c565b6040516101949190611ee8565b60405180910390f35b3480156101a957600080fd5b506101c460048036038101906101bf9190611f2f565b6104c2565b005b3480156101d257600080fd5b506101ed60048036038101906101e89190611f6f565b6105d9565b005b61020960048036038101906102049190611fc2565b610639565b005b34801561021757600080fd5b50610232600480360381019061022d9190611f6f565b610883565b005b34801561024057600080fd5b5061025b60048036038101906102569190611e7a565b6108a3565b6040516102689190611ee8565b60405180910390f35b34801561027d57600080fd5b5061029860048036038101906102939190612078565b610929565b6040516102a591906120b4565b60405180910390f35b3480156102ba57600080fd5b506102c36109e0565b6040516102d09190611e22565b60405180910390f35b3480156102e557600080fd5b5061030060048036038101906102fb91906120fb565b610a72565b005b34801561030e57600080fd5b5061032960048036038101906103249190612270565b610a88565b005b34801561033757600080fd5b50610352600480360381019061034d9190611e7a565b610aea565b60405161035f9190611e22565b60405180910390f35b34801561037457600080fd5b5061038f600480360381019061038a9190612394565b610afc565b005b610399610b30565b005b3480156103a757600080fd5b506103c260048036038101906103bd91906123f0565b610b79565b6040516103cf9190611d77565b60405180910390f35b60006103e382610c0d565b9050919050565b6060600080546103f99061245f565b80601f01602080910402602001604051908101604052809291908181526020018280546104259061245f565b80156104725780601f1061044757610100808354040283529160200191610472565b820191906000526020600020905b81548152906001019060200180831161045557829003601f168201915b5050505050905090565b600061048782610c6e565b6004600083815260200190815260200160002060009054906101000a900473ffffffffffffffffffffffffffffffffffffffff169050919050565b60006104cd826108a3565b90508073ffffffffffffffffffffffffffffffffffffffff168373ffffffffffffffffffffffffffffffffffffffff160361053d576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040161053490612502565b60405180910390fd5b8073ffffffffffffffffffffffffffffffffffffffff1661055c610cb9565b73ffffffffffffffffffffffffffffffffffffffff16148061058b575061058a81610585610cb9565b610b79565b5b6105ca576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004016105c190612594565b60405180910390fd5b6105d48383610cc1565b505050565b6105ea6105e4610cb9565b82610d7a565b610629576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040161062090612626565b60405180910390fd5b610634838383610e0f565b505050565b8573ffffffffffffffffffffffffffffffffffffffff168873ffffffffffffffffffffffffffffffffffffffff1614610688576106768689610b79565b6106875761068686896001611108565b5b5b6106a386888360405180602001604052806000815250611274565b6000670de0b6b3a76400006064846106bb91906126a4565b6106c591906126d5565b90508673ffffffffffffffffffffffffffffffffffffffff168973ffffffffffffffffffffffffffffffffffffffff1603610746578673ffffffffffffffffffffffffffffffffffffffff166108fc829081150290604051600060405180830381858888f19350505050158015610740573d6000803e3d6000fd5b50610878565b60006064858361075691906126d5565b61076091906126a4565b90508973ffffffffffffffffffffffffffffffffffffffff166108fc829081150290604051600060405180830381858888f193505050501580156107a8573d6000803e3d6000fd5b5080826107b59190612717565b91506000606487846107c791906126d5565b6107d191906126a4565b905060008890508073ffffffffffffffffffffffffffffffffffffffff166108fc839081150290604051600060405180830381858888f1935050505015801561081e573d6000803e3d6000fd5b50818461082b9190612717565b93508973ffffffffffffffffffffffffffffffffffffffff166108fc859081150290604051600060405180830381858888f19350505050158015610873573d6000803e3d6000fd5b505050505b505050505050505050565b61089e83838360405180602001604052806000815250610a88565b505050565b6000806108af836112d0565b9050600073ffffffffffffffffffffffffffffffffffffffff168173ffffffffffffffffffffffffffffffffffffffff1603610920576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040161091790612797565b60405180910390fd5b80915050919050565b60008073ffffffffffffffffffffffffffffffffffffffff168273ffffffffffffffffffffffffffffffffffffffff1603610999576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040161099090612829565b60405180910390fd5b600360008373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff168152602001908152602001600020549050919050565b6060600180546109ef9061245f565b80601f0160208091040260200160405190810160405280929190818152602001828054610a1b9061245f565b8015610a685780601f10610a3d57610100808354040283529160200191610a68565b820191906000526020600020905b815481529060010190602001808311610a4b57829003601f168201915b5050505050905090565b610a84610a7d610cb9565b8383611108565b5050565b610a99610a93610cb9565b83610d7a565b610ad8576040517f08c379a0000000000000000000000000000000000000000000000000000000008152600401610acf90612626565b60405180910390fd5b610ae484848484611274565b50505050565b6060610af58261130d565b9050919050565b60076000815480929190610b0f90612849565b9190505550610b208260075461141f565b610b2c6007548261163c565b5050565b3373ffffffffffffffffffffffffffffffffffffffff166108fc479081150290604051600060405180830381858888f19350505050158015610b76573d6000803e3d6000fd5b50565b6000600560008473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200190815260200160002060008373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200190815260200160002060009054906101000a900460ff16905092915050565b6000634906490660e01b7bffffffffffffffffffffffffffffffffffffffffffffffffffffffff1916827bffffffffffffffffffffffffffffffffffffffffffffffffffffffff19161480610c675750610c66826116e0565b5b9050919050565b610c77816117c2565b610cb6576040517f08c379a0000000000000000000000000000000000000000000000000000000008152600401610cad90612797565b60405180910390fd5b50565b600033905090565b816004600083815260200190815260200160002060006101000a81548173ffffffffffffffffffffffffffffffffffffffff021916908373ffffffffffffffffffffffffffffffffffffffff160217905550808273ffffffffffffffffffffffffffffffffffffffff16610d34836108a3565b73ffffffffffffffffffffffffffffffffffffffff167f8c5be1e5ebec7d5bd14f71427d1e84f3dd0314c0f7b2291e5b200ac8c7c3b92560405160405180910390a45050565b600080610d86836108a3565b90508073ffffffffffffffffffffffffffffffffffffffff168473ffffffffffffffffffffffffffffffffffffffff161480610dc85750610dc78185610b79565b5b80610e0657508373ffffffffffffffffffffffffffffffffffffffff16610dee8461047c565b73ffffffffffffffffffffffffffffffffffffffff16145b91505092915050565b8273ffffffffffffffffffffffffffffffffffffffff16610e2f826108a3565b73ffffffffffffffffffffffffffffffffffffffff1614610e85576040517f08c379a0000000000000000000000000000000000000000000000000000000008152600401610e7c90612903565b60405180910390fd5b600073ffffffffffffffffffffffffffffffffffffffff168273ffffffffffffffffffffffffffffffffffffffff1603610ef4576040517f08c379a0000000000000000000000000000000000000000000000000000000008152600401610eeb90612995565b60405180910390fd5b610f018383836001611803565b8273ffffffffffffffffffffffffffffffffffffffff16610f21826108a3565b73ffffffffffffffffffffffffffffffffffffffff1614610f77576040517f08c379a0000000000000000000000000000000000000000000000000000000008152600401610f6e90612903565b60405180910390fd5b6004600082815260200190815260200160002060006101000a81549073ffffffffffffffffffffffffffffffffffffffff02191690556001600360008573ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff168152602001908152602001600020600082825403925050819055506001600360008473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200190815260200160002060008282540192505081905550816002600083815260200190815260200160002060006101000a81548173ffffffffffffffffffffffffffffffffffffffff021916908373ffffffffffffffffffffffffffffffffffffffff160217905550808273ffffffffffffffffffffffffffffffffffffffff168473ffffffffffffffffffffffffffffffffffffffff167fddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef60405160405180910390a46111038383836001611809565b505050565b8173ffffffffffffffffffffffffffffffffffffffff168373ffffffffffffffffffffffffffffffffffffffff1603611176576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040161116d90612a01565b60405180910390fd5b80600560008573ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200190815260200160002060008473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200190815260200160002060006101000a81548160ff0219169083151502179055508173ffffffffffffffffffffffffffffffffffffffff168373ffffffffffffffffffffffffffffffffffffffff167f17307eab39ab6107e8899845ad3d59bd9653f200f220920489ca2b5937696c31836040516112679190611d77565b60405180910390a3505050565b61127f848484610e0f565b61128b8484848461180f565b6112ca576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004016112c190612a93565b60405180910390fd5b50505050565b60006002600083815260200190815260200160002060009054906101000a900473ffffffffffffffffffffffffffffffffffffffff169050919050565b606061131882610c6e565b60006006600084815260200190815260200160002080546113389061245f565b80601f01602080910402602001604051908101604052809291908181526020018280546113649061245f565b80156113b15780601f10611386576101008083540402835291602001916113b1565b820191906000526020600020905b81548152906001019060200180831161139457829003601f168201915b5050505050905060006113c2611996565b905060008151036113d757819250505061141a565b60008251111561140c5780826040516020016113f4929190612aef565b6040516020818303038152906040529250505061141a565b611415846119ad565b925050505b919050565b600073ffffffffffffffffffffffffffffffffffffffff168273ffffffffffffffffffffffffffffffffffffffff160361148e576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040161148590612b5f565b60405180910390fd5b611497816117c2565b156114d7576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004016114ce90612bcb565b60405180910390fd5b6114e5600083836001611803565b6114ee816117c2565b1561152e576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040161152590612bcb565b60405180910390fd5b6001600360008473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200190815260200160002060008282540192505081905550816002600083815260200190815260200160002060006101000a81548173ffffffffffffffffffffffffffffffffffffffff021916908373ffffffffffffffffffffffffffffffffffffffff160217905550808273ffffffffffffffffffffffffffffffffffffffff16600073ffffffffffffffffffffffffffffffffffffffff167fddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef60405160405180910390a4611638600083836001611809565b5050565b611645826117c2565b611684576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040161167b90612c5d565b60405180910390fd5b806006600084815260200190815260200160002090816116a49190612e29565b507ff8e1a15aba9398e019f0b49df1a4fde98ee17ae345cb5f6b5e2c27f5033e8ce7826040516116d491906120b4565b60405180910390a15050565b60007f80ac58cd000000000000000000000000000000000000000000000000000000007bffffffffffffffffffffffffffffffffffffffffffffffffffffffff1916827bffffffffffffffffffffffffffffffffffffffffffffffffffffffff191614806117ab57507f5b5e139f000000000000000000000000000000000000000000000000000000007bffffffffffffffffffffffffffffffffffffffffffffffffffffffff1916827bffffffffffffffffffffffffffffffffffffffffffffffffffffffff1916145b806117bb57506117ba82611a15565b5b9050919050565b60008073ffffffffffffffffffffffffffffffffffffffff166117e4836112d0565b73ffffffffffffffffffffffffffffffffffffffff1614159050919050565b50505050565b50505050565b60006118308473ffffffffffffffffffffffffffffffffffffffff16611a7f565b15611989578373ffffffffffffffffffffffffffffffffffffffff1663150b7a02611859610cb9565b8786866040518563ffffffff1660e01b815260040161187b9493929190612f50565b6020604051808303816000875af19250505080156118b757506040513d601f19601f820116820180604052508101906118b49190612fb1565b60015b611939573d80600081146118e7576040519150601f19603f3d011682016040523d82523d6000602084013e6118ec565b606091505b506000815103611931576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040161192890612a93565b60405180910390fd5b805181602001fd5b63150b7a0260e01b7bffffffffffffffffffffffffffffffffffffffffffffffffffffffff1916817bffffffffffffffffffffffffffffffffffffffffffffffffffffffff19161491505061198e565b600190505b949350505050565b606060405180602001604052806000815250905090565b60606119b882610c6e565b60006119c2611996565b905060008151116119e25760405180602001604052806000815250611a0d565b806119ec84611aa2565b6040516020016119fd929190612aef565b6040516020818303038152906040525b915050919050565b60007f01ffc9a7000000000000000000000000000000000000000000000000000000007bffffffffffffffffffffffffffffffffffffffffffffffffffffffff1916827bffffffffffffffffffffffffffffffffffffffffffffffffffffffff1916149050919050565b6000808273ffffffffffffffffffffffffffffffffffffffff163b119050919050565b606060006001611ab184611b70565b01905060008167ffffffffffffffff811115611ad057611acf612145565b5b6040519080825280601f01601f191660200182016040528015611b025781602001600182028036833780820191505090505b509050600082602001820190505b600115611b65578080600190039150507f3031323334353637383961626364656600000000000000000000000000000000600a86061a8153600a8581611b5957611b58612646565b5b04945060008503611b10575b819350505050919050565b600080600090507a184f03e93ff9f4daa797ed6e38ed64bf6a1f0100000000000000008310611bce577a184f03e93ff9f4daa797ed6e38ed64bf6a1f0100000000000000008381611bc457611bc3612646565b5b0492506040810190505b6d04ee2d6d415b85acef81000000008310611c0b576d04ee2d6d415b85acef81000000008381611c0157611c00612646565b5b0492506020810190505b662386f26fc100008310611c3a57662386f26fc100008381611c3057611c2f612646565b5b0492506010810190505b6305f5e1008310611c63576305f5e1008381611c5957611c58612646565b5b0492506008810190505b6127108310611c88576127108381611c7e57611c7d612646565b5b0492506004810190505b60648310611cab5760648381611ca157611ca0612646565b5b0492506002810190505b600a8310611cba576001810190505b80915050919050565b6000604051905090565b600080fd5b600080fd5b60007fffffffff0000000000000000000000000000000000000000000000000000000082169050919050565b611d0c81611cd7565b8114611d1757600080fd5b50565b600081359050611d2981611d03565b92915050565b600060208284031215611d4557611d44611ccd565b5b6000611d5384828501611d1a565b91505092915050565b60008115159050919050565b611d7181611d5c565b82525050565b6000602082019050611d8c6000830184611d68565b92915050565b600081519050919050565b600082825260208201905092915050565b60005b83811015611dcc578082015181840152602081019050611db1565b60008484015250505050565b6000601f19601f8301169050919050565b6000611df482611d92565b611dfe8185611d9d565b9350611e0e818560208601611dae565b611e1781611dd8565b840191505092915050565b60006020820190508181036000830152611e3c8184611de9565b905092915050565b6000819050919050565b611e5781611e44565b8114611e6257600080fd5b50565b600081359050611e7481611e4e565b92915050565b600060208284031215611e9057611e8f611ccd565b5b6000611e9e84828501611e65565b91505092915050565b600073ffffffffffffffffffffffffffffffffffffffff82169050919050565b6000611ed282611ea7565b9050919050565b611ee281611ec7565b82525050565b6000602082019050611efd6000830184611ed9565b92915050565b611f0c81611ec7565b8114611f1757600080fd5b50565b600081359050611f2981611f03565b92915050565b60008060408385031215611f4657611f45611ccd565b5b6000611f5485828601611f1a565b9250506020611f6585828601611e65565b9150509250929050565b600080600060608486031215611f8857611f87611ccd565b5b6000611f9686828701611f1a565b9350506020611fa786828701611f1a565b9250506040611fb886828701611e65565b9150509250925092565b600080600080600080600080610100898b031215611fe357611fe2611ccd565b5b6000611ff18b828c01611f1a565b98505060206120028b828c01611f1a565b97505060406120138b828c01611f1a565b96505060606120248b828c01611f1a565b95505060806120358b828c01611e65565b94505060a06120468b828c01611e65565b93505060c06120578b828c01611e65565b92505060e06120688b828c01611e65565b9150509295985092959890939650565b60006020828403121561208e5761208d611ccd565b5b600061209c84828501611f1a565b91505092915050565b6120ae81611e44565b82525050565b60006020820190506120c960008301846120a5565b92915050565b6120d881611d5c565b81146120e357600080fd5b50565b6000813590506120f5816120cf565b92915050565b6000806040838503121561211257612111611ccd565b5b600061212085828601611f1a565b9250506020612131858286016120e6565b9150509250929050565b600080fd5b600080fd5b7f4e487b7100000000000000000000000000000000000000000000000000000000600052604160045260246000fd5b61217d82611dd8565b810181811067ffffffffffffffff8211171561219c5761219b612145565b5b80604052505050565b60006121af611cc3565b90506121bb8282612174565b919050565b600067ffffffffffffffff8211156121db576121da612145565b5b6121e482611dd8565b9050602081019050919050565b82818337600083830152505050565b600061221361220e846121c0565b6121a5565b90508281526020810184848401111561222f5761222e612140565b5b61223a8482856121f1565b509392505050565b600082601f8301126122575761225661213b565b5b8135612267848260208601612200565b91505092915050565b6000806000806080858703121561228a57612289611ccd565b5b600061229887828801611f1a565b94505060206122a987828801611f1a565b93505060406122ba87828801611e65565b925050606085013567ffffffffffffffff8111156122db576122da611cd2565b5b6122e787828801612242565b91505092959194509250565b600067ffffffffffffffff82111561230e5761230d612145565b5b61231782611dd8565b9050602081019050919050565b6000612337612332846122f3565b6121a5565b90508281526020810184848401111561235357612352612140565b5b61235e8482856121f1565b509392505050565b600082601f83011261237b5761237a61213b565b5b813561238b848260208601612324565b91505092915050565b600080604083850312156123ab576123aa611ccd565b5b60006123b985828601611f1a565b925050602083013567ffffffffffffffff8111156123da576123d9611cd2565b5b6123e685828601612366565b9150509250929050565b6000806040838503121561240757612406611ccd565b5b600061241585828601611f1a565b925050602061242685828601611f1a565b9150509250929050565b7f4e487b7100000000000000000000000000000000000000000000000000000000600052602260045260246000fd5b6000600282049050600182168061247757607f821691505b60208210810361248a57612489612430565b5b50919050565b7f4552433732313a20617070726f76616c20746f2063757272656e74206f776e6560008201527f7200000000000000000000000000000000000000000000000000000000000000602082015250565b60006124ec602183611d9d565b91506124f782612490565b604082019050919050565b6000602082019050818103600083015261251b816124df565b9050919050565b7f4552433732313a20617070726f76652063616c6c6572206973206e6f7420746f60008201527f6b656e206f776e6572206f7220617070726f76656420666f7220616c6c000000602082015250565b600061257e603d83611d9d565b915061258982612522565b604082019050919050565b600060208201905081810360008301526125ad81612571565b9050919050565b7f4552433732313a2063616c6c6572206973206e6f7420746f6b656e206f776e6560008201527f72206f7220617070726f76656400000000000000000000000000000000000000602082015250565b6000612610602d83611d9d565b915061261b826125b4565b604082019050919050565b6000602082019050818103600083015261263f81612603565b9050919050565b7f4e487b7100000000000000000000000000000000000000000000000000000000600052601260045260246000fd5b7f4e487b7100000000000000000000000000000000000000000000000000000000600052601160045260246000fd5b60006126af82611e44565b91506126ba83611e44565b9250826126ca576126c9612646565b5b828204905092915050565b60006126e082611e44565b91506126eb83611e44565b92508282026126f981611e44565b915082820484148315176127105761270f612675565b5b5092915050565b600061272282611e44565b915061272d83611e44565b925082820390508181111561274557612744612675565b5b92915050565b7f4552433732313a20696e76616c696420746f6b656e2049440000000000000000600082015250565b6000612781601883611d9d565b915061278c8261274b565b602082019050919050565b600060208201905081810360008301526127b081612774565b9050919050565b7f4552433732313a2061646472657373207a65726f206973206e6f74206120766160008201527f6c6964206f776e65720000000000000000000000000000000000000000000000602082015250565b6000612813602983611d9d565b915061281e826127b7565b604082019050919050565b6000602082019050818103600083015261284281612806565b9050919050565b600061285482611e44565b91507fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff820361288657612885612675565b5b600182019050919050565b7f4552433732313a207472616e736665722066726f6d20696e636f72726563742060008201527f6f776e6572000000000000000000000000000000000000000000000000000000602082015250565b60006128ed602583611d9d565b91506128f882612891565b604082019050919050565b6000602082019050818103600083015261291c816128e0565b9050919050565b7f4552433732313a207472616e7366657220746f20746865207a65726f2061646460008201527f7265737300000000000000000000000000000000000000000000000000000000602082015250565b600061297f602483611d9d565b915061298a82612923565b604082019050919050565b600060208201905081810360008301526129ae81612972565b9050919050565b7f4552433732313a20617070726f766520746f2063616c6c657200000000000000600082015250565b60006129eb601983611d9d565b91506129f6826129b5565b602082019050919050565b60006020820190508181036000830152612a1a816129de565b9050919050565b7f4552433732313a207472616e7366657220746f206e6f6e20455243373231526560008201527f63656976657220696d706c656d656e7465720000000000000000000000000000602082015250565b6000612a7d603283611d9d565b9150612a8882612a21565b604082019050919050565b60006020820190508181036000830152612aac81612a70565b9050919050565b600081905092915050565b6000612ac982611d92565b612ad38185612ab3565b9350612ae3818560208601611dae565b80840191505092915050565b6000612afb8285612abe565b9150612b078284612abe565b91508190509392505050565b7f4552433732313a206d696e7420746f20746865207a65726f2061646472657373600082015250565b6000612b49602083611d9d565b9150612b5482612b13565b602082019050919050565b60006020820190508181036000830152612b7881612b3c565b9050919050565b7f4552433732313a20746f6b656e20616c7265616479206d696e74656400000000600082015250565b6000612bb5601c83611d9d565b9150612bc082612b7f565b602082019050919050565b60006020820190508181036000830152612be481612ba8565b9050919050565b7f45524337323155524953746f726167653a2055524920736574206f66206e6f6e60008201527f6578697374656e7420746f6b656e000000000000000000000000000000000000602082015250565b6000612c47602e83611d9d565b9150612c5282612beb565b604082019050919050565b60006020820190508181036000830152612c7681612c3a565b9050919050565b60008190508160005260206000209050919050565b60006020601f8301049050919050565b600082821b905092915050565b600060088302612cdf7fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff82612ca2565b612ce98683612ca2565b95508019841693508086168417925050509392505050565b6000819050919050565b6000612d26612d21612d1c84611e44565b612d01565b611e44565b9050919050565b6000819050919050565b612d4083612d0b565b612d54612d4c82612d2d565b848454612caf565b825550505050565b600090565b612d69612d5c565b612d74818484612d37565b505050565b5b81811015612d9857612d8d600082612d61565b600181019050612d7a565b5050565b601f821115612ddd57612dae81612c7d565b612db784612c92565b81016020851015612dc6578190505b612dda612dd285612c92565b830182612d79565b50505b505050565b600082821c905092915050565b6000612e0060001984600802612de2565b1980831691505092915050565b6000612e198383612def565b9150826002028217905092915050565b612e3282611d92565b67ffffffffffffffff811115612e4b57612e4a612145565b5b612e55825461245f565b612e60828285612d9c565b600060209050601f831160018114612e935760008415612e81578287015190505b612e8b8582612e0d565b865550612ef3565b601f198416612ea186612c7d565b60005b82811015612ec957848901518255600182019150602085019450602081019050612ea4565b86831015612ee65784890151612ee2601f891682612def565b8355505b6001600288020188555050505b505050505050565b600081519050919050565b600082825260208201905092915050565b6000612f2282612efb565b612f2c8185612f06565b9350612f3c818560208601611dae565b612f4581611dd8565b840191505092915050565b6000608082019050612f656000830187611ed9565b612f726020830186611ed9565b612f7f60408301856120a5565b8181036060830152612f918184612f17565b905095945050505050565b600081519050612fab81611d03565b92915050565b600060208284031215612fc757612fc6611ccd565b5b6000612fd584828501612f9c565b9150509291505056fea2646970667358221220e789422279ddc18ec503788c15ef52b0042364b2063aef6cc7f1d0435c3c9f7b64736f6c63430008130033"