import React, { createContext, useContext, useEffect, useState } from "react";
import { useWeb3 } from "./Web3Context";

type UserContextType = {
    user : string | undefined,
}

const UserContext = createContext<UserContextType>({
    user : undefined
})

export const useUser = () => useContext(UserContext)

export const UserProvider = ({children}:{children: React.ReactNode}) => {
    const {web3} = useWeb3()
    const [user,setUser] = useState<string |undefined>(undefined)
    const fetchUserAccount = async() =>{
        const accounts = await web3?.eth.getAccounts()
        setUser(accounts ? accounts[0] : undefined)
    }

    useEffect(()=>{
        fetchUserAccount()
    },[web3])

    return(
        <UserContext.Provider value={{
            user:user,
        }}>
            {children}
        </UserContext.Provider>
    )
}