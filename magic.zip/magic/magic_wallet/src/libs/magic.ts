import { Magic } from 'magic-sdk';

export const magic = new Magic("pk_live_6B5FCCFF6378BBC6",{
    network: 'goerli'
})