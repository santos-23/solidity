import { Button } from "@chakra-ui/react";
import { useWeb3 } from "../context/Web3Context";
import { magic } from "../libs/magic";

const DisconnectButton = () => {
    const { initializeWeb3 } = useWeb3()
    const handleDisconnect = async() =>{
        try{
            await magic.user.logout();
            initializeWeb3()
        }catch(error){
            console.log("Handle Disconnect Errors: ", error)
        }
    }
    return(
        <Button onClick={handleDisconnect}>
            Disconnect
        </Button>
    )
}

export default DisconnectButton;