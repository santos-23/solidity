import { Box, Button, Divider, HStack, Input, Text, VStack } from "@chakra-ui/react";
import { useState } from "react";
import { useUser } from "../context/UserContext";
import { useWeb3 } from "../context/Web3Context";

const SignMessage = () => {
    const { web3 } = useWeb3()
    const { user } = useUser()

    const [message,setMessage] = useState("")
    const [signature,setSignature] = useState("")

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) =>{
        setMessage(e.target.value)
    }

    const handleSignMessage = async() => {
        if(user && web3){
            try{
                const signedMessage = await web3.eth.personal.sign(message,user,"")
                setSignature(signedMessage)
            }catch(error){
                console.error("handleSignMessage: ",error)
            }
        }
    }

    return(
        <VStack>
        <Divider my={7} />
        <Text fontFamily="heading" fontWeight={"bold"} fontSize={22} align={"center"}>SIGN-MESSAGE</Text>
        <HStack justifyContent="flex-start" alignItems="flex-start">
            <Box
                maxW="sm"
                borderWidth="1px"
                borderRadius="lg"
                overflow="hidden"
                padding="10px"
            >
                <VStack>
                    <Input
                        placeholder="set message"
                        maxLength={30}
                        onChange={handleInputChange}
                        w={"300px"}
                    />
                    <Button onClick={handleSignMessage} isDisabled={!message}>
                        Sign Message
                    </Button>
                </VStack>
                {signature && <Text>{`Signature: ${signature}`}</Text>}
            </Box>
        </HStack>
        </VStack>
    )
}

export default SignMessage;