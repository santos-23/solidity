import { Button } from "@chakra-ui/react";
import { useEffect, useState } from "react";
import { magic } from "../libs/magic";

const ShowUIButton = () => {
    const [showButton, setShowButton] = useState(false)
    const checkWalletType = async() => {
        try{
            const walletInfo = await magic.user.getInfo()
            console.log(walletInfo)
            const isMagicWallet = true
            // const isMagicWallet = walletInfo.walletType === "magic" // ?????
            setShowButton(isMagicWallet)
        }catch(error){
            console.log("checkWalletType: ",error)
        }
    }

    useEffect(()=>{
        checkWalletType()
    },[magic])

    const handleShowUI = async () => {
        try {
            await magic?.wallet.showUI()
        } catch (error) {
            console.error("handleShowUI:", error)
        }
    }

    return showButton ? <Button onClick={handleShowUI}>Show UI</Button> : null
}

export default ShowUIButton;