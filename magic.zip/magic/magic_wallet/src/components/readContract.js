import { Divider, Flex, Text } from "@chakra-ui/react";
import { ethers } from "ethers";
import { useEffect, useState } from "react";
import { useUser } from "../context/UserContext";
import { magic } from "../libs/magic";

const ReadContract = (props) =>{
    const { user } = useUser()
    const [msg,setMsg] = useState('')

    useEffect(async()=>{
        const provider = new ethers.providers.Web3Provider(magic.rpcProvider);
        const signer = provider.getSigner(user);
        const contractABI =
            '[{"inputs": [{"internalType": "string","name": "_initMessage","type": "string"}],"stateMutability": "nonpayable","type": "constructor"},{"inputs": [],"name": "message","outputs": [{"internalType": "string","name": "","type": "string"}],"stateMutability": "view","type": "function"},{"inputs": [{"internalType": "string","name": "_message","type": "string"}],"name": "setMessage","outputs": [],"stateMutability": "nonpayable","type": "function"} ]';
        const ContractAddress = props.contractAddress;
        const contract = new ethers.Contract(ContractAddress, contractABI, signer);
        const message = await contract.message();
        setMsg(message);
    },[msg])
    

    return(
        <Flex direction={"column"}>
            <Text fontWeight="bold">Contract Message:</Text>
            <Text fontFamily="monospace">{msg}</Text>
            <Divider my={2} />
        </Flex>
    )
}

export default ReadContract;