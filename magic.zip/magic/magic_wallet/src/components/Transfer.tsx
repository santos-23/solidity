import { Flex } from "@chakra-ui/react"
import { ethers } from "ethers"
import { contractABI } from "../ABI_file"
import { useUser } from "../context/UserContext"


const TransferNFT = () => {
    const {user} = useUser();

    const handleTransfer = async() => {
        const contract = new ethers.Contract("",contractABI)
    }

    return(
        <Flex direction={"column"}>

        </Flex>
    )
}

export default TransferNFT;