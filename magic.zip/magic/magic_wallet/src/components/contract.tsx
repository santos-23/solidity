import { Button, Divider, Flex, Input, Text } from "@chakra-ui/react";
import { Signer, ethers } from "ethers";
import { useEffect, useState } from "react";
import { bytecode, contractABI, contractAbi } from "../ABI_file";
import { useUser } from "../context/UserContext";
import { useWeb3 } from "../context/Web3Context";

interface myProps{
    signer: Signer
}

const Contract = (props:myProps) => {
    const {user} = useUser()
    const {web3} = useWeb3()
    const [contractAddress, setContractAddress] = useState('')
    const [toAddress,setToAddress] = useState('');
    const [admin,setAdmin] = useState('')
    const [artist,setArtist] = useState('')
    const [royalityAddress,setRoyalityAddress] = useState('')
    const [royality,setRoyality] = useState(0)
    const [commission,setCommission] = useState(0)
    const [amount,setAmount] = useState(0)
    const [uri,setUri] = useState('')
    const [tokenId,setTokenId] = useState('')
    const signer = props.signer
    // const provider = new ethers.providers.JsonRpcProvider("https://goerli.infura.io/v3/2230b04db26b44faaede09a00c6a02c7","goerli")
    // const signer = provider.getSigner(user)

    const handleDeploy = async() => {
        console.log(props.signer)
        const contractFactory = new ethers.ContractFactory(contractABI,bytecode,props.signer)
        const contract = await contractFactory.deploy();
        console.log("contract_address: ",contract.address);
        setContractAddress(contract.address)
        const receipt = await contract.deployed();
        console.log("receipt: ",receipt)
    }

    const handleMint = async() => {
        
        const contract = new ethers.Contract(contractAddress,contractABI,props.signer)
        console.log(contract)
        const tx = await contract.mint(user,"https://ipfs.io/ipfs/Qmd8rQZA2bcJrQWRYa5TwXwUH453k2Hor3gaVMNQ9vLEeq/3.json")
        console.log(tx)
        await tx.wait()
    }

    // const handleSend = async() => {
    //     // const contractFactory = new ethers.ContractFactory(demoABI,demoByteCode,props.signer)
    //     // const contract = await contractFactory.deploy();
    //     // console.log(contract.address)
    //     const contract = new ethers.Contract("0x5FA3b88d64bf8Ea87383FD4975b7aa9f817860ca",demoABI,props.signer)
    //     // const result = await contract.mint(user);
    //     // console.log(result)
    //     const result = await contract.transFer("0x6e654df4037e0d0313E6E6a07701FED65CBF956f",{value: ethers.utils.parseEther('0.001')})
    //     console.log(result)
    //     // web3?.eth.sendTransaction({
    //     //     from: admin,
    //     //     to: artist,
    //     //     value: web3.utils.toWei(0.001,'ether')
    //     // }).then((receipt)=>{
    //     //     console.log(receipt)
    //     // })
    // }

    const handleSend = async() => {
        // const contractFactory = new ethers.ContractFactory(contractAbi,contractByte,props.signer)
        // const contract = await contractFactory.deploy();
        // console.log("contract_address: ",contract.address); // 0x1d01179B44bB6B46Fb6057e4711590e4dB313088
        const contract = new ethers.Contract("0x1d01179B44bB6B46Fb6057e4711590e4dB313088",contractAbi,props.signer)
        const tx = await contract.mint(user,"https://ipfs.io/ipfs/Qmd8rQZA2bcJrQWRYa5TwXwUH453k2Hor3gaVMNQ9vLEeq/1.json")
        // const tx = await contract.magicTransfer(
        //     admin,toAddress,artist,royalityAddress,royality,commission,tokenId,
        //     {value: ethers.utils.parseEther(`${amount}`)}
        // )
        console.log(tx)
        await tx.wait()
    }
// 0x6800144cCf574F777Cb11e26eA3c10F7dF4bf6f9
// 0x946cBd53b8cd9CfCc74E2dDE9F1B5Ddd241CADd5 - con
// 0xafdE767A5e0cE748AA293355281489D15995A7Af - con
// 0xe45D94Cd161eC171e15aeD6Bce6B09AcBEf916C9
    useEffect(()=>{
        if(contractAddress === ''){
            setContractAddress("0xafdE767A5e0cE748AA293355281489D15995A7Af");
        }
    },[])

    const handleTransfer = async() => {
        const contract = new ethers.Contract("0xe45D94Cd161eC171e15aeD6Bce6B09AcBEf916C9",contractABI,props.signer)
        const tx = await contract.magicTransfer(
            admin,toAddress,artist,royalityAddress,royality,commission,1,tokenId
            // ,{value: ethers.utils.parseEther('0.001')}
        )
        console.log(tx)
        await tx.wait()
        let remainingAmount = amount;
        if(admin === artist){
            await web3?.eth.sendTransaction({
                from: user,
                to: artist,
                value: web3?.utils.toWei(remainingAmount,"ether")
            }).then((receipt)=>{
                console.log(receipt)
            })
        }else{
            let transferCommission = (remainingAmount * commission) / 100;
            const tx = await signer.sendTransaction({
                to: admin,
                value: web3?.utils.toWei(transferCommission,"ether")
            });
            const receipt = await tx.wait();
            console.log(receipt)

            remainingAmount = remainingAmount - transferCommission;
            let royalityAmount = (remainingAmount * royality) / 100;

            const tx1 = await signer.sendTransaction({
                to: royalityAddress,
                value: web3?.utils.toWei(royalityAmount,"ether")
            });
            const receipt1 = await tx1.wait();
            console.log(receipt1)

            remainingAmount = remainingAmount - royalityAmount;

            const tx2 = await signer.sendTransaction({
                to: artist,
                value: web3?.utils.toWei(remainingAmount,"ether")
            });
            const receipt2 = await tx2.wait();
            console.log(receipt2)
        }
        
        // const txnParams = {
        //     from: user,
        //     to: admin,
        //     value: web3?.utils.toWei(0.005,'ether'),
        //     gas: 21000
        // }
        // const receipt = await web3?.eth.signTransaction(txnParams)
        // console.log(receipt)
        // const txnParams1 = {
        //     from: user,
        //     to: artist,
        //     value: web3?.utils.toWei(0.005,'ether'),
        //     gas: 21000
        // }
        // const receipt1 = await web3?.eth.signTransaction(txnParams1)
        // console.log(receipt1)
    
        // const tx1 = await web3?.eth.sendTransaction(txnParams as any)
        // console.log(tx1)
        // const tx2 = await web3?.eth.sendTransaction(txnParams1 as any)
        // console.log(tx2)
    }

// 0xf9200b48D73FD0cEB081448884Fa239cFA592744 - shantos   admin
// 0x6e654df4037e0d0313E6E6a07701FED65CBF956f - santhosh  addr1
// 0x67e5F97B5B45b357862DaFEd6761fD90663d7131 - krsan     addr2
// 0xc9b158C9F8C504CB3eFfC9740bfa454F00fcAF27 - metamask  royality

    const collect = async() => {
        // const contract = new ethers.Contract("0x946cBd53b8cd9CfCc74E2dDE9F1B5Ddd241CADd5",contractABI,signer)
        const contract = new ethers.Contract("0x1d01179B44bB6B46Fb6057e4711590e4dB313088",contractAbi,props.signer)
        const tx = await contract.collect();
        console.log(tx)
        await tx.wait()
    }


    return(
        <Flex direction={"column"}>
            <Divider my={7} />
            <Text fontFamily="heading" fontWeight={"bold"} fontSize={22} align={"center"}>Send Transaction</Text>
            <Divider my={2} />
            <Button onClick={handleDeploy}>Deploy</Button>
            <Divider my={2} />
            <Text fontWeight="bold">Contract Address:</Text>
            <Text fontFamily="monospace">{contractAddress}</Text>
            <Divider my={2} />
            <Input placeholder="Address to mint NFT" value={toAddress} maxLength={50} onChange={(e:any)=>setToAddress(e.target.value)} w={"300px"} />
            <Divider my={1} />
            <Input placeholder="Enter token uri for NFT" value={uri} maxLength={70} onChange={(e:any)=>setUri(e.target.value)} w={"300px"} />
            <Divider my={1} />
            <Button onClick={handleMint}>Mint</Button>
            <Divider my={2} />
            <Input placeholder="Admin of the NFT" value={admin} maxLength={50} onChange={(e:any)=>setAdmin(e.target.value)} w={"300px"} />
            <Divider my={1} />
            <Input placeholder="Address to transfer NFT" value={toAddress} maxLength={50} onChange={(e:any)=>setToAddress(e.target.value)} w={"300px"} />
            <Divider my={1} />
            <Input placeholder="Address of NFT holder" value={artist} maxLength={50} onChange={(e:any)=>setArtist(e.target.value)} w={"300px"} />
            <Divider my={1} />
            <Input placeholder="Address for royality amount" value={royalityAddress} maxLength={50} onChange={(e:any)=>setRoyalityAddress(e.target.value)} w={"300px"} />
            <Divider my={1} />
            <Input placeholder="Enter royality percentage" value={royality} maxLength={30} onChange={(e:any)=>setRoyality(e.target.value)} w={"300px"} />
            <Divider my={1} />
            <Input placeholder="Enter transfer commission percentage" value={commission} maxLength={30} onChange={(e:any)=>setCommission(e.target.value)} w={"300px"} />
            <Divider my={1} />
            <Input placeholder="Enter amount for NFT" value={amount} maxLength={30} onChange={(e:any)=>setAmount(e.target.value)} w={"300px"} />
            <Divider my={1} />
            <Input placeholder="Enter tokenId of NFT" value={tokenId} maxLength={30} onChange={(e:any)=>setTokenId(e.target.value)} w={"300px"} />
            <Divider my={1} />
            <Button onClick={handleTransfer}>getNFT</Button>
            <Divider my={2} />
            <Button onClick={handleSend}>Send</Button>
            <Divider my={2} />
            <Button onClick={collect}>collect</Button>
        </Flex>
    )
}

export default Contract;

//0x2cEc1183F4E1bc0A1e78E76aBC00C80448e1B586