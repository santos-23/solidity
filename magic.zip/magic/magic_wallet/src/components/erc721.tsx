import { Button, Divider, Flex, Input, Text } from "@chakra-ui/react";
import { Signer, ethers } from "ethers";
import { useState } from "react";
import { ERC721ABI, bytecode721 } from "../abi";
import { useUser } from "../context/UserContext";
import { useWeb3 } from "../context/Web3Context";

interface myProps{
    signer: Signer
}

const ERC721 = (props: myProps) => {
    // const [web3,setWeb3] = useState<any>()
    const {user} = useUser();
    const {web3} = useWeb3()
    const [toAddress,setToAddress] = useState('')
    const [tokenId,setTokenId] = useState('')
    const [contractAddress, setContractAddress] = useState('')
    // const provider = new ethers.providers.JsonRpcProvider("https://goerli.infura.io/v3/d45ef8d0c163493fb59babc623f635b4","goerli")
    // const signer = provider.getSigner(user)

    const handleDeploy = async() => {
        try {
            const contractFactory = new ethers.ContractFactory(ERC721ABI,bytecode721,props.signer)
            const contract = await contractFactory.deploy();
            console.log(contract)
            setContractAddress(contract.address)
            const receipt = await contract.deployed()
            console.log(receipt)
            // console.log('done1')
            // const contract = new web3.eth.Contract(ERC721ABI,"0x7E3c781248193Ab93E7C149b99d372860D2869bD")
            // console.log(contract)
            // const gas = await contract.methods.mint().estimateGas({ from: "0xf9200b48D73FD0cEB081448884Fa239cFA592744" });
            // console.log('done3')
            // contract.methods.name().call()
            //     .then((receipt:any)=>{
            //         console.log("receipt: ",receipt)
            //     })
            //     .catch((error:any)=>{
            //         console.log(error)
            //     })
            // contract.methods.mint()
            //     .send({ from:"0xf9200b48D73FD0cEB081448884Fa239cFA592744"})
            //     .on('transactionHash',(hash:any)=>{
            //         console.log("transactionHash: ",hash)
            //     })
            //     .then((receipt:any)=>{
            //         console.log("receipt: ",receipt)
            //     })
            //     .catch((error:any)=>{
            //         console.log(error)
            //     })
        } catch (error) {
            console.log(error)
        }
    }

    const handleMint = async() => {
        try {
            const contract = new ethers.Contract(contractAddress,ERC721ABI,props.signer)
            const receipt = await contract.mint();
            console.log(receipt)
        } catch (error) {
            console.log(error)
        }
    }

    const handleTransfer = async() => {
        try {
            const contract = new ethers.Contract(contractAddress,ERC721ABI,props.signer)
            const receipt = await contract.TransferNFT(toAddress,tokenId)
            console.log(receipt)
        } catch (error) {
            console.log(error)
        }
    }

    return(
        <Flex direction={"column"}>
            <Divider my={7} />
            <Text fontFamily="heading" fontWeight={"bold"} fontSize={22} align={"center"}>ERC-721</Text>
            <Divider my={2} />
            <Button onClick={handleDeploy}>Deploy</Button>
            <Divider my={2} />
            <Text fontWeight="bold">Contract Address:</Text>
            <Text fontFamily="monospace">{contractAddress}</Text>
            <Divider my={2} />
            <Button onClick={handleMint}>Mint</Button>
            <Divider my={2} />
            <Input value={toAddress} onChange={(e: any) => setToAddress(e.target.value)} placeholder="Address of the receiver" />
            <Divider my={2} />
            <Input value={tokenId} onChange={(e: any) => setTokenId(e.target.value)} placeholder="Enter NFT tokenId" />
            <Divider my={2} />
            <Button onClick={handleTransfer}>Transfer</Button>
            <Divider my={2} />
        </Flex>
    )
}

export default ERC721;