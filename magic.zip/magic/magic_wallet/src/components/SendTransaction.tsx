import { Button, Divider, Flex, Input, Text } from "@chakra-ui/react";
import { useState } from "react";
import { useUser } from "../context/UserContext";
import { useWeb3 } from "../context/Web3Context";


const SendTransaction = () => {
    const {user} = useUser();
    const {web3} = useWeb3();
    const [toAddress,setToAddress] = useState('');
    const [amount,setAmount] = useState('');

    const handleTransfer = () => {
        const txnParams = {
            from: user,
            to: toAddress,
            value: web3?.utils.toWei(amount,'ether'),
            gas: 21000
        }
        web3?.eth.sendTransaction(txnParams as any)
            .on('transactionHash',(hash)=>{
                console.log(hash)
            })
            .then((receipt)=>{
                console.log(receipt)
            })
            .catch((error)=>{
                console.log(error)
            })
    }

    return(
        <Flex direction={"column"}>
            <Divider my={7} />
            <Text fontFamily="heading" fontWeight={"bold"} fontSize={22} align={"center"}>Send Transaction</Text>
            <Divider my={2} />
            <Input placeholder="Enter recipient address" maxLength={30} value={toAddress} onChange={(e)=>setToAddress(e.target.value)} />
            <Divider my={2} />
            <Input placeholder="Enter amount(ETH)" maxLength={30} value={amount} onChange={(e)=>setAmount(e.target.value)} />
            <Divider my={2} />
            <Button onClick={handleTransfer}>Transfer</Button>
            <Divider my={2} />
        </Flex>
    )
}

export default SendTransaction;