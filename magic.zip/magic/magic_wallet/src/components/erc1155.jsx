import { Button, Divider, Flex, Input, Text } from "@chakra-ui/react";
import { ethers } from "ethers";
import { useState } from "react";
import { useUser } from "../context/UserContext";
import { useWeb3 } from "../context/Web3Context";
import { magic } from "../libs/magic";
import { byteCode, transferABI } from "../transferABI";
import Contract from "./contract";
import ERC20 from "./erc20";
import ERC721 from "./erc721";

const ERC1155 = () => {
    const { user } = useUser()
    const { web3 } = useWeb3()
    const [contractAddress,setContractAddress] = useState('')
    const [recipientAddress,setRecipientAddress] = useState("")
    const [tokenID,setTokenID] = useState(0);
    const [quantity,setQuantity] = useState(0);

    const provider = new ethers.providers.Web3Provider(magic.rpcProvider);
    let signer = provider.getSigner(user)
    // const provider = new ethers.providers.JsonRpcProvider("https://goerli.infura.io/v3/d45ef8d0c163493fb59babc623f635b4","goerli")
    // const signer = provider.getSigner(user)
    console.log("signer: ",signer);

    const handleDeploy = async() => {
        const contractFactory = new ethers.ContractFactory(transferABI,byteCode,signer);
        const contract = await contractFactory.deploy();
        console.log("contract_address: ",contract.address);
        setContractAddress(contract.address)
        const receipt = await contract.deployed();
        console.log("receipt: ",receipt)
    }

    const handleMint = async() => { //0xAC96768dA33930437ecedC8837B186a380C85510
        const contract = new ethers.Contract("0xAC96768dA33930437ecedC8837B186a380C85510",transferABI,signer);
        const tx = await contract.mint(user,tokenID,quantity)
        console.log(tx)
        await tx.wait()
    }

    const handleTransfer = async() => {
        console.log(recipientAddress)
        const contract = new ethers.Contract("0xAC96768dA33930437ecedC8837B186a380C85510",transferABI,signer);
        const tx = await contract.safeTransferFrom(signer._address,"0x6e654df4037e0d0313E6E6a07701FED65CBF956f",tokenID,quantity,"0x00")
        console.log(tx)
        await tx.wait()
        const name = await contract.name();
        console.log("name: ",name)
    }

    return(
        <Flex direction={"column"}>
            <Contract signer={signer} />
            <Divider my={7} />
            <Text fontFamily="heading" fontWeight={"bold"} fontSize={22} align={"center"}>ERC-1155</Text>
            <Divider my={2} />
            <Button onClick={handleDeploy}>Deploy</Button>
            <Divider my={2} />
            <Text fontWeight="bold">Contract Address:</Text>
            <Text fontFamily="monospace">{contractAddress}</Text>
            <Divider my={2} />
            <Input placeholder="Enter token-id" maxLength={30} onChange={(e)=>setTokenID(e.target.value)} w={"300px"} />
            <Divider my={1} />
            <Input placeholder="Enter quantity to mint" maxLength={30} onChange={(e)=>setQuantity(e.target.value)} w={"300px"} />
            <Divider my={1} />
            <Button onClick={handleMint}>Mint NFT</Button>
            <Divider my={2} />
            <Input placeholder="Enter recipient address" maxLength={30} onChange={(e)=>setRecipientAddress(e.target.value)} w={"300px"} />
            <Divider my={1} />
            <Input placeholder="Enter token-id" maxLength={30} onChange={(e)=>setTokenID(e.target.value)} w={"300px"} />
            <Divider my={1} />
            <Input placeholder="Enter quantity to send" maxLength={30} onChange={(e)=>setQuantity(e.target.value)} w={"300px"} />
            <Divider my={1} />
            <Button onClick={handleTransfer}>Transfer</Button>
            <Divider my={7} />
            <ERC721 signer={signer} />
            <ERC20 />
        </Flex>
    )
}

export default ERC1155;


   // const handleApprove = async() =>{
    //     const contract = new ethers.Contract(contractAddress,transferABI,signer);
    //     const tx = await contract.setApprovalForAll("0x6e654df4037e0d0313E6E6a07701FED65CBF956f",true)
    //     await tx.wait()
    // }

    // const handleIsApproved = async() => {
    //     const contract = new ethers.Contract(contractAddress,transferABI,"0x6e654df4037e0d0313E6E6a07701FED65CBF956f");
    //     const tx = await contract.isApprovedForAll(signer,"0x6e654df4037e0d0313E6E6a07701FED65CBF956f")
    //     setApproved(tx)
    //     await tx.wait()     0x0a7469CF91781F36C1224dD624ef68E9ec01Db58
    // }


     // const contract = new web3.eth.Contract(transferABI,"0xAC96768dA33930437ecedC8837B186a380C85510")
        // // const gas = await contract.methods.mint(signer._address,3,10)
        // await contract.methods.mint(signer._address,3,10).send({from:user,})
        //     .on('transactionHash', (hash) => {
        //         console.log('Transaction hash:', hash);
        //     })
        //     .then((receipt) => {
        //         console.log('Transaction receipt:', receipt);
        //     })
        //     .catch((error) => {
        //         console.error(error);
        //     });

// const contract = new web3.eth.Contract(transferABI,"0xAC96768dA33930437ecedC8837B186a380C85510")
        // contract.methods
            // .safeTransferFrom(signer._address,"0x6e654df4037e0d0313E6E6a07701FED65CBF956f",3,3,"0x00")
            // .send({from:user})
            // .on("transactionHash",(hash)=>{
            //     console.log('Transaction hash:', hash);
            // })
            // .then((receipt) => {
            //     console.log('Transaction receipt:', receipt);
            // })
            // .catch((error) => {
            //     console.error(error);
            // });
        // const response = await magic.nft.transfer({
        //     contractAddress: "0xAC96768dA33930437ecedC8837B186a380C85510",
        //     tokenId: 3,
        //     quantity: 4,
        //     recipient: "0x6e654df4037e0d0313E6E6a07701FED65CBF956f"
        // })
        // console.log(response)
        // const transferComplete = response.status === 'complete';