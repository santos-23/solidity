import { Button, Divider, Flex, Text } from "@chakra-ui/react";
import { useState } from "react";
import Web3 from "web3";
import { ERC20ABI } from '../abi';
import { useUser } from "../context/UserContext";
import { magic } from "../libs/magic";


const ERC20 = () => {
    // const {web3} = useWeb3();
    const web3 = new Web3(magic.rpcProvider);
    const {user} = useUser();
    const [amount,setAmount] = useState(0)

    const handleMint = async() =>{
        try {
            const functionName = "mint";
            const arg1 = amount;
            const contract = new web3.eth.Contract(ERC20ABI as any,"0x2454743174B71DDfC012FBB7a59d7289bdeea8aA")
            // const functionData = contract.methods[functionName]().encodeABI();
            await contract.methods.name()
                .call({from:user})
                .then((result) => {
                    console.log('Function result:', result);
                })
                .catch((error) => {
                    console.error('Error:', error);
                });
        } catch (error) {
            console.log(error)
        }
    }

    return(
        <Flex direction={"column"}>
            <Divider my={7} />
            <Text fontFamily="heading" fontWeight={"bold"} fontSize={22} align={"center"}>ERC-20</Text>
            <Divider my={2} />
            <Button onClick={handleMint}>Mint</Button>
        </Flex>
    )
}

export default ERC20;