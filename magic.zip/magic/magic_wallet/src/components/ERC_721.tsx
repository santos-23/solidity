import { Button, Divider, Flex, Text } from "@chakra-ui/react";
import Web3 from "web3";
import { ERC721ABI } from "../abi";
import { useUser } from "../context/UserContext";
import { magic } from "../libs/magic";

const ERC_721 = () => {
    const web3 = new Web3(magic.rpcProvider);

    const {user} = useUser();

    const handleMint = () =>{
        const contract = new web3.eth.Contract(ERC721ABI,"0xcD3596b8c56d0CAfc9D8bD93d003cA57F11BD576")
        // const contract = new ethers.Contract("0xcD3596b8c56d0CAfc9D8bD93d003cA57F11BD576",ERC721ABI,signer)
        contract.methods.mint().send({from:"0xf9200b48D73FD0cEB081448884Fa239cFA592744"}).then(console.log)
    }

    return(
        <Flex direction={"column"}>
            <Divider my={7} />
            <Text fontFamily="heading" fontWeight={"bold"} fontSize={22} align={"center"}>ERC-721</Text>
            <Divider my={2} />
            <Button onClick={handleMint}>Mint NFT</Button>
            <Divider my={2} />
        </Flex>
    )
}

export default ERC_721;