import { Button, Input, Text } from "@chakra-ui/react";
import { useState } from "react";
import { useWeb3 } from "../context/Web3Context";
import { magic } from "../libs/magic";

const ConnectButton = () => {
    const { initializeWeb3 } = useWeb3()
    const [phoneNumber,setPhoneNumber] = useState('')
    const handleConnect = async() =>{
        try{
            await magic.wallet.connectWithUI();
            // magic.wallet.
            initializeWeb3()
        }catch(error){
            console.log("Handle Connect Errors: ", error)
        }
    }

    const handleLogin = async(e:any) => {
        e.preventDefault();
        try {
            if (phoneNumber) {
                await magic.auth.loginWithSMS({phoneNumber});
            }
        } catch (error) {
            console.log(error)
        }
    };

    return(
        <div>
            <Button onClick={handleConnect}>
                Connect
            </Button>
            <Text>Please sign up or login</Text>
            <form onSubmit={handleLogin}>
                <Input type="phonenumber" value={phoneNumber} onChange={(e)=>setPhoneNumber(e.target.value)} required placeholder="Enter your phonenumber" />
                <Button type="submit">Send</Button>
            </form>
        </div>
    )
}

export default ConnectButton;