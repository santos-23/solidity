
















const { ethers } = require('hardhat');

async function main() {
    // console.log('Deploying contract with address:', deployer.address);

    const ContractFactory = await ethers.getContractFactory('erc1155');
    const contract = await ContractFactory.deploy();
    console.log('Contract address:', contract.address);
}

main()
.then(() => process.exit(0))
.catch(error => {
    console.error(error);
    process.exit(1);
});
