/** @type import('hardhat/config').HardhatUserConfig */
require("dotenv").config();
module.exports = {
  solidity: "0.8.19",
  networks: {
    goerli:{
      url: 'https://goerli.infura.io/v3/d45ef8d0c163493fb59babc623f635b4',
      accounts:[
        `0x${process.env.PRIVATE_KEY1}`
      ]
    }
  }
};
