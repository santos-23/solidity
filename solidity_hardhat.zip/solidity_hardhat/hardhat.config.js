/** @type import('hardhat/config').HardhatUserConfig */
require("dotenv").config();
require("@nomiclabs/hardhat-waffle");
require("@nomiclabs/hardhat-ganache");
module.exports = {
  solidity: "0.8.19",
  networks: {
    localganache1: {
      url: "HTTP://127.0.0.1:7545",
      accounts: [`0x${process.env.PRIVATE_KEY}`],
    }
  }
};




// task("deploy", "Deploys the HelloWorld contract and sets a new message")
//     .setAction(async () => {
//         await run("compile");
//         await run("scripts/deploy.js");
//     });
