const { ethers } = require("hardhat");

async function main() {
    const [deployer] = await ethers.getSigners();

    const BalanceReducer = await ethers.getContractFactory("BalanceReducer");
    const balanceReducer = await BalanceReducer.attach("CONTRACT_ADDRESS"); // Replace with the actual contract address

    // Replace with the address you want to reduce the balance of
    const targetAddress = "TARGET_ADDRESS";
    const amount = ethers.utils.parseEther("1"); // Amount to reduce

    console.log("Reducing balance...");
    await balanceReducer.reduceBalance(targetAddress, amount);

    console.log("Balance reduced successfully!");
}

main()
    .then(() => process.exit(0))
    .catch((error) => {
        console.error(error);
        process.exit(1);
    });
