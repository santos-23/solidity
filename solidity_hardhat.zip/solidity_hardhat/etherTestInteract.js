
const { ethers } = require('hardhat');
const myContractABI = require('./artifacts/contracts/Ether.sol/MyContract.json');

async function main(){
    const rpcURL = "HTTP://127.0.0.1:7545";
    const provider = new ethers.providers.JsonRpcProvider(rpcURL);

    // Replace with the deployed contract's address
    const contractAddress = "0xc9b158C9F8C504CB3eFfC9740bfa454F00fcAF27";

    const contract = new ethers.Contract(contractAddress, myContractABI, provider);

    // Call a function on the contract
    const accountBalance = await contract.getAccountBalance("0x74630c903687dCbB670774E41D7a8FB221eA1b37");

    console.log("Account Balance:", accountBalance.toString());
}

main();