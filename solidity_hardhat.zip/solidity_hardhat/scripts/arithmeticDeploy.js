
async function main() {
    const Arithmetic = await ethers.getContractFactory("Arithmetic");
    const arithmetic = await Arithmetic.deploy();

    await arithmetic.deployed();

    console.log("Arithmetic contract deployed to:", arithmetic.address);
}

main()
    .then(() => process.exit(0))
    .catch(error => {
        console.error(error);
        process.exit(1);
    });
