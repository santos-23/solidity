
async function main(){
    const ether = await ethers.getContractFactory("PayableContract");
    const etherDeploy = await ether.deploy();
    console.log("Deployed in : ",etherDeploy.address)
}

main()
.then(()=>process.exit(0))
.catch((error)=>{
    console.error(error);
    process.exit(1)
})