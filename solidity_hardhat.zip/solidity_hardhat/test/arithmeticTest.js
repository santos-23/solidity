const { expect } = require('chai');

describe("Arithmetic Operations: ",function(){
    let arithmetic;

    beforeEach(async function(){
        const Arithmetic = await ethers.getContractFactory("Arithmetic");
        arithmetic = await Arithmetic.deploy();
        await arithmetic.deployed();
    })

    it("should perform Arithmetic operations",async function(){
        const a = await arithmetic.a();
        const b = await arithmetic.b();

        const expectedAddition = a.add(b);
        const expectedSubtraction = a.sub(b);
        const expectedMultiplication = a.mul(b);
        const expectedDivision = a.div(b);
        const expectedModulus = a.mod(b);

        expect(await arithmetic.addition()).to.equal(expectedAddition);
        expect(await arithmetic.subtraction()).to.equal(expectedSubtraction);
        expect(await arithmetic.multiplication()).to.equal(expectedMultiplication);
        expect(await arithmetic.division()).to.equal(expectedDivision);
        expect(await arithmetic.modulus()).to.equal(expectedModulus);
    })
    it("should update values",async function(){
        await arithmetic.updateValues(10,10);
        expect(await arithmetic.a()).to.equal(10);
        expect(await arithmetic.b()).to.equal(10);
    })
})