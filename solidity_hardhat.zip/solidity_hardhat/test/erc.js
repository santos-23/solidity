
const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("MyToken Contract", function () {
    let myToken;
    let owner;
    let recipient;
    let addrs;

    beforeEach(async function () {
        const MyToken = await ethers.getContractFactory("ercToken");
        [owner, recipient, ...addrs] = await ethers.getSigners();

        myToken = await MyToken.deploy("My Token", "MTK");
        await myToken.deployed();
    });

    it("should have correct name, symbol, and initial supply", async function () {
        expect(await myToken.name()).to.equal("My Token");
        expect(await myToken.symbol()).to.equal("MTK");
        expect(await myToken.totalSupply()).to.equal(ethers.utils.parseEther("1000"));
    });

    it("should assign initial supply to owner", async function () {
        const ownerBalance = await myToken.balanceOf(owner.address);
        expect(ownerBalance).to.equal(ethers.utils.parseEther("1000"));
    });

    it("should transfer tokens between accounts", async function () {
        await myToken.connect(owner).transfer(recipient.address, ethers.utils.parseEther("100"));
        const recipientBalance = await myToken.balanceOf(recipient.address);
        expect(recipientBalance).to.equal(ethers.utils.parseEther("100"));
    });

});
