const { expect } = require("chai");

describe("TransferEther Contract", function () {
    let transferEther;
    let owner, recipient;

    beforeEach(async function () {
        const TransferEther = await ethers.getContractFactory("TransferEther");
        transferEther = await TransferEther.deploy();
        await transferEther.deployed();

        [owner, recipient] = await ethers.getSigners();
    });

    it("should transfer Ether to recipient", async function () {
        const initialBalance = await ethers.provider.getBalance(recipient.address);
        const amountToSend = ethers.utils.parseEther("0.1"); // 0.1 Ether

        await transferEther.connect(owner).transferEther(recipient.address, amountToSend);

        const newBalance = await ethers.provider.getBalance(recipient.address);
        expect(newBalance.sub(initialBalance)).to.equal(amountToSend);
    });

    it("should revert when amount is more than balance", async function () {
        const balance = await ethers.provider.getBalance(transferEther.address);
        const amountToSend = balance.add(ethers.utils.parseEther("1.0")); // More than the contract balance

        await expect(transferEther.connect(owner).transferEther(recipient.address, amountToSend))
            .to.be.revertedWith("Insufficient Balance");
    });
});





// const { expect } = require('chai');

// describe("Transfer Ether: ",function(){
//     let myContract;
//     let sender,recipient;

//     beforeEach(async function(){
//         const MyContract = await ethers.getContractFactory("TransferEther");
//         myContract = await MyContract.deploy();
//         await myContract.deployed();

//         [sender,recipient] = await ethers.getSigners();
//     })

//     it("should transfer the Ether to another address",async function(){
//         const initialBalance = await ethers.provider.getBalance(recipient.address);
//         const amountToSend = ethers.utils.parseEther("0.1")

//         await myContract.connect(sender).transferEther(recipient.address,amountToSend);

//         const newBalance = await ethers.provider.getBalance(recipient.address);
//         expect(initialBalance.sub(newBalance)).to.equal(amountToSend);
//     });
//     it("should revert when amount is more than balance", async function () {
//         const balance = await ethers.provider.getBalance(myContract.address);
//         const amountToSend = balance.add(ethers.utils.parseEther("1.0")); // More than the contract balance

//         await expect(myContract.connect(sender).transferEther(recipient.address, amountToSend))
//             .to.be.revertedWith("Insufficient Balance");
//     });
// })