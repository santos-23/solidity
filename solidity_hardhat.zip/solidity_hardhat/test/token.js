const { expect } = require('chai');

describe("Token Contract",function(){
    let owner,Token,addr1,addr2,addrs,hardhatToken;

    beforeEach(async function(){
        Token = await ethers.getContractFactory("Token");
        [owner,addr1,addr2,...addrs] = await ethers.getSigners();
        hardhatToken = await Token.deploy();
    })

    describe("Deployement: ",function(){
        it("should set the right owner",async function(){
            expect(await hardhatToken.owner()).to.equal(owner.address)
        });
        it("should assign the total supply of tokens to the owner",async function(){
            const ownerBalance = await hardhatToken.balanceOf(owner.address);
            expect(await hardhatToken.totalSupply()).to.equal(ownerBalance);
        })
    })

    describe("Transfer: ",function(){
        it("should transfer tokens between accounts",async function(){
            await hardhatToken.transfer(addr1.address,10);
            const addr1Balance = await hardhatToken.balanceOf(addr1.address);
            console.log("adde1: ",addr1Balance);
            expect(addr1Balance).to.equal(10);


            await hardhatToken.connect(owner).transfer(addr2.address,5);
            const addr2Balance = await hardhatToken.balanceOf(addr2.address);
            expect(addr2Balance).to.equal(5);
        })
        it('should fail if sender does not have enough tokens',async function(){
            const initialOwnerBalance = await hardhatToken.balanceOf(owner.address);
            await expect(hardhatToken.connect(addr1).transfer(owner.address,1)).to.be.revertedWith("Not enough Tokens...");
            expect(await hardhatToken.balanceOf(owner.address)).to.equal(initialOwnerBalance);
        })
        it("should update balance after the transfer",async function(){
            const initialOwnerBalance = await hardhatToken.balanceOf(owner.address);
            await hardhatToken.transfer(addr1.address,10);
            await hardhatToken.transfer(addr2.address,5);

            const finalOwnerBalance = await hardhatToken.balanceOf(owner.address);
            expect(finalOwnerBalance).to.equal(initialOwnerBalance-15);

            const addr1Balance = await hardhatToken.balanceOf(addr1.address);
            expect(addr1Balance).to.equal(10);
            const addr2Balance = await hardhatToken.balanceOf(addr2.address);
            expect(addr2Balance).to.equal(5);
        })
    })
})

// describe("Token Contract",function(){
//     it("Deployment should assign the total supply of tokens to the owner ", async function(){
//         const [owner] = await ethers.getSigners();
//         // console.log("signers object: ",owner);

//         const Token = await ethers.getContractFactory("Token");
//         const hardhatToken = await Token.deploy();
//         const ownerBalance = await hardhatToken.balanceOf(owner.address);
//         // console.log('owner address: ',owner.address);

//         expect(await hardhatToken.totalSupply()).to.equal(ownerBalance);
//         console.log('run4 successfully');
//     });
//     it("should transfer the tokens between the accounts", async function(){
//         const [owner,addr1,addr2] = await ethers.getSigners();
//         // console.log("signers object: ",owner);

//         const Token = await ethers.getContractFactory("Token");
//         const hardhatToken = await Token.deploy();
        
//         await hardhatToken.transfer(addr1.address,10);
//         expect(await hardhatToken.balanceOf(addr1.address)).to.equal(10);
        
//         await hardhatToken.transfer(addr2.address,5);
//         expect(await hardhatToken.balanceOf(addr2.address)).to.equal(5);

//     })
// })