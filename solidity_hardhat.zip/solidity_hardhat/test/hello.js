const { expect } = require('chai');

describe('HelloWorld', function () {
    it('Should return the correct message', async function () {
        const HelloWorld = await ethers.getContractFactory('HelloWorld');
        const helloWorld = await HelloWorld.deploy();

        await helloWorld.deployed();
        expect(await helloWorld.message()).to.equal('Hello, World!');

        await helloWorld.setMessage('New message');
        expect(await helloWorld.message()).to.equal('New message');
    });
});
