
const { expect } = require("chai");


describe("MyContract",function(){
    let myContract;
    let address1;

    beforeEach(async function(){
        const MyContract = await ethers.getContractFactory("MyContract");
        [address1] = await ethers.getSigners();
        myContract = await MyContract.deploy();
    })
    describe("receive",function(){
        it("should send ether to the contract and update the account balances",async function(){
            const provider = waffle.provider
            expect(await provider.getBalance(myContract.address)).to.equal(0);

            await address1.sendTransaction({
                to: myContract.address,
                value:100
            })
            
            expect(await provider.getBalance(myContract.address)).to.equal(100);
            expect(await myContract.getAccountBalance(address1.address)).to.equal(100)
        })
    })
})