const { expect } = require('chai');


describe("Send Ether",function(){
    let owner,recipient1,recipient2,recipients,ether,hardhatEther;

    beforeEach(async function(){
        ether = await ethers.getContractFactory("PayableContract");
        [owner,recipient1,recipient2,...recipients] = await ethers.getSigners();
        hardhatEther = await ether.deploy();
    })

    describe("Deployments: ",function(){
        it("should set the right owner",async function(){
            expect(await hardhatEther.owner()).to.equal(owner.address);
        });
        it("should send Ethers to recipients",async function(){
            await hardhatEther.sendEther(recipient1.address);
            expect(await hardhatEther.owner()).to.not.equal(recipient1.address);

            await hardhatEther.sendEther(recipient2.address);
            expect(await hardhatEther.owner()).to.not.equal(recipient2.address);
        })
    })
})
