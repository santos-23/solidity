const { ethers } = require("hardhat");

async function main(){
    const [deployer,player1,player2] = await ethers.getSigners();
    console.log('Lottery is deployed on : ',deployer.address);

    const Lottery = await ethers.getContractFactory("LotteryFirst");
    const lottery = await Lottery.deploy(500);
    console.log("Lottery Contract address : ",lottery.target)

    console.log("player 1: ",player1.address);
    console.log("player 2: ",player2.address);
    
    await player1.sendTransaction({
        to: lottery.address,
        value: ethers.parseEther("0.02")
    })
    await player2.sendTransaction({
        to: lottery.address,
        value: ethers.parseEther("0.02")
    })

    await lottery.generateSecretCode();
    const secretCode = await lottery.show();
    console.log(secretCode);

    await lottery.connect(player1).claim(23);
    await lottery.connect(player2).claim(secretCode);

    
}

main()
.then(()=>process.exit(0))
.catch((error)=>{
    console.error(error);
    process.exit(1)
})