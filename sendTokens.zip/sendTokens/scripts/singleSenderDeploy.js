async function main() {
    const [deployer] = await ethers.getSigners();

    console.log('Deploying contracts with the account:', deployer.address);

    const SingleSender = await ethers.getContractFactory('SingleSender');
    const singleSender = await SingleSender.deploy();


    const recipientAddress = '0x5a398371D5334A64e752509b5C99b8822036F63A';
    // singleSender.target = recipientAddress;
    
    const amountToSend = ethers.parseEther('0.01');
    const tx = await singleSender.sendEther(recipientAddress, { value: amountToSend });
    await tx.wait();

    // console.log(singleSender);
    console.log('Ethers sent to: ', recipientAddress);
}

main()
.then(()=>process.exit(0))
.catch((error) => {
    console.error('Error deploying contracts:', error);
    process.exit(1);
});
