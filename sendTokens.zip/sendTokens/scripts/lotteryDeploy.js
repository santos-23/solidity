

async function main(){
    const [deployer] = await ethers.getSigners();
    console.log('Lottery is deployed on : ',deployer.address);

    const Lottery = await ethers.getContractFactory("Lottery");
    const lottery = await Lottery.deploy();
    
    const player1 = "0xc9b158C9F8C504CB3eFfC9740bfa454F00fcAF27";
    const player2 = "0x5a398371D5334A64e752509b5C99b8822036F63A";
    const player3 = "0x4486Cc578880fe45550ccB821C842D61eB74DdDb";
    const player4 = "0x9CaE8b09de8185577Be99E4c523844F858F5bBF9";

    // const players = [player1,player2,player3,player4];
    await lottery.buyTicket(player1,{ value: ethers.parseEther("0.02") });
    await lottery.buyTicket(player2,{ value: ethers.parseEther("0.02") });
    await lottery.buyTicket(player3,{ value: ethers.parseEther("0.02") });
    await lottery.buyTicket(player4,{ value: ethers.parseEther("0.02") });
    await lottery.getPlayers();

    await lottery.pickWinner();
    const winner = await lottery.showWinner();
    console.log(winner);

    const secretCode = await lottery.secretCode(winner);
    console.log(secretCode);
    // const secretCode = 23;
    await lottery.claimReward(secretCode);

}

main()
.then(()=>process.exit(0))
.catch((error)=>{
    console.error(error);
    process.exit(1)
})