// const { ethers } = require("hardhat");

async function main(){
    const [deployer] = await ethers.getSigners();

    console.log('Deploying contracts with the account:', deployer.address);

    const MultipleReceiver = await ethers.getContractFactory("MultipleReceiver");
    const  multipleReceiver = await MultipleReceiver.deploy();

    const address1 = "0xc9b158C9F8C504CB3eFfC9740bfa454F00fcAF27";
    const address2 = "0x5a398371D5334A64e752509b5C99b8822036F63A";
    const address3 = "0x4486Cc578880fe45550ccB821C842D61eB74DdDb";

    const totalValue = ethers.parseEther('0.03');
    const recipientAddress = [address1,address2,address3];
    const amounts = [ethers.parseEther("0.01"),ethers.parseEther("0.01"),ethers.parseEther("0.01")];
    const tx = await multipleReceiver.sendEther(recipientAddress,amounts,{value:totalValue});
    await tx.wait();

    console.log("Ethers sent to Multiple Accounts.....");
    console.log(`address1: ${address1}`);
    console.log(`address2: ${address2}`);
    console.log(`address3: ${address3}`);
}

main()
.then(()=>process.exit(0))
.catch((error)=>{
    console.log(error);
    process.exit(1);
})