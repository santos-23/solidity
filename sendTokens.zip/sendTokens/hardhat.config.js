/** @type import('hardhat/config').HardhatUserConfig */
require("dotenv").config();
require("@nomicfoundation/hardhat-toolbox");
module.exports = {
  solidity: "0.8.19",
  networks: {
    localganache1: {
      url: "HTTP://127.0.0.1:7545",
      accounts:[
        `0x${process.env.PRIVATE_KEY1}`, //0x74630c903687dCbB670774E41D7a8FB221eA1b37
        `0x${process.env.PRIVATE_KEY2}`, //0x5a398371D5334A64e752509b5C99b8822036F63A
        `0x${process.env.PRIVATE_KEY3}`, //0xc9b158C9F8C504CB3eFfC9740bfa454F00fcAF27
      ]
    }
  }
};