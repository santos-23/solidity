const { expect } = require('chai');

describe("Token Contract",function(){
    let sender,Token,receiver,addrs,hardhatToken;

    beforeEach(async function(){
        Token = await ethers.getContractFactory("SendOne");
        [sender,receiver,...addrs] = await ethers.getSigners();
        hardhatToken = await Token.deploy();
    })

    describe("Transfer: ",function(){
        it("should transfer tokens between accounts",async function(){
            await hardhatToken.transfer(receiver.address,10);
            const receiverBalance = await hardhatToken.balanceOf(receiver.address);
            const senderBalance = await hardhatToken.balanceOf(sender.address)
            console.log("senderBalance: ",senderBalance)
            console.log("receiverBalance: ",receiverBalance);
            expect(receiverBalance).to.equal(10);
        })
        it('should fail if sender does not have enough tokens',async function(){
            const initialSenderBalance = await hardhatToken.balanceOf(sender.address);
            // console.log("initialBalance: ",initialSenderBalance)
            await expect(hardhatToken.connect(receiver).transfer(sender.address,100)).to.be.revertedWith("Not enough Tokens...");
            expect(await hardhatToken.balanceOf(sender.address)).to.equal(initialSenderBalance);
        })
        it("should update balance after the transfer",async function(){
            const initialSenderBalance = await hardhatToken.balanceOf(sender.address);
            await hardhatToken.transfer(receiver.address,10);

            const finalSenderBalance = await hardhatToken.balanceOf(sender.address);
            expect(finalSenderBalance).to.equal((BigInt(initialSenderBalance) - BigInt(10)));
            console.log("senderBalance: ",finalSenderBalance)

            const receiverBalance = await hardhatToken.balanceOf(receiver.address);
            expect(receiverBalance).to.equal(10);
            
        })
    })
})

