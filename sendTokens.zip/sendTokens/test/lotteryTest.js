const { expect } = require('chai');
const { ethers } = require('hardhat');

describe("Lottery Contract",function(){
    let Lottery,lottery;

    beforeEach(async function(){
        Lottery = await ethers.getContractFactory("Lottery");
        lottery = await Lottery.deploy();
    })

    it("Should allow participants to buy tickets", async function() {
        const player1 = "0xc9b158C9F8C504CB3eFfC9740bfa454F00fcAF27";
        await lottery.buyTicket(player1,{ value: ethers.parseEther("0.02") });
        const players = await lottery.getPlayers();
        expect(players.length).to.equal(1);
    });
    it("Should pick a winner and allow claiming", async function() {
        const player1 = "0xc9b158C9F8C504CB3eFfC9740bfa454F00fcAF27";
        const player2 = "0x5a398371D5334A64e752509b5C99b8822036F63A";
        await lottery.buyTicket(player1,{ value: ethers.parseEther("0.02") });
        await lottery.buyTicket(player2,{ value: ethers.parseEther("0.02") });
    
        await lottery.pickWinner();

        const winner = await lottery.showWinner();

        const secretCode = await lottery.secretCode(winner);
        await lottery.claimReward(secretCode);

        const hasClaimed = await lottery.hasClaimed(winner);
        expect(hasClaimed).to.equal(true);
    });
})