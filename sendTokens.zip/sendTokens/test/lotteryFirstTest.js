const { expect } = require('chai');
const { ethers } = require('hardhat');

describe("Lucky Lottery",function(){
    let owner;
    let participant;
    let lottery;

    beforeEach(async function(){
        const Lottery = await ethers.getContractFactory("LotteryFirst");
        lottery = await Lottery.deploy(500);
    })

    it("should allow participants",async function(){
        participant = "0xc9b158C9F8C504CB3eFfC9740bfa454F00fcAF27";
        const price = ethers.parseEther("0.01");
        await expect(()=> participant.sendTransaction({
            to : lottery.address,
            value : price
        })).to.changeEtherBalance(participant,price);
        expect(await lottery.checkTicketPurchase(participant.address)).to.be.true;
    })
})