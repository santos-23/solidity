const { expect } = require('chai');
const { ethers } = require('hardhat');

describe("Multiple Accounts",function(){
    let address1,address2,address3,MultipleReceiver,multipleReceiver;

    beforeEach(async function(){
        MultipleReceiver = await ethers.getContractFactory("MultipleReceiver");
        multipleReceiver = await MultipleReceiver.deploy();
        // await multipleReceiver.deployed();
        address1 = "0xc9b158C9F8C504CB3eFfC9740bfa454F00fcAF27";
        address2 = "0x5a398371D5334A64e752509b5C99b8822036F63A";
        address3 = "0x4486Cc578880fe45550ccB821C842D61eB74DdDb";
    })

    it("should send ethers to multiple accounts",async function(){
        const recipientAddress = [address1,address2,address3];
        const initialBalance = await ethers.provider.getBalance(address1);
        const amountToSend = ethers.parseEther("0.1");
        const amounts = [ethers.parseEther("0.1"),ethers.parseEther("0.1"),ethers.parseEther("0.1")];
        const tx = await multipleReceiver.sendEther(recipientAddress,amounts,{value:ethers.parseEther("0.3")});
        await tx.wait();

        const finalBalance = await ethers.provider.getBalance(address1);
        const expectedBalance = initialBalance+amountToSend;
        expect(finalBalance).to.equal(expectedBalance);
    })
})