const { expect } = require('chai');
const { ethers } = require('hardhat');

describe('SingleSender', function () {
    it('Should send ether to one account', async function () {
        const SingleSender = await ethers.getContractFactory('SingleSender');
        const singleSender = await SingleSender.deploy();
        // await singleSender.deployed();

        const recipientAddress = '0x5a398371D5334A64e752509b5C99b8822036F63A'; // Replace with recipient address

        const initialBalance = await ethers.provider.getBalance(recipientAddress);
        const amountToSend = ethers.parseEther('0.1');
        const tx = await singleSender.sendEther(recipientAddress, { value: amountToSend });
        await tx.wait();

        const finalBalance = await ethers.provider.getBalance(recipientAddress);
        const equal = initialBalance + amountToSend;
        expect(finalBalance).to.equal(equal);
    });
});
